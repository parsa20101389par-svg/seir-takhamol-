extends Area2D
# گلوله اسیدی آسید اسپیتر - حرکت آرام، آسیب به بازیکن در برخورد

var velocity: Vector2 = Vector2.ZERO
var damage: float = 6.0
var lifetime: float = 4.0
var radius: float = 9.0
var pulse_time: float = 0.0

func _ready():
	add_to_group("acid_blobs")
	collision_layer = 0
	collision_mask = 1  # player layer
	pulse_time = randf_range(0, 10)
	var tw : Tween = create_tween()
	tw.tween_interval(lifetime)
	tw.tween_callback(queue_free)

func setup(dir: Vector2, spd: float = 160.0, dmg: float = 6.0):
	velocity = dir.normalized() * spd
	damage = dmg

func _process(delta):
	position += velocity * delta
	pulse_time += delta * 6.0
	queue_redraw()

func _physics_process(_delta):
	for area in get_overlapping_areas():
		if area.is_in_group("food"):
			continue
	for body in get_overlapping_bodies():
		if body and body.has_method("take_damage"):
			body.take_damage(damage)
			_splash()
			return

func _splash():
	var parent : Node = get_parent()
	if parent and is_instance_valid(parent):
		for i in range(6):
			var lbl : Label = Label.new()
			lbl.text = "•"
			lbl.top_level = true
			lbl.z_index = 90
			lbl.global_position = global_position + Vector2(randf_range(-14, 14), randf_range(-14, 14))
			lbl.add_theme_color_override("font_color", Color(0.5, 1.0, 0.2))
			parent.add_child(lbl)
			var tw : Tween = lbl.create_tween()
			tw.tween_property(lbl, "modulate:a", 0.0, 0.5)
			tw.tween_callback(lbl.queue_free)
	queue_free()

func _draw():
	var p_scale = 1.0 + sin(pulse_time) * 0.2
	var r = radius * p_scale
	draw_circle(Vector2.ZERO, r + 4.0, Color(0.4, 1.0, 0.1, 0.2))
	draw_circle(Vector2.ZERO, r, Color(0.5, 1.0, 0.15, 0.85))
	draw_circle(Vector2(-r * 0.3, -r * 0.3), r * 0.35, Color(0.85, 1.0, 0.6, 0.8))
