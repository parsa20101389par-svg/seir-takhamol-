extends CharacterBody2D
# سیر تکامل - سلول دشمن: ۸ نوع با AI متمایز، انیمیشن ارگانیک و تیراندازی اسید

enum EnemyType {
	AMINO_GRAZER,
	VIRUS_HUNTER,
	ARMORED_DIATOM,
	ELECTRIC_JELLY,
	LEVIATHAN_TITAN,
	ACID_SPITTER,
	SWARM_MITE,
	CRYSTAL_AMOEBA
}

const ACID_RANGE: float = 650.0
const ACID_COOLDOWN: float = 1.4
const AGGRO_RANGE: float = 900.0
const MAX_ENEMY_MASS: float = 900.0

@export var enemy_type: EnemyType = EnemyType.AMINO_GRAZER
var mass: float = 20.0
@export var is_boss: bool = false
@export var is_event_hunter: bool = false
@export var is_predator: bool = false
var attack_flash_timer: float = 0.0
var is_event_hunter_alias: bool = false
var event_hunter: bool = false # Backward-compatible alias for existing world code
var event_lifetime: float = 0.0
var event_expired: bool = false
var boss_max_hp: float = 0.0
var boss_hp: float = 0.0
var boss_phase: int = 1
var boss_phase_count: int = 3
var boss_phase_flash: float = 0.0
var radius: float = 20.0
var speed: float = 120.0
var slow_factor: float = 1.0  # Time Warp: کند شدن توسط بازیکن
var flee_speed: float = 160.0
var pulse_time: float = 0.0
var wiggle_phase: float = 0.0
var rotation_anim: float = 0.0
var rotation_speed: float = 0.0
var target_player: Node2D = null
var defense_mult: float = 1.0   # damage taken multiplier
var dna_multiplier: int = 1     # DNA drop multiplier on defeat
var difficulty: float = 1.0     # ضریب سختی جهانی (با سطح بازیکن بالا می‌رود)
var region_name: String = "دشت آرام"
var region_tint: Color = Color(0.18, 0.82, 0.78)
var region_secondary: Color = Color(0.08, 0.45, 0.40)
var region_visual_style: int = 0
var organelle_seed: float = 0.0 # فاز شخصی ارگانل‌ها برای تنوع بصری
var spots_seed: float = 0.0     # الگوی خال/رگه هر سلول منحصر به فرد باشد
var organelle_rng: RandomNumberGenerator = RandomNumberGenerator.new()
var spots_rng: RandomNumberGenerator = RandomNumberGenerator.new()

var base_color: Color = Color(1.0, 0.3, 0.3)
var membrane_color: Color = Color(1.0, 0.6, 0.6)
var wander_timer: float = 0.0
var wander_dir: Vector2 = Vector2.ZERO
var attack_cooldown: float = 0.0
var acid_cooldown: float = 0.0
var ai_timer: float = 0.0
var ai_mode: String = "wander"   # wander / chase / flee / posture / hunt_enemy / flee_enemy
var last_velocity: Vector2 = Vector2.ZERO

signal died(enemy_pos: Vector2, enemy_type: int, enemy_mass: float)
signal hit_player(position: Vector2, damage: float)
signal damage_to_player(damage_val: float, knockback_vector: Vector2)
signal boss_hp_changed(current_hp: float, max_hp: float)
signal boss_defeated(position: Vector2)

@onready var col_shape: CollisionShape2D = $CollisionShape2D

func _ready():
	add_to_group("enemies")
	if is_event_hunter_alias:
		is_event_hunter = true	
	event_hunter = is_event_hunter
	if enemy_type == EnemyType.VIRUS_HUNTER or is_event_hunter:
		is_predator = true
	setup_type()
	set_region_theme(region_name)
	if enemy_type == EnemyType.VIRUS_HUNTER or is_event_hunter:
		base_color = Color(0.58, 0.015, 0.055)
		membrane_color = Color(1.0, 0.12, 0.18)
	if is_boss:
		mass = maxf(mass * 5.0, 650.0)
		speed *= 0.78
		flee_speed *= 0.78
		radius = 16.0 + sqrt(mass) * 4.4
		if col_shape and col_shape.shape is CircleShape2D:
			col_shape.shape.radius = radius
		boss_max_hp = mass * 1.7
		boss_hp = boss_max_hp
		boss_hp_changed.emit(boss_hp, boss_max_hp)
	pulse_time = randf_range(0, 10)
	wiggle_phase = randf_range(0, TAU)
	rotation_speed = randf_range(-0.5, 0.5)
	if enemy_type == EnemyType.SWARM_MITE:
		rotation_speed *= 3.0
	organelle_seed = randf_range(0.0, TAU)
	spots_seed = randf_range(0.0, 100.0)
	# RNG یک بار در _ready ساخته/تنظیم می‌شود (نه در _draw)
	organelle_rng.seed = int(organelle_seed * 1000.0)
	spots_rng.seed = int(spots_seed * 100.0)
	wander_timer = randf_range(0.8, 2.0)
	ai_timer = randf_range(0.0, 0.5)
	acid_cooldown = randf_range(0.5, ACID_COOLDOWN)

func setup_type():
	match enemy_type:
		EnemyType.AMINO_GRAZER:
			mass = randf_range(20.0, 38.0)
			speed = 180.0
			flee_speed = 250.0
			base_color = Color(0.3, 0.85, 0.4)
			membrane_color = Color(0.6, 1.0, 0.6)
		EnemyType.VIRUS_HUNTER:
			mass = randf_range(34.0, 58.0)
			speed = 245.0
			flee_speed = 285.0
			base_color = Color(0.95, 0.2, 0.3)
			membrane_color = Color(1.0, 0.4, 0.4)
		EnemyType.ARMORED_DIATOM:
			mass = randf_range(65.0, 115.0)
			speed = 106.0
			flee_speed = 138.0
			base_color = Color(0.85, 0.6, 0.1)
			membrane_color = Color(1.0, 0.85, 0.3)
		EnemyType.ELECTRIC_JELLY:
			mass = randf_range(50.0, 85.0)
			speed = 138.0
			flee_speed = 175.0
			base_color = Color(0.7, 0.2, 0.95)
			membrane_color = Color(0.85, 0.5, 1.0)
		EnemyType.LEVIATHAN_TITAN:
			mass = randf_range(150.0, 260.0)
			speed = 88.0
			flee_speed = 118.0
			base_color = Color(0.1, 0.15, 0.4)
			membrane_color = Color(0.2, 0.5, 0.9)
		EnemyType.ACID_SPITTER:
			mass = randf_range(48.0, 78.0)
			speed = 100.0
			flee_speed = 150.0
			base_color = Color(0.35, 0.65, 0.1)
			membrane_color = Color(0.65, 1.0, 0.2)
		EnemyType.SWARM_MITE:
			mass = randf_range(10.0, 20.0)
			speed = 355.0
			flee_speed = 410.0
			base_color = Color(1.0, 0.55, 0.1)
			membrane_color = Color(1.0, 0.8, 0.4)
		EnemyType.CRYSTAL_AMOEBA:
			mass = randf_range(115.0, 180.0)
			speed = 69.0
			flee_speed = 94.0
			defense_mult = 0.35   # takes ~1/3 damage
			dna_multiplier = 3    # drops 3x DNA on defeat
			base_color = Color(0.35, 0.85, 0.9)
			membrane_color = Color(0.7, 1.0, 1.0)
	# سرعت/جرم با سختی جهانی مقیاس می‌شود؛ سقف جرم برای غول‌های واقعی
	mass = minf(mass * (0.85 + difficulty * 0.3), MAX_ENEMY_MASS)
	speed *= (0.85 + difficulty * 0.18)
	flee_speed *= (0.85 + difficulty * 0.18)
	# پرچم بزرگ‌تر: شعاع پایه حدود ۴۵٪ بیشتر از قبل
	radius = 16.0 + sqrt(mass) * 4.4
	if col_shape and col_shape.shape is CircleShape2D:
		col_shape.shape.radius = radius

func set_region_theme(new_region: String) -> void:
	region_name = new_region
	match new_region:
		"دشت آرام":
			region_tint = Color(0.18, 0.88, 0.78)
			region_secondary = Color(0.05, 0.42, 0.34)
			region_visual_style = 0
		"جنگل زیستی":
			region_tint = Color(0.28, 1.0, 0.28)
			region_secondary = Color(0.10, 0.48, 0.16)
			region_visual_style = 1
		"منطقه شکار":
			region_tint = Color(1.0, 0.20, 0.12)
			region_secondary = Color(0.48, 0.025, 0.03)
			region_visual_style = 2
		"خندق تاریک":
			region_tint = Color(0.56, 0.30, 1.0)
			region_secondary = Color(0.14, 0.06, 0.38)
			region_visual_style = 3
		"شهر مرجانی":
			region_tint = Color(1.0, 0.38, 0.72)
			region_secondary = Color(0.55, 0.10, 0.24)
			region_visual_style = 4
		"دره کریستالی":
			region_tint = Color(0.42, 0.92, 1.0)
			region_secondary = Color(0.08, 0.34, 0.58)
			region_visual_style = 5
		"غار زیستی":
			region_tint = Color(0.72, 0.36, 1.0)
			region_secondary = Color(0.26, 0.08, 0.40)
			region_visual_style = 6
		"آب‌های یخی":
			region_tint = Color(0.72, 0.96, 1.0)
			region_secondary = Color(0.10, 0.32, 0.52)
			region_visual_style = 7
	# هر منطقه کمی رفتار/قدرت متفاوت هم دارد.
	if region_visual_style == 2:
		speed *= 1.05
	elif region_visual_style == 3:
		speed *= 0.94
	elif region_visual_style == 7:
		speed *= 0.90
	queue_redraw()

func set_hunter_threat(player_mass: float, player_speed: float) -> void:
	# Scale hunters against the current player; ensure they are genuinely dangerous.
	mass = maxf(mass, player_mass * randf_range(1.1, 1.45))
	is_predator = true
	radius = 16.0 + sqrt(mass) * 4.4
	if col_shape and col_shape.shape is CircleShape2D:
		col_shape.shape.radius = radius
	# Keep a pursuit advantage without making faster hunters trivial to escape.
	speed = maxf(speed, player_speed * 0.85)
	queue_redraw()

func _process(delta):
	if is_event_hunter and event_lifetime > 0.0:
		event_lifetime -= delta
		if event_lifetime <= 0.0:
			event_expired = true
			queue_free()
	pulse_time += delta * 3.5
	boss_phase_flash = maxf(0.0, boss_phase_flash - delta)
	wiggle_phase += delta * (2.5 if enemy_type != EnemyType.SWARM_MITE else 5.0)
	rotation_anim += rotation_speed * delta
	rotation = rotation_anim
	if attack_cooldown > 0:
		attack_cooldown -= delta
	attack_flash_timer = maxf(0.0, attack_flash_timer - delta)
	queue_redraw()

func _physics_process(delta):
	if slow_factor <= 0.0:
		slow_factor = 1.0
	# Wandering هوشمندتر: جهت‌ها سریع‌تر عوض می‌شوند و کمی به سمت بازیکن متمایل‌اند
	wander_timer -= delta
	if wander_timer <= 0:
		wander_timer = randf_range(1.0, 2.2)
		var target_dir = Vector2(randf_range(-1, 1), randf_range(-1, 1)).normalized()
		if target_player and is_instance_valid(target_player) and target_player.alive 				and global_position.distance_to(target_player.global_position) < AGGRO_RANGE * 1.4:
			var bias: Vector2 = (target_player.global_position - global_position).normalized()
			target_dir = (target_dir + bias * 0.45).normalized()
		wander_dir = wander_dir.lerp(target_dir, 0.75).normalized()
		if wander_dir.length() < 0.1:
			wander_dir = target_dir
	# SWARM_MITE: flocking/group wander toward nearby swarm center
	if enemy_type == EnemyType.SWARM_MITE:
		var center : Vector2 = Vector2.ZERO
		var n : int = 0
		for e in get_tree().get_nodes_in_group("enemies"):
			if e != self and is_instance_valid(e) and e.enemy_type == EnemyType.SWARM_MITE \
					and global_position.distance_to(e.global_position) < 400.0:
				center += e.global_position
				n += 1
		if n > 0:
			var to_center: Vector2 = (center / float(n) - global_position)
			wander_dir = wander_dir.lerp(to_center.normalized(), 0.35).normalized()
		# tiny separation jitter so they never perfectly overlap
		wander_dir += Vector2(sin(pulse_time * 3.0 + wiggle_phase), cos(pulse_time * 2.7)) * 0.15
		wander_dir = wander_dir.normalized()

	ai_timer -= delta
	if ai_timer <= 0:
		ai_timer = 0.3
		decide_ai_mode()

	var desired : Vector2 = Vector2.ZERO
	# باس و شکارچیان رویداد همیشه بازیکن را تعقیب می‌کنند؛
	# منطق flee/wander نباید این مأموریت را لغو کند.
	if target_player and is_instance_valid(target_player) and target_player.alive and (is_boss or is_event_hunter or event_hunter):
		var hunter_dir: Vector2 = (target_player.global_position - global_position).normalized()
		var pursuit_speed: float = speed * (1.35 if is_boss else 1.22)
		if is_event_hunter or event_hunter:
			pursuit_speed = maxf(pursuit_speed, target_player.current_speed * 1.18 + 35.0)
		desired = hunter_dir * pursuit_speed
		ai_mode = "chase"
	else:
		match ai_mode:
			"chase":
				var dir = (target_player.global_position - global_position).normalized()
				desired = dir * speed * 1.25
			"flee":
				var away = (global_position - target_player.global_position).normalized()
				desired = away * flee_speed
			"posture":
				var dir2 = (target_player.global_position - global_position).normalized()
				desired = dir2 * speed * 0.35   # slow territorial approach
			"hunt_enemy":
				desired = hunt_dir() * speed
			"flee_enemy":
				desired = -hunt_dir() * flee_speed
			_:
				desired = wander_dir * speed * 0.8
	# Electric jelly keeps its pulsing rhythm while chasing
	if enemy_type == EnemyType.ELECTRIC_JELLY and (ai_mode == "chase" or ai_mode == "posture"):
		desired *= (sin(pulse_time * 2.0) + 1.2)
	# ACID_SPITTER: strafe slowly while shooting from range
	if enemy_type == EnemyType.ACID_SPITTER and ai_mode == "chase":
		var to_p: Vector2 = target_player.global_position - global_position
		if to_p.length() < ACID_RANGE * 0.6:
			desired = to_p.normalized().orthogonal() * speed   # orbit instead of ram
	var smooth_factor: float = 1.0 - exp(-6.0 * delta)
	velocity = velocity.lerp(desired * slow_factor, smooth_factor)
	var sp: float = maxf(desired.length(), 1.0)
	velocity = velocity.limit_length(sp)
	# Soft repulsion (flocking separation): enemies push away from each other
	# so they scatter across the ocean instead of clumping into a line.
	# جداسازی سبک: فقط ۳ همسایه نزدیک بررسی می‌شود (بدون حلقه O(N^2) کامل)
	var separation : Vector2 = Vector2.ZERO
	var checked : int = 0
	for e in get_tree().get_nodes_in_group("enemies"):
		if checked >= 3:
			break
		if e == self or not is_instance_valid(e):
			continue
		var d : float = global_position.distance_to(e.global_position)
		if d > 400.0:
			continue
		checked += 1
		var min_d : float = radius + e.radius + 60.0
		if d < min_d and d > 0.01:
			separation += (global_position - e.global_position).normalized() * (1.0 - d / min_d)
	if separation.length() > 0.01:
		velocity += separation.normalized() * 320.0 * delta
	# Gently drift back toward the map center if pushed to the edge
	if global_position.length() > 2200.0:
		velocity += -global_position.normalized() * 60.0 * delta
	last_velocity = velocity
	move_and_slide()
	check_collisions()
	update_acid_shooting(delta)

func update_acid_shooting(delta):
	# ACID_SPITTER only: shoot AcidProjectile at player within ~500px
	if enemy_type != EnemyType.ACID_SPITTER:
		return
	if acid_cooldown > 0.0:
		acid_cooldown -= delta
		return
	if target_player == null or not is_instance_valid(target_player) or not target_player.alive:
		return
	var dist = global_position.distance_to(target_player.global_position)
	if dist > ACID_RANGE:
		return
	var dir: Vector2 = (target_player.global_position - global_position).normalized()
	var world = get_tree().get_first_node_in_group("world")
	if world and world.has_method("spawn_acid_projectile"):
		var proj_speed: float = 210.0 + difficulty * 40.0
		var proj_dmg: float = 9.0 + difficulty * 3.0
		world.spawn_acid_projectile(global_position + dir * (radius + 10.0), dir, proj_speed, proj_dmg)
		acid_cooldown = ACID_COOLDOWN / clampf(difficulty, 1.0, 2.2)

func strongest_threat() -> Node2D:
	# Bigger nearby enemy we should fear (also considers the player)
	var best: Node2D = null
	var best_m: float = mass * 1.15
	if target_player and is_instance_valid(target_player) and target_player.alive:
		if target_player.mass >= best_m and global_position.distance_to(target_player.global_position) < 800.0:
			best = target_player
			best_m = target_player.mass
	for e in get_tree().get_nodes_in_group("enemies"):
		if e == self or not is_instance_valid(e):
			continue
		if e.mass > best_m and global_position.distance_to(e.global_position) < 420.0:
			best = e
			best_m = e.mass
	return best

func best_prey() -> Node2D:
	var best: Node2D = null
	var best_m: float = mass * 0.9
	if target_player and is_instance_valid(target_player) and target_player.alive:
		if target_player.mass <= best_m and global_position.distance_to(target_player.global_position) < 850.0:
			best = target_player
			best_m = target_player.mass
	for e in get_tree().get_nodes_in_group("enemies"):
		if e == self or not is_instance_valid(e):
			continue
		if e.mass <= best_m and global_position.distance_to(e.global_position) < 500.0:
			best = e
			best_m = e.mass
	return best

func hunt_dir() -> Vector2:
	var prey = best_prey()
	if prey and is_instance_valid(prey):
		return (prey.global_position - global_position).normalized()
	return wander_dir

func decide_ai_mode():
	# شکارچیان رویداد «حمله شکارچیان» هدف اجباری دارند و نباید از دشمنان دیگر بترسند.
	if (is_event_hunter or event_hunter) and target_player and is_instance_valid(target_player) and target_player.alive:
		ai_mode = "chase"
		return
	# بازتاب/شکار در شعاع بزرگ‌تر: شکارچیان عادی از دورتر متوجه بازیکن می‌شوند
	var threat = strongest_threat()
	if threat and is_instance_valid(threat):
		ai_mode = "flee"
		return
	# SWARM_MITE: always flees a stronger player, never chases
	if enemy_type == EnemyType.SWARM_MITE and target_player and is_instance_valid(target_player) \
			and target_player.alive and global_position.distance_to(target_player.global_position) < 650.0:
		if target_player.mass > mass * 1.05:
			ai_mode = "flee"
			return
	var prey = best_prey()
	if prey and is_instance_valid(prey):
		# Player-relative rules with clear thresholds
		if prey == target_player:
			if mass > target_player.mass * 1.15:
				ai_mode = "chase"
			elif mass < target_player.mass * 0.9:
				ai_mode = "flee"
			else:
				ai_mode = "posture"
		else:
			ai_mode = "hunt_enemy"
		return
	ai_mode = "wander"

func check_collisions():
	for i in range(get_slide_collision_count()):
		var collision = get_slide_collision(i)
		var collider = collision.get_collider()
		if collider == target_player and is_instance_valid(target_player):
			if attack_cooldown <= 0:
				attack_cooldown = 0.8
				handle_player_encounter()

func eat(food_node: Node2D) -> void:
	# دشمنان هم غذا می‌خورند و رشد می‌کنند: تهدیدهای بزرگ در طول زمان شکل می‌گیرند
	if food_node.value < 0.0:
		return
	mass = minf(mass + food_node.value * 1.2, MAX_ENEMY_MASS)
	apply_growth_visual()

func apply_growth_visual() -> void:
	var new_radius: float = 16.0 + sqrt(mass) * 4.4
	radius = new_radius
	if col_shape and col_shape.shape is CircleShape2D:
		col_shape.shape.radius = radius
	speed = maxf(40.0, speed * 0.995)  # غول‌ها کمی سنگین‌تر و کندتر می‌شوند

func take_damage(dmg: float) -> void:
	# CRYSTAL_AMOEBA high defense: only a fraction of damage applies
	if not is_inside_tree() or dmg <= 0.0:
		return
	var applied_damage: float = dmg * defense_mult
	if is_boss:
		boss_hp = maxf(0.0, boss_hp - applied_damage)
		var ratio: float = boss_hp / maxf(1.0, boss_max_hp)
		var new_phase: int = 1
		if ratio <= 0.66: new_phase = 2
		if ratio <= 0.33: new_phase = 3
		if new_phase > boss_phase:
			boss_phase = new_phase
			boss_phase_flash = 1.2
			# هر فاز باس واقعاً خطرناک‌تر می‌شود، نه فقط ظاهر متفاوت.
			speed *= 1.16
			flee_speed *= 1.12
			defense_mult = maxf(0.18, defense_mult * 0.86)
			if target_player and is_instance_valid(target_player):
				target_player.spawn_float_text("⚠️ فاز %d باس فعال شد!" % boss_phase, Color(1.0,0.35,0.2), get_parent(), 30)
		boss_hp_changed.emit(boss_hp, boss_max_hp)
		mass = maxf(6.0, 6.0 + boss_hp / 1.7)
	else:
		mass -= applied_damage
	if target_player and is_instance_valid(target_player) and target_player.has_method("heal_from_combat"):
		target_player.heal_from_combat(applied_damage)
	if (boss_hp <= 0.0 if is_boss else mass <= 6.0):
		if is_boss:
			boss_defeated.emit(global_position)
		died.emit(global_position, enemy_type, maxf(mass, 0.0))
		queue_free()

func take_damage_from(dmg: float, from_pos: Vector2) -> void:
	# Same as take_damage but remembers the source for spike logic
	take_damage(dmg)

func handle_player_encounter():
	if not target_player or not target_player.alive:
		return
	# باس‌ها شکار عادی نیستند؛ حتی اگر جرم بازیکن از جرم باس بیشتر باشد،
	# تماس مستقیم نباید باس را یک‌باره بخورد و حذف کند. باس فقط با مهارت‌ها،
	# شاخک‌ها و آسیب‌های واقعی کم‌کم آسیب می‌بیند و در تماس خودش ضربه می‌زند.
	if is_boss:
		var boss_damage: float = maxf(18.0, mass * 0.055)
		var knockback_vector: Vector2 = (target_player.global_position - global_position).normalized() * clampf(mass * 1.35, 320.0, 1100.0)
		target_player.take_damage(boss_damage, global_position)
		target_player.velocity += knockback_vector
		damage_to_player.emit(boss_damage, knockback_vector)
		hit_player.emit(global_position, boss_damage)
		attack_flash_timer = 0.32
		queue_redraw()
		# شاخک/پوست سمی بازیکن همچنان می‌تواند باس را زخمی کند، اما نه با «خوردن» مستقیم.
		if target_player.poison_skin_level > 0:
			var poison_damage: float = (4.0 + 4.0 * float(target_player.poison_skin_level)) * target_player.get_attack_mult()
			take_damage(poison_damage)
			if not is_instance_valid(self) or not is_inside_tree():
				return
		if target_player.has_method("apply_front_spike_hit"):
			target_player.apply_front_spike_hit(global_position, self)
		return
	if target_player.mass > mass * 1.15:
		SoundManager.play_enemy_eat()
		var reward_mass = mass * 0.4
		target_player.add_mass(reward_mass, true)
		target_player.heal_from_combat(mass * 0.4)
		target_player.score += int(mass * 30)
		target_player.score_updated.emit(target_player.score)
		target_player.add_dna(int(mass * 0.2) * dna_multiplier)
		target_player.update_stats()
		target_player.check_evolution()
		died.emit(global_position, enemy_type, mass)
		queue_free()
	elif mass > target_player.mass * 1.15:
		var damage_val: float = maxf(12.0, mass * 0.35)
		var knockback_vector: Vector2 = (target_player.global_position - global_position).normalized() * clampf(mass * 1.2, 260.0, 900.0)
		target_player.take_damage(damage_val, global_position)
		target_player.velocity += knockback_vector
		damage_to_player.emit(damage_val, knockback_vector)
		hit_player.emit(global_position, damage_val)
		attack_flash_timer = 0.28
		queue_redraw()
		# Poison skin damages enemies on contact, independent of the shop poison upgrade.
		if target_player.poison_skin_level > 0:
			var poison_damage: float = (4.0 + 4.0 * float(target_player.poison_skin_level)) * target_player.get_attack_mult()
			take_damage(poison_damage)
			if not is_instance_valid(self) or not is_inside_tree():
				return
		# Enemy bounces slightly after hitting a bigger target
		velocity += (global_position - target_player.global_position).normalized() * 180.0
		# Poison trail upgrade: damages enemies that keep chasing
		if SaveManager.upgrade_poison > 0:
			mass -= SaveManager.upgrade_poison * 2.0 * defense_mult
			if mass <= 6.0:
				died.emit(global_position, enemy_type, mass)
				queue_free()
	else:
		# Similar size: both bounce and take minor scratch damage
		var push_dir = (global_position - target_player.global_position).normalized()
		velocity += push_dir * 220.0
		target_player.velocity -= push_dir * 220.0
		target_player.take_damage(mass * 0.06, global_position)  # minor scratch
		hit_player.emit(global_position, mass * 0.06)
		take_damage(2.0)
		target_player.heal_from_combat(2.0)
	# Evolution spike upgrades: frontal boost / rear counterattack on contact
	if target_player.has_method("apply_front_spike_hit"):
		target_player.apply_front_spike_hit(global_position, self)

func _draw():
	# جهت حرکت واقعی برای چشم/لکه بینایی
	var vel_dir: Vector2 = last_velocity
	if vel_dir.length() < 5.0:
		vel_dir = wander_dir
	if vel_dir.length() > 1.0:
		vel_dir = vel_dir.normalized()
	var vel_ang: float = atan2(vel_dir.y, vel_dir.x)

	# Boss aura and animated tentacles are drawn behind the cell body.
	if is_boss:
		var glow: float = 0.5 + 0.5 * sin(pulse_time * 2.4)
		for ring in range(4):
			draw_circle(Vector2.ZERO, radius * (1.25 + float(ring) * 0.23), Color(0.08, 0.72, 1.0, 0.10 - float(ring) * 0.018 + glow * 0.025))
		for tentacle in range(8):
			var ta: float = TAU * float(tentacle) / 8.0 + sin(pulse_time + float(tentacle)) * 0.08
			var points: PackedVector2Array = PackedVector2Array()
			points.append(Vector2(cos(ta), sin(ta)) * radius * 0.72)
			for segment in range(1, 5):
				var f: float = float(segment) / 4.0
				var bend: float = sin(pulse_time * 2.2 + float(tentacle) * 1.7 + f * 3.0) * radius * 0.10 * f
				points.append(Vector2(cos(ta) * radius * (0.72 + f * 0.60) - sin(ta) * bend, sin(ta) * radius * (0.72 + f * 0.60) + cos(ta) * bend))
			draw_polyline(points, Color(0.12, 0.7, 1.0, 0.65), maxf(2.0, radius * 0.045), true)
		draw_arc(Vector2.ZERO, radius * 1.30, 0.0, TAU, 48, Color(0.25, 0.9, 1.0, 0.65 + glow * 0.3), 4.0, true)
		if boss_phase >= 2:
			draw_arc(Vector2.ZERO, radius * 1.55, pulse_time, pulse_time + PI * 1.6, 42, Color(1.0, 0.35, 0.12, 0.72), 5.0, true)
		if boss_phase >= 3:
			for phase_ring in range(3):
				draw_circle(Vector2.ZERO, radius * (1.65 + phase_ring * 0.16), Color(1.0, 0.08, 0.12, 0.06))
	# ---- لایه ۰: هاله بیرونی نیمه‌شفاف (غشای دوگانه) ----
	var squash: float = 1.0 + sin(pulse_time * 1.7 + wiggle_phase) * 0.05
	var r_x: float = radius * (2.0 - squash)
	var r_y: float = radius * squash
	var r: float = radius * (1.0 + sin(pulse_time) * 0.06)
	var breath: float = 0.5 + 0.5 * sin(pulse_time * 1.3)
	draw_circle(Vector2.ZERO, r * 1.45, Color(membrane_color.r, membrane_color.g, membrane_color.b, 0.06 + 0.03 * breath))
	draw_circle(Vector2.ZERO, r * 1.28, Color(membrane_color.r, membrane_color.g, membrane_color.b, 0.10 + 0.04 * breath))

	var is_hunter_visual: bool = enemy_type == EnemyType.VIRUS_HUNTER or is_event_hunter or event_hunter
	if is_hunter_visual:
		var danger_pulse: float = 0.5 + 0.5 * sin(pulse_time * 5.0)
		for ring_index in range(3):
			draw_arc(Vector2.ZERO, r * (1.18 + float(ring_index) * 0.22), 0.0, TAU, 48, Color(0.95, 0.015, 0.045, 0.28 + danger_pulse * 0.28 - float(ring_index) * 0.04), 2.5 + danger_pulse, true)
		# Sharp alternating crimson spikes around the membrane.
		for spike_index in range(12):
			var spike_angle: float = TAU * float(spike_index) / 12.0 + pulse_time * 0.08
			var spike_root: Vector2 = Vector2(cos(spike_angle), sin(spike_angle)) * r * 0.88
			var spike_tip: Vector2 = Vector2(cos(spike_angle), sin(spike_angle)) * r * (1.22 + 0.08 * sin(pulse_time * 4.0 + float(spike_index)))
			var spike_side: Vector2 = Vector2(-sin(spike_angle), cos(spike_angle)) * r * 0.11
			draw_colored_polygon(PackedVector2Array([spike_tip, spike_root + spike_side, spike_root - spike_side]), Color(0.52, 0.005, 0.035, 0.96))
			draw_line(spike_root, spike_tip, Color(1.0, 0.16, 0.2, 0.95), maxf(1.5, r * 0.025), true)
	# ---- لایه ویژه منطقه: ظاهر دشمن با محیط عوض می‌شود ----
	var rt = 0.5 + 0.5 * sin(pulse_time * 1.6 + wiggle_phase)
	match region_visual_style:
		0: # دشت آرام: هاله‌های نرم و حلقه‌های زیستی
			for i in range(2):
				draw_arc(Vector2.ZERO, r * (1.35 + i * 0.18), 0.0, TAU, 32, Color(region_tint.r, region_tint.g, region_tint.b, 0.18 - i * 0.05), 2.0)
		1: # جنگل زیستی: شاخه/برگ‌های کوچک
			for i in range(6):
				var a = TAU * float(i) / 6.0 + pulse_time * 0.08
				var root = Vector2(cos(a), sin(a)) * r * 0.85
				var tip = Vector2(cos(a), sin(a)) * r * (1.35 + rt * 0.10)
				draw_line(root, tip, Color(region_tint.r, region_tint.g, region_tint.b, 0.45), maxf(2.0, r * 0.035), true)
		2: # منطقه شکار: خارهای قرمز و علامت هشدار
			for i in range(10):
				var a = TAU * float(i) / 10.0 + pulse_time * 0.05
				var root = Vector2(cos(a), sin(a)) * r * 0.92
				var tip = Vector2(cos(a), sin(a)) * r * (1.48 + rt * 0.16)
				draw_colored_polygon(PackedVector2Array([tip, root + root.orthogonal() * r * 0.07, root - root.orthogonal() * r * 0.07]), Color(region_tint.r, region_tint.g, region_tint.b, 0.72))
		3: # خندق تاریک: چشم/حلقه بنفش
			for i in range(3):
				draw_arc(Vector2.ZERO, r * (1.18 + i * 0.22), pulse_time * 0.35 + i, pulse_time * 0.35 + i + 4.5, 28, Color(region_tint.r, region_tint.g, region_tint.b, 0.26 - i * 0.05), 2.5)
		4: # شهر مرجانی: شاخه‌های مرجانی صورتی/نارنجی
			for i in range(5):
				var a = TAU * float(i) / 5.0 + 0.3
				var p1 = Vector2(cos(a), sin(a)) * r * 0.75
				var p2 = Vector2(cos(a), sin(a)) * r * 1.35
				draw_line(p1, p2, Color(region_tint.r, region_tint.g, region_tint.b, 0.50), maxf(2.0, r * 0.04), true)
				draw_circle(p2, r * 0.07, Color(1.0, 0.55, 0.35, 0.65))
		5: # دره کریستالی: تیغه‌های کریستالی آبی
			for i in range(6):
				var a = TAU * float(i) / 6.0 + pulse_time * 0.12
				var rr = r * 1.38
				var tip = Vector2(cos(a), sin(a)) * rr
				var b1 = Vector2(cos(a - 0.12), sin(a - 0.12)) * r * 0.92
				var b2 = Vector2(cos(a + 0.12), sin(a + 0.12)) * r * 0.92
				draw_colored_polygon(PackedVector2Array([tip, b1, b2]), Color(region_tint.r, region_tint.g, region_tint.b, 0.50))
		6: # غار زیستی: لکه‌های نورانی قارچی
			for i in range(7):
				var a = TAU * float(i) / 7.0 + pulse_time * 0.06
				var pp = Vector2(cos(a), sin(a)) * r * 1.12
				draw_circle(pp, r * (0.08 + 0.025 * rt), Color(region_tint.r, region_tint.g, region_tint.b, 0.75))
		7: # آب‌های یخی: بلورهای سفید/آبی
			for i in range(5):
				var a = TAU * float(i) / 5.0 - pulse_time * 0.04
				var pp = Vector2(cos(a), sin(a)) * r * 1.18
				draw_line(pp - pp.normalized() * r * 0.18, pp + pp.normalized() * r * 0.18, Color(0.85, 0.98, 1.0, 0.8), maxf(2.0, r * 0.03), true)

	# نشانگر حالت AI
	if ai_mode == "flee":
		draw_arc(Vector2.ZERO, r + 6.0, 0, TAU, 28, Color(1.0, 0.9, 0.3, 0.7), 2.0, true)
	elif ai_mode == "chase" or ai_mode == "hunt_enemy":
		draw_arc(Vector2.ZERO, r + 6.0, 0, TAU, 28, Color(1.0, 0.25, 0.25, 0.8), 2.5, true)

	draw_circle(Vector2.ZERO, r, base_color)
	draw_circle(Vector2.ZERO, r * 0.92, Color(base_color.r, base_color.g, base_color.b, 0.55))
	draw_circle(Vector2.ZERO, r * 0.8, Color(membrane_color.r, membrane_color.g, membrane_color.b, 0.35))

	# ---- لایه ۲: ارگانل‌های شناور (blob های داخل سیتوپلاسم) ----
	# توجه: rng_o هر فریم باید از ابتدا یکسان تولید کند؛ پس position بازنشانی می‌شود
	organelle_rng.seed = int(organelle_seed * 1000.0)
	var rng_o: RandomNumberGenerator = organelle_rng
	for i in range(7):
		var oa: float = rng_o.randf_range(0.0, TAU) + pulse_time * 0.25 * (1.0 if i % 2 == 0 else -1.0)
		var od: float = r * rng_o.randf_range(0.25, 0.6)
		var orad: float = r * rng_o.randf_range(0.06, 0.14)
		var op: Vector2 = Vector2(cos(oa) * od, sin(oa) * od)
		var ocol: Color = membrane_color.lerp(Color(1, 1, 1), 0.3)
		draw_circle(op, orad * (1.0 + 0.15 * sin(pulse_time * 2.0 + float(i))), Color(ocol.r, ocol.g, ocol.b, 0.30))
		draw_circle(op + Vector2(orad * 0.2, -orad * 0.2), orad * 0.45, Color(1, 1, 1, 0.18))
	# میتوکندری‌های بیضی
	for i in range(3):
		var ma: float = organelle_seed + float(i) * 2.1 + pulse_time * 0.15
		var mp: Vector2 = Vector2(cos(ma) * r * 0.45, sin(ma) * r * 0.45)
		_draw_mito(mp, r * 0.16, ma, membrane_color)

	# ---- لایه ۳: هسته مرکزی تپنده + نوکلئوس ----
	var nuc_r: float = r * 0.34 * (1.0 + sin(pulse_time * 2.2) * 0.09)
	draw_circle(Vector2.ZERO, nuc_r * 1.25, Color(0, 0, 0, 0.15))
	draw_circle(Vector2.ZERO, nuc_r, Color(membrane_color.r * 0.5, membrane_color.g * 0.5, membrane_color.b * 0.5, 0.9))
	draw_circle(Vector2.ZERO, nuc_r * 0.8, Color(base_color.r * 0.7, base_color.g * 0.7, base_color.b * 0.7, 0.95))
	var nc: Vector2 = Vector2(sin(pulse_time * 0.9) * nuc_r * 0.25, cos(pulse_time * 1.1) * nuc_r * 0.25)
	draw_circle(nc, nuc_r * 0.35, Color(1, 1, 1, 0.55))

	# ---- لایه ۴: خال‌ها/رگه‌های منحصر به فرد بدن ----
	spots_rng.seed = int(spots_seed * 100.0)
	var rng_s: RandomNumberGenerator = spots_rng
	for i in range(9):
		var sa: float = rng_s.randf_range(0.0, TAU)
		var sd: float = r * rng_s.randf_range(0.3, 0.85)
		var sr: float = r * rng_s.randf_range(0.03, 0.07)
		draw_circle(Vector2(cos(sa) * sd, sin(sa) * sd), sr, Color(0, 0, 0, 0.12))

	# ---- لایه ۵: چشم/لکه بینایی جهت‌دار به سمت سرعت ----
	var eye_pos: Vector2 = Vector2(cos(vel_ang) * r * 0.5, sin(vel_ang) * r * 0.5)
	var eye_r: float = r * 0.16
	draw_circle(eye_pos, eye_r * 1.35, Color(1, 1, 1, 0.9))
	draw_circle(eye_pos, eye_r, Color(0.05, 0.05, 0.1, 0.95))
	var look: Vector2 = Vector2(cos(vel_ang), sin(vel_ang)) * eye_r * 0.35
	draw_circle(eye_pos + look, eye_r * 0.3, Color(1, 1, 1, 0.85))
	if is_hunter_visual:
		var face_dir: Vector2 = vel_dir
		if target_player and is_instance_valid(target_player):
			face_dir = (target_player.global_position - global_position).normalized()
		var face_perp: Vector2 = face_dir.orthogonal()
		for eye_side in [-1.0, 1.0]:
			var fierce_eye: Vector2 = face_dir * r * 0.32 + face_perp * eye_side * r * 0.22
			draw_circle(fierce_eye, eye_r * 0.95, Color(1.0, 0.55, 0.48, 0.95))
			draw_circle(fierce_eye + face_dir * eye_r * 0.18, eye_r * 0.68, Color(0.9, 0.015, 0.025, 1.0))
			draw_circle(fierce_eye + face_dir * eye_r * 0.35, eye_r * 0.30, Color(0.08, 0.0, 0.01, 1.0))
	if attack_flash_timer > 0.0:
		draw_circle(Vector2.ZERO, r * 1.03, Color(1.0, 0.8, 0.8, attack_flash_timer / 0.28 * 0.55))
	# لکه بینایی دوم برای گونه‌های شکارچی
	if enemy_type == EnemyType.VIRUS_HUNTER or enemy_type == EnemyType.LEVIATHAN_TITAN:
		var e2: Vector2 = eye_pos + Vector2(cos(vel_ang + PI * 0.5), sin(vel_ang + PI * 0.5)) * r * 0.3
		draw_circle(e2, eye_r * 0.8, Color(1, 1, 1, 0.7))
		draw_circle(e2, eye_r * 0.5, Color(0.05, 0.05, 0.1, 0.9))

	match enemy_type:
		EnemyType.AMINO_GRAZER:
			draw_circle(Vector2(-r * 0.3, 0), r * 0.25, Color(0.2, 0.6, 0.3, 0.7))
			draw_circle(Vector2(r * 0.3, 0), r * 0.25, Color(0.2, 0.6, 0.3, 0.7))
		EnemyType.VIRUS_HUNTER:
			draw_circle(Vector2.ZERO, r * 0.4, Color(0.4, 0.0, 0.1, 0.85))
			for i in range(8):
				var ang: float = (float(i) / 8.0) * TAU
				draw_circle(Vector2(cos(ang) * (r + 6.0), sin(ang) * (r + 6.0)), 2.4, Color(1, 0.1, 0.1, 0.85))
		EnemyType.ARMORED_DIATOM:
			pass

		EnemyType.ELECTRIC_JELLY:
			for i in range(5):
				var offset_ang: float = (float(i) - 2.0) * 0.3 + PI * 0.5
				var t2: Vector2 = Vector2(cos(offset_ang) * (r + 12.0 + sin(pulse_time * 6.0 + i) * 4.0), sin(offset_ang) * (r + 22.0))
				draw_circle(t2, 2.4, Color(0.4, 0.8, 1.0, 0.5))
				draw_circle(t2, 1.6, Color(0.6, 1.0, 1.0, 0.7))
			# قوس‌های برقی تپنده
			for i in range(3):
				var ea: float = pulse_time * 2.0 + float(i) * 2.1
				draw_arc(Vector2.ZERO, r * (0.6 + 0.12 * float(i)), ea, ea + 1.6, 12, Color(0.8, 0.95, 1.0, 0.5), 1.5, true)
		EnemyType.LEVIATHAN_TITAN:
			draw_circle(Vector2.ZERO, r * 0.5, Color(0.05, 0.08, 0.2, 0.85))
			for i in range(4):
				var ang: float = (float(i) / 4.0) * TAU + pulse_time * 0.3
				draw_circle(Vector2(cos(ang) * r * 0.35, sin(ang) * r * 0.35), r * 0.18, Color(0.0, 0.8, 0.9, 0.7))
			for i in range(6):
				var ta: float = PI * 0.5 + (float(i) - 2.5) * 0.25
				var s2: Vector2 = Vector2(cos(ta) * (r * 0.9 + sin(pulse_time * 4.0 + i) * 8.0), sin(ta) * (r * 0.9 + 30.0))
				draw_circle(s2, 3.0, Color(0.15, 0.35, 0.7, 0.6))
		EnemyType.ACID_SPITTER:
			var sac: float = r * 0.45 * (1.0 + maxf(0.0, sin((ACID_COOLDOWN - acid_cooldown) * 3.0)) * 0.3)
			draw_circle(Vector2.ZERO, sac, Color(0.55, 1.0, 0.1, 0.9))
			draw_circle(Vector2(sac * 0.3, sac * 0.3), sac * 0.35, Color(0.9, 1.0, 0.5, 0.7))
			for i in range(4):
				var drip: float = fmod(pulse_time * 0.6 + float(i) * 0.25, 1.0)
				var dp: Vector2 = Vector2(r * 0.6, r * 0.4 + drip * r * 0.9)
				draw_circle(dp, 2.5 - drip * 1.5, Color(0.5, 1.0, 0.15, 0.8 - drip * 0.5))
		EnemyType.SWARM_MITE:
			for i in range(6):
				var ang: float = (float(i) / 6.0) * TAU + sin(pulse_time * 8.0) * 0.4
				draw_circle(Vector2(cos(ang) * (r + 5.0), sin(ang) * (r + 5.0)), 1.6, Color(1.0, 0.7, 0.2, 0.85))
			# چشم مایت در همان سیستم جدید (کمی بزرگ‌تر)
			draw_circle(eye_pos, eye_r * 1.6, Color(1, 1, 1, 0.9))
			draw_circle(eye_pos, eye_r * 1.1, Color(0.1, 0.05, 0.0, 0.95))
			draw_circle(eye_pos + look, eye_r * 0.4, Color(1, 1, 1, 0.9))
		EnemyType.CRYSTAL_AMOEBA:
			for i in range(7):
				var ang: float = (float(i) / 7.0) * TAU + pulse_time * 0.25
				var shard_r: float = r * 0.85
				var tip: Vector2 = Vector2(cos(ang) * shard_r, sin(ang) * shard_r)
				var base1: Vector2 = Vector2(cos(ang - 0.25) * shard_r * 0.55, sin(ang - 0.25) * shard_r * 0.55)
				var base2: Vector2 = Vector2(cos(ang + 0.25) * shard_r * 0.55, sin(ang + 0.25) * shard_r * 0.55)
				var tri: PackedVector2Array = PackedVector2Array([tip, base1, base2])
				draw_colored_polygon(tri, Color(0.85, 1.0, 1.0, 0.8))
			draw_circle(Vector2.ZERO, r * 0.4, Color(0.5, 0.95, 1.0, 0.85))
			draw_circle(Vector2.ZERO, r * 0.18, Color(1, 1, 1, 0.8))

func _draw_mito(pos: Vector2, size: float, ang: float, col: Color) -> void:
	var mcol: Color = Color(col.r * 0.7, col.g, col.b * 0.6, 0.45)
	var pts: PackedVector2Array = PackedVector2Array()
	for i in range(10):
		var a: float = (float(i) / 10.0) * TAU
		pts.append(pos + Vector2(cos(a) * size * 1.6, sin(a) * size))
	draw_colored_polygon(pts, mcol)
	for k in range(3):
		var ka: float = ang + float(k) * 0.6
		var p1: Vector2 = pos + Vector2(cos(ka) * size * 0.65, sin(ka) * size * 0.45)
		var p2: Vector2 = pos + Vector2(cos(ka + 0.35) * size * 0.65, sin(ka + 0.35) * size * 0.45)
		draw_line(p1, p2, Color(0.9, 1.0, 0.85, 0.5), 1.2, true)
