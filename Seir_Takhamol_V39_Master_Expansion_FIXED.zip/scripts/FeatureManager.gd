extends Node
## سیستم‌های پیشرفت عمیق «سیر تکامل»: درخت تکامل، کلکسیون، لیگ، داستان، مناطق مخفی و رویدادهای نادر.

signal feature_changed
signal rare_event(text: String)
signal story_completed(title: String, reward: int)

const SAVE_PATH: String = "user://seir_takhamol_features.json"

const SPECIES: Array[Dictionary] = [
	{"id":"amoeba","name":"آمیب نخستین","icon":"🦠","cost":0,"region":"دشت آرام"},
	{"id":"cyan","name":"سیانوباکتری","icon":"🧫","cost":120,"region":"جنگل زیستی"},
	{"id":"jelly","name":"مدوسای برق","icon":"🪼","cost":220,"region":"آب‌های یخی"},
	{"id":"coral","name":"مرجان زنده","icon":"🪸","cost":320,"region":"شهر مرجانی"},
	{"id":"crystal","name":"آمیب کریستالی","icon":"💎","cost":450,"region":"دره کریستالی"},
	{"id":"angler","name":"شکارچی اعماق","icon":"🐟","cost":600,"region":"خندق تاریک"},
	{"id":"ray","name":"پرتوی زیستی","icon":"🪽","cost":780,"region":"خندق تاریک"},
	{"id":"squid","name":"شکارچی مرکبی","icon":"🦑","cost":980,"region":"منطقه شکار"},
	{"id":"octopus","name":"هشت‌پای جهش‌یافته","icon":"🐙","cost":1200,"region":"غار زیستی"},
	{"id":"turtle","name":"لاک‌پشت زرهی","icon":"🐢","cost":1450,"region":"شهر مرجانی"},
	{"id":"shark","name":"کوسه ژنتیکی","icon":"🦈","cost":1750,"region":"منطقه شکار"},
	{"id":"whale","name":"نهنگ کریستالی","icon":"🐋","cost":2100,"region":"آب‌های یخی"},
	{"id":"leviathan","name":"لویاتان","icon":"🐉","cost":2600,"region":"خندق تاریک"},
	{"id":"phoenix","name":"ققنوس سلولی","icon":"🔥","cost":3200,"region":"جنگل زیستی"},
	{"id":"void","name":"موجود خلأ","icon":"🕳️","cost":3900,"region":"خندق تاریک"},
	{"id":"aurora","name":"سلول شفق قطبی","icon":"🌌","cost":4700,"region":"آب‌های یخی"},
	{"id":"prism","name":"موجود منشوری","icon":"🔷","cost":5600,"region":"دره کریستالی"},
	{"id":"fungus","name":"غول قارچی","icon":"🍄","cost":6600,"region":"غار زیستی"},
	{"id":"thorn","name":"خارزیست","icon":"🌵","cost":7800,"region":"جنگل زیستی"},
	{"id":"venom","name":"زهرآمیب","icon":"☣️","cost":9200,"region":"منطقه شکار"},
	{"id":"solar","name":"هسته خورشیدی","icon":"☀️","cost":10800,"region":"دشت آرام"},
	{"id":"moon","name":"هسته ماه","icon":"🌙","cost":12600,"region":"خندق تاریک"},
	{"id":"star","name":"ستاره‌زیست","icon":"⭐","cost":14800,"region":"منطقه مخفی: شکاف ستاره"},
	{"id":"abyss","name":"فرزند ابیس","icon":"👁️","cost":17500,"region":"منطقه مخفی: ابیس"},
	{"id":"dragon","name":"اژدهای سلولی","icon":"🐲","cost":20500,"region":"منطقه مخفی: لانه اژدها"},
	{"id":"titan","name":"تایتان تکامل","icon":"🗿","cost":24000,"region":"منطقه مخفی: هسته باستانی"},
	{"id":"nebula","name":"آمیب سحابی","icon":"🌠","cost":28000,"region":"منطقه مخفی: سحابی"},
	{"id":"quantum","name":"سلول کوانتومی","icon":"⚛️","cost":33000,"region":"منطقه مخفی: شکاف کوانتومی"},
	{"id":"chrono","name":"زمان‌زیست","icon":"⏳","cost":39000,"region":"منطقه مخفی: حلقه زمان"},
	{"id":"eclipse","name":"کسوف‌زیست","icon":"🌑","cost":46000,"region":"منطقه مخفی: کسوف"},
	{"id":"rainbow","name":"هفت‌رنگ","icon":"🌈","cost":54000,"region":"منطقه مخفی: باغ رنگین"},
	{"id":"godcell","name":"سلول الهی","icon":"✨","cost":65000,"region":"منطقه مخفی: تکامل نهایی"},
	{"id":"reaper","name":"دروگر اعماق","icon":"☠️","cost":78000,"region":"منطقه شکار"},
	{"id":"guardian","name":"نگهبان کیهانی","icon":"🛡️","cost":92000,"region":"هسته باستانی"},
	{"id":"emperor","name":"امپراتور زیستی","icon":"👑","cost":110000,"region":"تکامل نهایی"},
	{"id":"singularity","name":"تکینگی","icon":"🌀","cost":135000,"region":"شکاف کوانتومی"},
	{"id":"eternal","name":"جاودانه","icon":"♾️","cost":165000,"region":"حلقه زمان"},
	{"id":"cosmic","name":"موجود کیهانی","icon":"🌌","cost":200000,"region":"سحابی"},
	{"id":"origin","name":"منشأ حیات","icon":"🧬","cost":250000,"region":"تکامل نهایی"},
	{"id":"omega","name":"اُمگا","icon":"Ω","cost":320000,"region":"منطقه مخفی: پایان چرخه"}
]

const STORY: Array[Dictionary] = [
	{"id":"awakening","title":"بیداری حیات","desc":"۵۰ واحد جرم جمع کن و اولین جهش را تجربه کن.","target":50,"kind":"mass","reward":100},
	{"id":"first_hunt","title":"اولین شکار","desc":"۳ دشمن را شکست بده.","target":3,"kind":"enemy","reward":180},
	{"id":"new_world","title":"جهان‌های ناشناخته","desc":"برای اولین بار منطقه عوض شود.","target":1,"kind":"region","reward":250},
	{"id":"boss_trial","title":"آزمون غول‌ها","desc":"یک باس را شکست بده.","target":1,"kind":"boss","reward":450},
	{"id":"collector","title":"کلکسیونر","desc":"۵ موجود قابل باز شدن را کشف کن.","target":5,"kind":"species","reward":600},
	{"id":"secret","title":"دروازه مخفی","desc":"اولین منطقه مخفی را پیدا کن.","target":1,"kind":"secret","reward":1000},
	{"id":"champion","title":"قهرمان لیگ","desc":"به لیگ نخبگان برس.","target":1,"kind":"league","reward":1800}
]

const LEAGUES: Array[String] = ["پلانکتون", "میکرو", "شکارچی", "شکارچی ارشد", "تایتان", "نخبگان", "کیهانی", "اُمگا"]

var player_name: String = ""
var score: int = 0
var bosses_defeated: int = 0
var enemies_defeated: int = 0
var regions_seen: int = 1
var secret_regions_found: int = 0
var rare_events_found: int = 0
var total_survival: float = 0.0
var species_owned: Array = ["amoeba"]
var discovered_species: Array = ["amoeba"]
var active_species: String = "amoeba"
var story_progress: Dictionary = {}
var story_claimed: Dictionary = {}
var secret_regions: Array = []
var last_rare_event_time: float = -9999.0
var rare_event_cooldown: float = 80.0
var boss_stage_cache: Dictionary = {}
var survival_story_mark: int = 0

func _ready() -> void:
	_load()
	for m in STORY:
		var sid: String = str(m["id"])
		if not story_progress.has(sid): story_progress[sid] = 0
		if not story_claimed.has(sid): story_claimed[sid] = false

func _save() -> void:
	var data: Dictionary = {
		"player_name": player_name,
		"score": score,
		"bosses_defeated": bosses_defeated,
		"enemies_defeated": enemies_defeated,
		"regions_seen": regions_seen,
		"secret_regions_found": secret_regions_found,
		"rare_events_found": rare_events_found,
		"total_survival": total_survival,
		"species_owned": species_owned,
		"discovered_species": discovered_species,
		"active_species": active_species,
		"story_progress": story_progress,
		"story_claimed": story_claimed,
		"secret_regions": secret_regions
	}
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))
		f.close()

func _load() -> void:
	if not FileAccess.file_exists(SAVE_PATH): return
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null: return
	var raw: String = f.get_as_text(); f.close()
	var j: JSON = JSON.new()
	if j.parse(raw) != OK or typeof(j.data) != TYPE_DICTIONARY: return
	var d: Dictionary = j.data
	player_name = str(d.get("player_name", ""))
	score = int(d.get("score", 0))
	bosses_defeated = int(d.get("bosses_defeated", 0))
	enemies_defeated = int(d.get("enemies_defeated", 0))
	regions_seen = int(d.get("regions_seen", 1))
	secret_regions_found = int(d.get("secret_regions_found", 0))
	rare_events_found = int(d.get("rare_events_found", 0))
	total_survival = float(d.get("total_survival", 0.0))
	species_owned = d.get("species_owned", ["amoeba"])
	discovered_species = d.get("discovered_species", ["amoeba"])
	active_species = str(d.get("active_species", "amoeba"))
	story_progress = d.get("story_progress", {})
	story_claimed = d.get("story_claimed", {})
	secret_regions = d.get("secret_regions", [])

func get_snapshot() -> Dictionary:
	return {"player_name":player_name,"score":score,"bosses_defeated":bosses_defeated,"enemies_defeated":enemies_defeated,"regions_seen":regions_seen,"secret_regions_found":secret_regions_found,"rare_events_found":rare_events_found,"total_survival":total_survival,"species_owned":species_owned,"discovered_species":discovered_species,"active_species":active_species,"story_progress":story_progress,"story_claimed":story_claimed,"secret_regions":secret_regions}

func apply_snapshot(d: Dictionary) -> void:
	player_name = str(d.get("player_name", player_name))
	score = int(d.get("score", score))
	bosses_defeated = int(d.get("bosses_defeated", bosses_defeated))
	enemies_defeated = int(d.get("enemies_defeated", enemies_defeated))
	regions_seen = int(d.get("regions_seen", regions_seen))
	secret_regions_found = int(d.get("secret_regions_found", secret_regions_found))
	rare_events_found = int(d.get("rare_events_found", rare_events_found))
	total_survival = float(d.get("total_survival", total_survival))
	species_owned = d.get("species_owned", ["amoeba"])
	discovered_species = d.get("discovered_species", ["amoeba"])
	active_species = str(d.get("active_species", "amoeba"))
	story_progress = d.get("story_progress", story_progress)
	story_claimed = d.get("story_claimed", story_claimed)
	secret_regions = d.get("secret_regions", secret_regions)
	_save()
	feature_changed.emit()

func register_mass(amount: float) -> void:
	_add_story("mass", int(amount))
	if amount > 0.0: _maybe_unlock_species()

func register_enemy() -> void:
	enemies_defeated += 1
	_add_story("enemy", 1)
	_maybe_unlock_species()
	_save()

func register_boss() -> void:
	bosses_defeated += 1
	_add_story("boss", 1)
	_maybe_unlock_species()
	_save()

func register_region(region_name: String) -> void:
	regions_seen += 1
	_add_story("region", 1)
	_maybe_find_secret(region_name)
	_maybe_unlock_species()
	_save()

func register_survival(delta: float) -> void:
	total_survival += delta
	var mark: int = int(floor(total_survival / 30.0))
	if mark > survival_story_mark:
		survival_story_mark = mark
		_add_story("survive", 1)

func register_rare_event(title: String) -> void:
	rare_events_found += 1
	_add_story("secret", 1)
	rare_event.emit("✨ اتفاق نادر: " + title)
	_save()

func _add_story(kind: String, amount: int) -> void:
	for m in STORY:
		if str(m["kind"]) != kind: continue
		var sid: String = str(m["id"])
		if bool(story_claimed.get(sid, false)): continue
		var p: int = mini(int(m["target"]), int(story_progress.get(sid, 0)) + amount)
		story_progress[sid] = p
		if p >= int(m["target"]):
			story_claimed[sid] = true
			SaveManager.add_dna(int(m["reward"]))
			story_completed.emit(str(m["title"]), int(m["reward"]))
	_save()

func _maybe_unlock_species() -> void:
	var threshold: int = int(SaveManager.max_level) + bosses_defeated + int(enemies_defeated / 4) + regions_seen
	for i in range(SPECIES.size()):
		var s: Dictionary = SPECIES[i]
		var id: String = str(s["id"])
		if species_owned.has(id): continue
		var needed: int = int(i * 3 + 1)
		if threshold >= needed and (int(s["cost"]) == 0 or SaveManager.total_dna >= int(s["cost"])) and i < 14:
			if not discovered_species.has(id): discovered_species.append(id)
	_save()

func buy_species(id: String) -> bool:
	for s in SPECIES:
		if str(s["id"]) != id: continue
		if species_owned.has(id):
			active_species = id; _save(); return true
		var price: int = int(s["cost"])
		if not SaveManager.spend_dna(price): return false
		species_owned.append(id)
		discovered_species.append(id)
		active_species = id
		_save()
		_add_story("species", 1)
		return true
	return false

func get_league() -> Dictionary:
	var points: int = SaveManager.high_score + bosses_defeated * 800 + enemies_defeated * 20 + regions_seen * 120 + rare_events_found * 500
	var idx: int = clampi(int(points / 2500), 0, LEAGUES.size() - 1)
	if idx >= 5 and not bool(story_claimed.get("champion", false)):
		_add_story("league", 1)
	return {"name":LEAGUES[idx],"index":idx,"points":points,"next":(idx + 1) * 2500}

func _maybe_find_secret(region_name: String) -> void:
	var candidates: Array[String] = []
	if regions_seen >= 3: candidates.append("شکاف ستاره")
	if bosses_defeated >= 2: candidates.append("ابیس")
	if regions_seen >= 5 and bosses_defeated >= 4: candidates.append("لانه اژدها")
	if regions_seen >= 8 and rare_events_found >= 1: candidates.append("هسته باستانی")
	for r in candidates:
		if secret_regions.has(r): continue
		if randf() < 0.28:
			secret_regions.append(r)
			secret_regions_found += 1
			_add_story("secret", 1)
			rare_event.emit("🗺 منطقه مخفی کشف شد: " + r)
			break
	_save()

func maybe_rare_event(run_time: float) -> void:
	if run_time - last_rare_event_time < rare_event_cooldown: return
	if randf() > 0.035: return
	last_rare_event_time = run_time
	var events: Array[String] = ["بارش DNA", "شکارچی طلایی", "گردباد پلانکتونی", "دروازه باستانی", "تخم تکامل کمیاب"]
	register_rare_event(events[randi() % events.size()])
