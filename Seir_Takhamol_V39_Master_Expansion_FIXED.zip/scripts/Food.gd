extends Area2D
# سیر تکامل - غذا/هاگ درخشان: هاگ مرکزی تپنده، هاله بیولومینسنت چندلایه،
# خارهای چرخان، هاگ‌های کوچک مداری و ردپای نوری — همه رویه‌ای و بدون Asset خارجی

enum FoodType { NORMAL, NUTRIENT_HIGH, DNA_SPHERE, TOXIC_BUBBLE }

@export var food_type: FoodType = FoodType.NORMAL

var value: float = 5.0
var dna_value: int = 0
var base_color: Color = Color(0.2, 0.9, 0.4)
var radius: float = 6.0
var pulse_time: float = 0.0
var float_vel: Vector2 = Vector2.ZERO
var consumed: bool = false
var spin: float = 0.0
var spin_speed: float = 1.2
var spikes: int = 7
var spike_len: float = 1.0
var halo_phase: float = 0.0
var orbiters: Array[Dictionary] = []
var trail: Array[Vector2] = []
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
# پالت اختصاصی هر نوع غذا: رنگ اصلی، رنگ هاله و رنگ هسته
var glow_color: Color = Color(0.4, 1.0, 0.6)
var core_color: Color = Color(1, 1, 1)
var toxic_flag: bool = false

func _ready() -> void:
	add_to_group("food")
	body_entered.connect(_on_body_entered)
	rng.randomize()
	float_vel = Vector2(rng.randf_range(-14.0, 14.0), rng.randf_range(-14.0, 14.0))
	setup_type()
	pulse_time = rng.randf_range(0.0, 10.0)
	halo_phase = rng.randf_range(0.0, TAU)
	spin_speed = rng.randf_range(0.6, 2.2) * (1.0 if rng.randf() < 0.5 else -1.0)
	spikes = rng.randi_range(6, 11)
	queue_redraw()  # فقط یک بار در _ready رسم می‌شود
	# هاگ‌های مداری کوچک دور غذا
	var orb_count: int = rng.randi_range(3, 6)
	for i in range(orb_count):
		orbiters.append({
			"ang": rng.randf_range(0.0, TAU),
			"dist": rng.randf_range(radius * 1.7, radius * 2.6),
			"speed": rng.randf_range(1.2, 3.0) * (1.0 if i % 2 == 0 else -1.0),
			"r": rng.randf_range(1.0, 2.4),
			"tilt": rng.randf_range(0.0, TAU),
		})

func _on_body_entered(body: Node2D) -> void:
	if consumed or not is_instance_valid(body) or not body.has_method("eat"):
		return
	consumed = true
	body.eat(self)
	queue_free()

func setup_type() -> void:
	match food_type:
		FoodType.NORMAL:
			value = 4.0
			dna_value = 0
			base_color = Color(0.2, 0.95, 0.45, 0.9)
			glow_color = Color(0.35, 1.0, 0.55)
			core_color = Color(0.85, 1.0, 0.9)
			radius = 6.0
			toxic_flag = false
		FoodType.NUTRIENT_HIGH:
			value = 15.0
			dna_value = 0
			base_color = Color(1.0, 0.8, 0.1, 0.95)
			glow_color = Color(1.0, 0.9, 0.35)
			core_color = Color(1.0, 1.0, 0.85)
			radius = 10.0
			toxic_flag = false
		FoodType.DNA_SPHERE:
			value = 8.0
			dna_value = 2
			base_color = Color(0.8, 0.3, 1.0, 0.95)
			glow_color = Color(0.95, 0.5, 1.0)
			core_color = Color(1.0, 0.9, 1.0)
			radius = 8.0
			toxic_flag = false
		FoodType.TOXIC_BUBBLE:
			value = -10.0
			dna_value = 0
			base_color = Color(0.9, 0.2, 0.2, 0.8)
			glow_color = Color(1.0, 0.35, 0.25)
			core_color = Color(1.0, 0.8, 0.7)
			radius = 7.0
			toxic_flag = true

func _process(delta: float) -> void:
	position += float_vel * delta
	pulse_time += delta * 3.0
	spin += spin_speed * delta
	halo_phase += delta * 2.0
	# پالس با scale (بدون redraw هر فریم)
	scale = Vector2.ONE * (1.0 + sin(pulse_time) * 0.15)

func _draw() -> void:
	var p_scale: float = 1.0 + sin(pulse_time) * 0.15
	var r: float = radius * p_scale
	var breath: float = 0.5 + 0.5 * sin(halo_phase)
	# --- هاله بیولومینسنت چندلایه (بیرونی‌ترین و کم‌رنگ‌ترین) ---
	for layer in range(3):
		var lr: float = r * (2.6 - float(layer) * 0.55) * (1.0 + breath * 0.12)
		var la: float = (0.05 + 0.04 * breath) * (1.0 - float(layer) * 0.3)
		draw_circle(Vector2.ZERO, lr, Color(glow_color.r, glow_color.g, glow_color.b, la))
	# --- پرتوهای نوری کوتاه دور هاگ (شعاع‌های نازک) ---
	var ray_count: int = spikes * 2
	for i in range(ray_count):
		var a: float = float(i) * TAU / float(ray_count) + spin * 0.4
		var ray_len: float = r * (1.5 + 0.5 * sin(pulse_time * 1.7 + float(i) * 1.3))
		var dir_v: Vector2 = Vector2(cos(a), sin(a))
		draw_line(dir_v * r * 1.05, dir_v * ray_len, Color(glow_color.r, glow_color.g, glow_color.b, 0.22 + 0.12 * breath), 1.0, false)
	# --- خارهای چرخان (اسپایک‌های زنده) ---
	for i in range(spikes):
		var a2: float = float(i) * TAU / float(spikes) + spin
		var wob: float = sin(pulse_time * 2.0 + float(i)) * 0.25
		var s_len: float = r * (1.35 + spike_len * 0.5 + wob)
		var d2: Vector2 = Vector2(cos(a2), sin(a2))
		draw_line(d2 * r * 0.9, d2 * s_len, Color(base_color.r, base_color.g, base_color.b, 0.8), 1.6, true)
		draw_circle(d2 * s_len, 1.3, Color(glow_color.r, glow_color.g, glow_color.b, 0.7))
	# --- بدنه اصلی: دایره تیره + بدنه رنگی + حلقه داخلی ---
	draw_circle(Vector2.ZERO, r + 1.2, Color(base_color.r * 0.4, base_color.g * 0.4, base_color.b * 0.4, 0.9))
	draw_circle(Vector2.ZERO, r, base_color)
	draw_arc(Vector2.ZERO, r * 0.72, 0.0, TAU, 24, Color(core_color.r, core_color.g, core_color.b, 0.35), 1.2, true)
	# --- هسته تپنده (بافت بیولومینسنت) ---
	var core_r: float = r * (0.32 + 0.08 * sin(pulse_time * 2.3))
	draw_circle(Vector2.ZERO, core_r, Color(core_color.r, core_color.g, core_color.b, 0.85))
	# هسته دوتایی: نقاط کوچک درون هسته (اندامک‌ها)
	for k in range(3):
		var ka: float = float(k) * TAU / 3.0 + spin * 1.6
		var kp: Vector2 = Vector2(cos(ka), sin(ka)) * core_r * 0.55
		draw_circle(kp, core_r * 0.3, Color(1.0, 1.0, 1.0, 0.55))
	# --- نوار DNA پیچانی (فقط برای DNA_SPHERE و NUTRIENT_HIGH) ---
	if food_type == FoodType.DNA_SPHERE or food_type == FoodType.NUTRIENT_HIGH:
		for s in range(14):
			var t: float = float(s) / 13.0
			var sa: float = t * TAU * 1.5 + spin
			var sp: Vector2 = Vector2(cos(sa), sin(sa) * 0.5 - 0.5) * r * 0.5
			draw_circle(sp, 1.0, Color(core_color.r, core_color.g, core_color.b, 0.3 + 0.4 * t))
	# --- هاگ‌های مداری کوچک ---
	for o in orbiters:
		o.ang += o.speed * get_process_delta_time() * 0.4
		var oa: float = o.ang + sin(halo_phase + o.tilt) * 0.3
		var od: Vector2 = Vector2(cos(oa) * cos(o.tilt), sin(oa)) * o.dist
		var oo: float = 0.5 + 0.5 * sin(halo_phase * 1.3 + o.tilt)
		draw_circle(od, o.r * (1.0 + oo * 0.5), Color(glow_color.r, glow_color.g, glow_color.b, 0.35 + 0.3 * oo))
		draw_circle(od, o.r * 0.5, Color(1.0, 1.0, 1.0, 0.4 * oo))
	# --- حباب داخل هاگ سمی (نشانه خطر) ---
	if toxic_flag:
		var bub_r: float = r * (0.45 + 0.1 * sin(pulse_time * 4.0))
		draw_arc(Vector2(0, -r * 0.1), bub_r, 0.0, TAU, 20, Color(1.0, 0.6, 0.5, 0.8), 1.4, true)
		draw_circle(Vector2(-bub_r * 0.35, -bub_r * 0.45), bub_r * 0.3, Color(1.0, 1.0, 1.0, 0.75))
		# علامت ضربدر هشدار
		var w: float = r * 0.3
		draw_line(Vector2(-w, -w * 0.6), Vector2(w, w * 1.4), Color(1.0, 0.35, 0.2, 0.85), 1.4, true)
		draw_line(Vector2(w, -w * 0.6), Vector2(-w, w * 1.4), Color(1.0, 0.35, 0.2, 0.85), 1.4, true)
