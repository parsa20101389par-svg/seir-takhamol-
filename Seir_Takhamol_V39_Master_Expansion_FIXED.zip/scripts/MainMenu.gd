extends Control
# سیر تکامل - منوی اصلی
# Author: Code Interpreter build

@onready var play_btn: Button = %PlayButton if find_child("PlayButton") else find_child("PlayButton")
@onready var howto_panel: PanelContainer = find_child("HowToPanel")
@onready var settings_panel: PanelContainer = find_child("SettingsPanel")
@onready var shop_panel: PanelContainer = find_child("ShopPanel")
@onready var overlay_dim: ColorRect = find_child("OverlayDim")
@onready var shop_list: VBoxContainer = find_child("ShopList")
@onready var shop_dna: Label = find_child("ShopDNA")
@onready var sound_check: CheckButton = find_child("SoundCheck")
@onready var music_check: CheckButton = find_child("MusicCheck")
@onready var stats_bar: PanelContainer = find_child("StatsBar")
var daily_panel: PanelContainer = null
var daily_list: VBoxContainer = null
var daily_claim_button: Button = null
var weekly_panel: PanelContainer = null

const UPGRADES: Array = [
	{"key": "upgrade_speed",   "name": "سرعت شنا",        "icon": "🚀", "max": 15, "cost": 18},
	{"key": "upgrade_attract", "name": "آهنربای غذا",     "icon": "🧲", "max": 15, "cost": 18},
	{"key": "upgrade_defense", "name": "پوسته محافظ",     "icon": "🛡", "max": 15, "cost": 22},
	{"key": "upgrade_spike",   "name": "تیغه‌های تهاجمی",  "icon": "🗡", "max": 12, "cost": 30},
	{"key": "upgrade_regen",   "name": "ترمیم خودکار",     "icon": "💚", "max": 12, "cost": 28},
	{"key": "upgrade_poison",  "name": "ردپای سمی",       "icon": "☠", "max": 12, "cost": 36},
	{"key": "upgrade_dna_boost","name": "شتاب‌دهنده ژنتیک", "icon": "🧬", "max": 12, "cost": 45},
	{"key": "upgrade_glow",    "name": "درخشش زیستی",     "icon": "✨", "max": 10, "cost": 30},
]

const EVOLUTION_SKINS: Array[Dictionary] = [
	{"name":"هسته کلاسیک","icon":"🧬","price":80,"color":"#49e6d6","desc":"ظاهر پایه با هاله زیستی"},
	{"name":"شعله‌ای","icon":"🔥","price":180,"color":"#ff5a24","desc":"رگه‌های شعله‌ای متحرک"},
	{"name":"کریستالی","icon":"💎","price":300,"color":"#5ed9ff","desc":"تیغه‌های کریستالی اطراف سلول"},
	{"name":"سمی","icon":"☢️","price":450,"color":"#71ff4d","desc":"درخشش سمی سبز"},
	{"name":"بنفش عمیق","icon":"🟣","price":650,"color":"#a15cff","desc":"هاله بنفش و ذرات انرژی"},
	{"name":"طلایی","icon":"👑","price":900,"color":"#ffd34d","desc":"حلقه طلایی ویژه"},
	{"name":"مرجانی","icon":"🪸","price":1200,"color":"#ff5b91","desc":"ظاهر مرجانی با برجستگی‌های کوچک"},
	{"name":"یخی","icon":"❄️","price":1550,"color":"#9cefff","desc":"دو حلقه یخی متحرک"},
	{"name":"کهکشانی","icon":"🌌","price":2000,"color":"#8b5cff","desc":"ستاره‌های چرخان روی سلول"},
	{"name":"رادیواکتیو","icon":"☣️","price":2600,"color":"#9dff22","desc":"رگه‌های انرژی سمی"},
	{"name":"تاریک","icon":"🌑","price":3400,"color":"#6d45ff","desc":"هاله تاریک با حلقه بنفش"},
	{"name":"مرواریدی","icon":"🫧","price":4500,"color":"#e6f2ff","desc":"پوسته مرواریدی بسیار کمیاب"}
]

const LAB_OPTIONS: Array = [
	["🦔", "شاخک جلو", "تقویت حمله جلویی و ضدحمله"], ["🗡", "شاخک عقب", "ضربه متقابل از پشت"],
	["⚔", "ارتقا حمله", "افزایش مستقیم آسیب"], ["❤", "ارتقا سلامت", "دوام و سلامت بیشتر"],
	["💨", "ارتقا سرعت", "حرکت و بوست سریع‌تر"], ["🧲", "آهنربا", "جذب غذا از فاصله بیشتر"],
	["🌿", "ترمیم خودکار", "بازسازی جرم در طول زمان"], ["🧬", "ضریب DNA", "افزایش کنترل‌شده پاداش DNA"],
	["💥", "موج شوک", "توانایی فعال برای دفع دشمنان"], ["🛡", "سپر حبابی", "دفاع فعال کوتاه‌مدت"],
	["☠", "پوست سمی", "آسیب هنگام تماس"], ["🧛", "خون‌آشامی", "ترمیم هنگام مبارزه"],
	["⏳", "اعوجاج زمان", "کندکردن دشمنان نزدیک"], ["🛡️", "زره سلولی", "کاهش آسیب دریافتی"],
	["🔥", "سوخت‌وساز", "رشد بهتر از غذا"], ["🌵", "خارهای سمی", "بازتاب آسیب"],
	["⚡", "شتاب تکاملی", "سرعت پایه بیشتر"], ["💚", "حیات بیشتر", "سلامت و ترمیم بیشتر"],
	["🦷", "شکارچی", "قدرت بیشتر مقابل دشمنان"], ["🌀", "جذب زیستی", "شعاع جذب بالاتر"],
	["🧬", "سازگاری", "تقویت متعادل چند ویژگی"],
	["🎯", "هسته بحرانی", "شانس ضربه قدرتمند بیشتر"], ["🫧", "رشد سلولی", "جرم بیشتر از غذا"],
	["⚡", "باتری زیستی", "بوست طولانی‌تر"], ["🔥", "استاد کمبو", "کمبوی طولانی‌تر و پاداش بهتر"],
	["🧿", "مقاومت شکارچی", "آسیب کمتر از شکارچیان"], ["🦈", "غریزه شکار", "آسیب بیشتر به شکارچیان"],
	["🍀", "شانس زیستی", "غنیمت و پاورآپ بهتر"], ["🔵", "پالس زیستی", "مهارت‌های فعال قوی‌تر"],
	["🧿", "هسته غول‌آسا", "رشد بدنی بیشتر"], ["🌌", "سازگاری عمیق", "تقویت همزمان چند ویژگی"],
	["🧪", "آنزیم تکامل", "هزینه جهش‌های بعدی را کمی کاهش می‌دهد"], ["🌊", "شناگر عمیق", "در نواحی خطرناک سرعت بیشتری می‌گیری"],
	["🫀", "قلب دوم", "یک بار در هر نبرد مرگبار، بخشی از سلامت حفظ می‌شود"], ["🧠", "هوش سلولی", "هشدار زودتر برای باس و شکارچیان"],
	["🧿", "چشم اعماق", "گنج‌ها و پاورآپ‌ها از فاصله بیشتری دیده می‌شوند"], ["🧬", "بازنویسی ژن", "هر چند سطح یک پاداش کوچک تصادفی می‌دهد"],
	["🌟", "پالس ستاره‌ای", "کمبوها مدت بیشتری حفظ می‌شوند"], ["☄", "جهش نهایی", "تقویت بزرگ اما بسیار گران در سطوح بالا"],
]

func _ready() -> void:
	find_child("PlayButton").pressed.connect(_on_play)
	find_child("HowToButton").pressed.connect(func(): _show_overlay(howto_panel))
	find_child("SettingsButton").pressed.connect(func(): _show_overlay(settings_panel))
	find_child("ShopButton").pressed.connect(_on_evolution_lab)
	find_child("QuitButton").pressed.connect(_on_quit)
	find_child("HowToClose").pressed.connect(_close_overlays)
	find_child("SettingsClose").pressed.connect(_close_overlays)
	find_child("ShopClose").pressed.connect(_close_overlays)
	find_child("ResetButton").pressed.connect(_on_reset)
	sound_check.toggled.connect(_on_sound_toggled)
	music_check.toggled.connect(_on_music_toggled)
	sound_check.button_pressed = SaveManager.sound_enabled
	music_check.button_pressed = SaveManager.music_enabled
	refresh_stats()
	_create_daily_reward_button()
	_create_weekly_challenges_button()
	_sync_profile()
	_create_masterpiece_buttons()
	if SaveManager.player_name.strip_edges().is_empty():
		_create_name_gate()
	_create_account_button()
	# Enlarge guide text at runtime too (works even if theme overrides change)
	var howto_body = find_child("HowToBody")
	if howto_body:
		howto_body.add_theme_font_size_override("normal_font_size", 30)
		howto_body.add_theme_font_size_override("bold_font_size", 32)
	var howto_title = find_child("HowToTitle")
	if howto_title:
		howto_title.add_theme_font_size_override("font_size", 36)

func _create_evolution_lab_button() -> void:
	var vbox: VBoxContainer = find_child("VBox")
	var shop_button: Button = find_child("ShopButton")
	if vbox == null or shop_button == null:
		return
	var lab_button: Button = shop_button.duplicate() as Button
	lab_button.name = "EvolutionLabButton"
	lab_button.text = "🧪 آزمایشگاه تکامل"
	vbox.add_child(lab_button)
	vbox.move_child(lab_button, shop_button.get_index() + 1)
	lab_button.pressed.connect(_on_evolution_lab)

func _on_evolution_lab() -> void:
	# منوی «آزمایشگاه تکامل» حالا واقعاً شامل شاخه‌های تکامل + ارتقاهای دائمی است.
	var panel: PanelContainer = shop_panel
	var title: Label = panel.find_child("ShopTitle", true, false)
	var dna: Label = panel.find_child("ShopDNA", true, false)
	var list: VBoxContainer = panel.find_child("ShopList", true, false)
	var close: Button = panel.find_child("ShopClose", true, false)
	if title: title.text = "🧪 آزمایشگاه تکامل — ۳۸ شاخه ژنتیکی"
	if dna: dna.text = "🧬 DNA موجود: %d   |   هر شاخه تکامل: سطح ۰ تا ۱۵" % SaveManager.total_dna
	if close:
		close.text = "بستن آزمایشگاه"
		if not close.pressed.is_connected(_close_overlays):
			close.pressed.connect(_close_overlays)
	if list:
		# ۳۸ شاخه + ارتقاهای دائمی روی موبایل داخل اسکرول قرار می‌گیرند.
		if list.get_parent() == panel.find_child("VBox", true, false):
			var parent_box: VBoxContainer = list.get_parent() as VBoxContainer
			var scroll: ScrollContainer = parent_box.find_child("EvolutionScroll", false, false) as ScrollContainer
			if scroll == null:
				scroll = ScrollContainer.new()
				scroll.name = "EvolutionScroll"
				scroll.custom_minimum_size = Vector2(0, 520)
				scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
				scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				scroll.mouse_filter = Control.MOUSE_FILTER_STOP
				scroll.scroll_deadzone = 12
				scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
				scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
				parent_box.add_child(scroll)
				list.reparent(scroll)
				parent_box.move_child(scroll, close.get_index())
		for child in list.get_children():
			child.queue_free()
		var intro: Label = Label.new()
		intro.text = "هر بار که در بازی به سطح جدید می‌رسی، ۵ جهش از این آزمایشگاه به‌صورت تصادفی پیشنهاد می‌شود. انتخاب‌ها در همان دور تا سطح ۱۵ قابل انباشته شدن هستند. علاوه بر آن، رویدادها، شکار گنج، مأموریت‌های زنجیره‌ای و جایزه روزانه برای تنوع بیشتر فعال هستند."
		intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		intro.add_theme_font_size_override("font_size", 27)
		intro.add_theme_color_override("font_color", Color("#7fffe8"))
		intro.custom_minimum_size = Vector2(0, 80)
		list.add_child(intro)
		var skin_title: Label = Label.new()
		skin_title.text = "🎨 فروشگاه اسکیل پلیر — ظاهر سلول"
		skin_title.add_theme_font_size_override("font_size", 40)
		skin_title.add_theme_color_override("font_color", Color("#ffe66d"))
		list.add_child(skin_title)
		var skin_info: Label = Label.new()
		skin_info.text = "هر اسکیل ظاهر و رنگ مخصوص دارد. با تغییر منطقه، رنگ غالب اسکیل هم با حال‌وهوای همان منطقه هماهنگ می‌شود."
		skin_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		skin_info.add_theme_font_size_override("font_size", 26)
		skin_info.add_theme_color_override("font_color", Color("#bdeff0"))
		list.add_child(skin_info)
		for skin in EVOLUTION_SKINS:
			list.add_child(_make_skin_row(skin))
		var skin_sep: HSeparator = HSeparator.new()
		list.add_child(skin_sep)
		for item in LAB_OPTIONS:
			var row: Label = Label.new()
			row.text = "%s  %s  •  حداکثر سطح ۱۵\n%s" % [item[0], item[1], item[2]]
			row.custom_minimum_size = Vector2(0, 68)
			row.add_theme_font_size_override("font_size", 30)
			row.add_theme_color_override("font_color", Color("#caf0f8"))
			row.add_theme_color_override("font_outline_color", Color("#06233a"))
			row.add_theme_constant_override("outline_size", 2)
			row.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			list.add_child(row)
		var sep: HSeparator = HSeparator.new()
		list.add_child(sep)
		var shop_title: Label = Label.new()
		shop_title.text = "💠 ارتقاهای دائمی با DNA"
		shop_title.add_theme_font_size_override("font_size", 40)
		shop_title.add_theme_color_override("font_color", Color("#ffe66d"))
		list.add_child(shop_title)
		for u in UPGRADES:
			list.add_child(_make_upgrade_row(u))

	panel.visible = true
	overlay_dim.visible = true
	_animate_overlay_open(panel)

func _make_skin_row(skin: Dictionary) -> Button:
	var b = Button.new()
	b.custom_minimum_size = Vector2(0, 82)
	b.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	b.add_theme_font_size_override("font_size", 22)
	var idx = EVOLUTION_SKINS.find(skin)
	var selected = SaveManager.evolution_skin == idx
	var owned = SaveManager.owned_evolution_skins.has(idx)
	var price = int(skin["price"])
	if selected:
		b.text = "%s  %s  ✓ فعال\n%s" % [skin["icon"], skin["name"], skin["desc"]]
	elif owned:
		b.text = "%s  %s  • انتخاب\n%s" % [skin["icon"], skin["name"], skin["desc"]]
	else:
		b.text = "%s  %s  • 🔒 %d DNA\n%s" % [skin["icon"], skin["name"], price, skin["desc"]]
	var normal = StyleBoxFlat.new()
	normal.bg_color = Color("#071a2a")
	normal.border_color = Color(str(skin["color"]), 0.65)
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(16)
	var hover = normal.duplicate()
	hover.bg_color = Color("#10324a")
	hover.border_color = Color(str(skin["color"]), 1.0)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", hover)
	b.add_theme_color_override("font_color", Color("#e9fbff"))
	b.pressed.connect(func(): _buy_or_select_skin(idx))
	return b

func _buy_or_select_skin(idx: int) -> void:
	if SaveManager.owned_evolution_skins.has(idx):
		SaveManager.evolution_skin = idx
		SaveManager.save_game()
		_on_evolution_lab()
		return
	var price = int(EVOLUTION_SKINS[idx]["price"])
	if not SaveManager.spend_dna(price):
		show_message("🧬 DNA کافی نیست — این اسکیل کمیاب است!")
		return
	SaveManager.owned_evolution_skins.append(idx)
	SaveManager.evolution_skin = idx
	SaveManager.save_game()
	show_message("✨ اسکیل «%s» فعال شد!" % EVOLUTION_SKINS[idx]["name"])
	refresh_stats()
	_on_evolution_lab()

func show_message(msg: String) -> void:
	var toast = Label.new()
	toast.text = msg
	toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast.add_theme_font_size_override("font_size", 24)
	toast.add_theme_color_override("font_color", Color("#7fffe8"))
	toast.position = Vector2(40, 120)
	toast.size = Vector2(800, 70)
	toast.z_index = 500
	add_child(toast)
	var tw = create_tween()
	tw.tween_interval(1.6)
	tw.tween_property(toast, "modulate:a", 0.0, 0.4)
	tw.tween_callback(toast.queue_free)

func _make_menu_button(source: Button, name: String, text: String) -> Button:
	var b = source.duplicate() as Button
	b.name = name
	b.text = text
	b.custom_minimum_size = Vector2(0, 64)
	b.add_theme_font_size_override("font_size", 24)
	return b

func _build_modal(panel_name: String, rect: Rect2) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.name = panel_name
	panel.anchor_left = rect.position.x
	panel.anchor_top = rect.position.y
	panel.anchor_right = rect.size.x
	panel.anchor_bottom = rect.size.y
	panel.offset_left = 0.0
	panel.offset_top = 0.0
	panel.offset_right = 0.0
	panel.offset_bottom = 0.0
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical = Control.GROW_DIRECTION_BOTH
	panel.z_index = 450
	panel.mouse_filter = Control.MOUSE_FILTER_STOP

	var style := StyleBoxFlat.new()
	style.bg_color = Color("061a2df5")
	style.border_color = Color("35dbe7")
	style.set_border_width_all(3)
	style.set_corner_radius_all(24)
	style.shadow_color = Color(0.0, 0.8, 0.9, 0.30)
	style.shadow_size = 18
	panel.add_theme_stylebox_override("panel", style)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_bottom", 20)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.name = "VBox"
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 12)
	margin.add_child(box)
	return panel

func _create_daily_reward_button() -> void:
	var vbox: VBoxContainer = find_child("VBox")
	var source: Button = find_child("ShopButton")
	if vbox == null or source == null or find_child("DailyRewardButton", true, false) != null:
		return
	var b = _make_menu_button(source, "DailyRewardButton", "🎁 پاداش روزانه")
	vbox.add_child(b)
	b.pressed.connect(_open_daily_rewards)
	_update_daily_button(b)

func _update_daily_button(b: Button) -> void:
	if not is_instance_valid(b): return
	b.text = "🎁 پاداش روزانه  |  %s" % ("آماده دریافت" if SaveManager.can_claim_daily() else "دریافت‌شده امروز")

func _open_daily_rewards() -> void:
	if is_instance_valid(daily_panel):
		_update_daily_panel()
		_show_overlay(daily_panel)
		return
	daily_panel = _build_modal("DailyRewardPanel", Rect2(Vector2(0.055, 0.06), Vector2(0.945, 0.95)))
	var box = daily_panel.get_child(0).get_child(0) as VBoxContainer
	box.add_theme_constant_override("separation", 12)
	var title = Label.new()
	title.text = "🎁 پاداش روزانه — زنجیره ۱۴ روزه"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color("#4deeea"))
	title.add_theme_color_override("font_outline_color", Color("#032235"))
	title.add_theme_constant_override("outline_size", 4)
	box.add_child(title)
	var info = Label.new()
	info.name = "DailyInfo"
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.add_theme_font_size_override("font_size", 25)
	info.add_theme_color_override("font_color", Color("#caf0f8"))
	info.custom_minimum_size = Vector2(0, 78)
	box.add_child(info)
	var scroll = ScrollContainer.new()
	scroll.name = "DailyScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 430)
	scroll.mouse_filter = Control.MOUSE_FILTER_STOP
	scroll.scroll_deadzone = 12
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	box.add_child(scroll)
	daily_list = VBoxContainer.new()
	daily_list.name = "DailyList"
	daily_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	daily_list.add_theme_constant_override("separation", 9)
	scroll.add_child(daily_list)
	daily_claim_button = _make_menu_button(find_child("ShopButton"), "DailyClaimButton", "🎁 دریافت امروز")
	daily_claim_button.custom_minimum_size = Vector2(0, 72)
	daily_claim_button.add_theme_font_size_override("font_size", 27)
	box.add_child(daily_claim_button)
	daily_claim_button.pressed.connect(_claim_daily_reward)
	var close = Button.new()
	close.text = "بستن"
	close.custom_minimum_size = Vector2(0, 64)
	close.add_theme_font_size_override("font_size", 25)
	box.add_child(close)
	close.pressed.connect(_close_overlays)
	find_child("OverlayLayer").add_child(daily_panel)
	_update_daily_panel()
	_show_overlay(daily_panel)

func _update_daily_panel() -> void:
	if not is_instance_valid(daily_panel) or not is_instance_valid(daily_list): return
	var current = SaveManager.daily_day_index()
	var claimed_today = not SaveManager.can_claim_daily()
	var shown_day = (current - 1 + SaveManager.DAILY_REWARDS.size()) % SaveManager.DAILY_REWARDS.size() if claimed_today else current
	for c in daily_list.get_children(): c.queue_free()
	for i in range(SaveManager.DAILY_REWARDS.size()):
		var reward = SaveManager.daily_reward_for_day(i)
		var is_today = i == current and not claimed_today
		var is_claimed = (claimed_today and i == shown_day) or (not claimed_today and i < current)
		var is_next = i == ((shown_day + 1) % SaveManager.DAILY_REWARDS.size())
		var state = "✓ دریافت شد" if is_claimed else ("🎁 امروز" if is_today else ("⏳ بعدی" if is_next else "🔒 قفل"))
		var card = PanelContainer.new()
		card.custom_minimum_size = Vector2(0, 72)
		var style = StyleBoxFlat.new()
		style.bg_color = Color("#12304a") if is_today else Color("#071d31")
		style.border_color = Color("#4deeea", 0.9 if is_today else 0.35)
		style.set_border_width_all(2 if is_today else 1)
		style.set_corner_radius_all(14)
		card.add_theme_stylebox_override("panel", style)
		var row = Label.new()
		row.text = "روز %02d    🧬 %d DNA    •    %s" % [i + 1, reward, state]
		row.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		row.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		row.add_theme_font_size_override("font_size", 29)
		row.add_theme_color_override("font_color", Color("#ffe66d") if is_today else Color("#d9f7ff"))
		row.add_theme_color_override("font_outline_color", Color("#02131f"))
		row.add_theme_constant_override("outline_size", 3)
		card.add_child(row)
		daily_list.add_child(card)
	var info: Label = daily_panel.find_child("DailyInfo", true, false)
	if info:
		info.text = "هر روز یک جایزه بگیر و زنجیره را حفظ کن.\nروز ۷ یک جهش بزرگ دارد و روز ۱۴ جایزه ویژه پایان زنجیره را می‌دهد.\nاگر یک روز کامل جا بیفتد، زنجیره از روز اول شروع می‌شود."
	if is_instance_valid(daily_claim_button):
		daily_claim_button.disabled = not SaveManager.can_claim_daily()
		daily_claim_button.text = "🎁 دریافت جایزه روز %d" % (current + 1) if SaveManager.can_claim_daily() else "✓ جایزه امروز دریافت شده"

func _claim_daily_reward() -> void:
	var reward: int = SaveManager.claim_daily_reward()
	if reward > 0:
		refresh_stats()
		var b = find_child("DailyRewardButton", true, false)
		if b: _update_daily_button(b)
		_update_daily_panel()
		SoundManager.play_eat_dna()

func _create_weekly_challenges_button() -> void:
	var vbox: VBoxContainer = find_child("VBox")
	var source: Button = find_child("ShopButton")
	if vbox == null or source == null or find_child("WeeklyChallengesButton", true, false) != null: return
	var b = _make_menu_button(source, "WeeklyChallengesButton", "🏆 چالش‌های هفتگی")
	vbox.add_child(b)
	b.pressed.connect(_open_weekly_challenges)

func _open_weekly_challenges() -> void:
	if is_instance_valid(weekly_panel):
		_update_weekly_panel(); _show_overlay(weekly_panel); return
	weekly_panel = _build_modal("WeeklyChallengesPanel", Rect2(Vector2(0.055, 0.06), Vector2(0.945, 0.95)))
	var box = weekly_panel.get_child(0).get_child(0) as VBoxContainer
	box.add_theme_constant_override("separation", 12)
	var title = Label.new()
	title.text = "🏆 چالش‌های هفتگی — ۹ مأموریت"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color("#4deeea"))
	title.add_theme_color_override("font_outline_color", Color("#032235"))
	title.add_theme_constant_override("outline_size", 4)
	box.add_child(title)
	var info = Label.new()
	info.name = "WeeklyInfo"
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.add_theme_font_size_override("font_size", 25)
	info.add_theme_color_override("font_color", Color("#caf0f8"))
	info.custom_minimum_size = Vector2(0, 66)
	box.add_child(info)
	var scroll = ScrollContainer.new()
	scroll.name = "WeeklyScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 520)
	scroll.mouse_filter = Control.MOUSE_FILTER_STOP
	scroll.scroll_deadzone = 12
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	box.add_child(scroll)
	var list = VBoxContainer.new()
	list.name = "WeeklyList"
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 10)
	scroll.add_child(list)
	var footer = Label.new()
	footer.name = "WeeklyFooter"
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	footer.add_theme_font_size_override("font_size", 24)
	footer.add_theme_color_override("font_color", Color("#7fffe8"))
	footer.custom_minimum_size = Vector2(0, 58)
	box.add_child(footer)
	var close = Button.new()
	close.text = "بستن"
	close.custom_minimum_size = Vector2(0, 64)
	close.add_theme_font_size_override("font_size", 25)
	box.add_child(close)
	close.pressed.connect(_close_overlays)
	find_child("OverlayLayer").add_child(weekly_panel)
	_update_weekly_panel()
	_show_overlay(weekly_panel)

func _update_weekly_panel() -> void:
	if not is_instance_valid(weekly_panel): return
	SaveManager.ensure_weekly_reset()
	var list: VBoxContainer = weekly_panel.find_child("WeeklyList", true, false)
	if not list: return
	for c in list.get_children(): c.queue_free()
	var total_reward := 0
	for mission in SaveManager.WEEKLY_MISSIONS:
		total_reward += int(mission["reward"])
		var kind := str(mission["kind"])
		var target := int(mission["target"])
		var cur = mini(int(SaveManager.weekly_progress.get(kind, 0)), target)
		var done = bool(SaveManager.weekly_milestone_claimed.get(str(mission["id"]), false))
		var percent := int(round(float(cur) * 100.0 / float(maxi(target, 1))))
		var card = PanelContainer.new()
		card.custom_minimum_size = Vector2(0, 94)
		var style = StyleBoxFlat.new()
		style.bg_color = Color("#12304a") if done else Color("#071d31")
		style.border_color = Color("#ffe66d", 0.95 if done else 0.28)
		style.set_border_width_all(2 if done else 1)
		style.set_corner_radius_all(14)
		card.add_theme_stylebox_override("panel", style)
		var l = Label.new()
		var mark = "✓ کامل شد" if done else "%d%%" % percent
		l.text = "%s    •    %s\n%d / %d    •    +%d DNA    •    %s" % [str(mission["title"]), str(mission["desc"]), cur, target, int(mission["reward"]), mark]
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.add_theme_font_size_override("font_size", 27)
		l.add_theme_color_override("font_color", Color("#ffe66d") if done else Color("#f2fbff"))
		l.add_theme_color_override("font_outline_color", Color("#02131f"))
		l.add_theme_constant_override("outline_size", 3)
		card.add_child(l)
		list.add_child(card)
	var info: Label = weekly_panel.find_child("WeeklyInfo", true, false)
	if info:
		info.text = "این هفته ۹ مأموریت داری؛ با جمع‌آوری غذا، شکست دشمنان و زنده‌ماندن پیشرفت می‌کنی.\nپاداش هر مرحله خودکار به DNA اضافه می‌شود. مجموع پاداش کامل این صفحه: %d DNA" % total_reward
	var footer: Label = weekly_panel.find_child("WeeklyFooter", true, false)
	if footer:
		footer.text = "🔥 چالش‌ها سخت‌تر می‌شوند اما پاداش‌ها هم بیشتر می‌شوند؛ هفته بعد همه از نو شروع می‌شوند."

func refresh_stats() -> void:
	find_child("HighScoreLabel").text = "🏆 رکورد: %d" % SaveManager.high_score
	find_child("MaxLevelLabel").text = "⭐ بالاترین سطح: %d" % SaveManager.max_level
	find_child("DNALabel").text = "🧬 DNA: %d" % SaveManager.total_dna
	shop_dna.text = "DNA موجود: %d" % SaveManager.total_dna

func _on_play() -> void:
	_sync_profile()
	if SaveManager.player_name.strip_edges().is_empty():
		_create_name_gate()
		return
	SoundManager.play_boost()
	get_tree().change_scene_to_file("res://scenes/World.tscn")

func _sync_profile() -> void:
	if FeatureManager.player_name.strip_edges().is_empty() and not SaveManager.player_name.strip_edges().is_empty():
		FeatureManager.player_name = SaveManager.player_name
	elif not FeatureManager.player_name.strip_edges().is_empty():
		SaveManager.player_name = FeatureManager.player_name

func _make_feature_panel(title_text: String) -> PanelContainer:
	var panel: PanelContainer = PanelContainer.new()
	panel.name = "FeaturePanel"
	# پنل کاملاً واکنش‌گراست تا روی موبایل از صفحه بیرون نزند.
	var vp: Vector2 = get_viewport_rect().size
	var panel_w: float = min(1140.0, max(320.0, vp.x - 40.0))
	var panel_h: float = min(1050.0, max(360.0, vp.y - 180.0))
	# پنل روی مرکز واقعی viewport قفل می‌شود. قبلاً هم anchor مرکز و هم position
	# شامل نصف viewport بود و باعث می‌شد پنل در موبایل از سمت راست بیرون بیفتد.
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-panel_w * 0.5, -panel_h * 0.5)
	panel.size = Vector2(panel_w, panel_h)
	panel.z_index = 400
	var style: StyleBoxFlat = StyleBoxFlat.new()
	style.bg_color = Color("061522eF")
	style.border_color = Color("49e6d6")
	style.set_border_width_all(3)
	style.set_corner_radius_all(24)
	style.shadow_color = Color(0.0,0.8,0.8,0.28)
	style.shadow_size = 18
	panel.add_theme_stylebox_override("panel", style)
	var box: VBoxContainer = VBoxContainer.new()
	box.name = "FeatureBox"
	box.add_theme_constant_override("separation", 12)
	box.add_theme_constant_override("margin_left", 24)
	box.add_theme_constant_override("margin_right", 24)
	box.add_theme_constant_override("margin_top", 20)
	box.add_theme_constant_override("margin_bottom", 20)
	var title: Label = Label.new()
	title.text = title_text
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", Color("ffffff"))
	title.add_theme_color_override("font_outline_color", Color("043b4b"))
	title.add_theme_constant_override("outline_size", 6)
	box.add_child(title)
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.name = "FeatureScroll"
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 320)
	scroll.mouse_filter = Control.MOUSE_FILTER_STOP
	scroll.scroll_deadzone = 12
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var list: VBoxContainer = VBoxContainer.new()
	list.name = "FeatureList"
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 12)
	scroll.add_child(list)
	box.add_child(scroll)
	var close: Button = Button.new()
	close.text = "✕ بستن"
	close.custom_minimum_size.y = 64
	close.add_theme_font_size_override("font_size", 28)
	close.add_theme_color_override("font_color", Color("ffffff"))
	close.add_theme_color_override("font_outline_color", Color("02131f"))
	close.add_theme_constant_override("outline_size", 3)
	close.pressed.connect(func(): panel.queue_free())
	box.add_child(close)
	panel.add_child(box)
	add_child(panel)
	return panel

func _create_masterpiece_buttons() -> void:
	var vbox: VBoxContainer = find_child("VBox", true, false)
	var shop: Button = find_child("ShopButton", true, false)
	if vbox == null or shop == null: return
	if find_child("MasterpieceButton", true, false) != null: return
	var b: Button = shop.duplicate() as Button
	b.name = "MasterpieceButton"
	b.text = "🌳 درخت تکامل • کلکسیون • لیگ"
	vbox.add_child(b)
	vbox.move_child(b, shop.get_index() + 1)
	b.pressed.connect(_open_masterpiece_hub)

func _style_feature_button(b: Button, accent: Color = Color("49e6d6")) -> void:
	b.custom_minimum_size.y = max(b.custom_minimum_size.y, 82.0)
	b.alignment = HORIZONTAL_ALIGNMENT_RIGHT
	b.add_theme_font_size_override("font_size", 27)
	b.add_theme_color_override("font_color", Color("f2fbff"))
	b.add_theme_color_override("font_hover_color", Color("ffffff"))
	b.add_theme_color_override("font_pressed_color", Color("bffff8"))
	b.add_theme_color_override("font_focus_color", Color("f2fbff"))
	b.add_theme_color_override("font_outline_color", Color("02131f"))
	b.add_theme_constant_override("outline_size", 3)
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color("0a2033e8")
	normal.border_color = Color(accent, 0.72)
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(18)
	normal.shadow_color = Color(0.0, 0.9, 0.85, 0.14)
	normal.shadow_size = 8
	var hover := normal.duplicate()
	hover.bg_color = Color("123c55f2")
	hover.border_color = accent
	hover.shadow_color = Color(0.0, 0.95, 0.9, 0.28)
	hover.shadow_size = 12
	var pressed := hover.duplicate()
	pressed.bg_color = Color("17627af5")
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("focus", hover)

func _style_feature_label(l: Label, size: int = 26, color: Color = Color("f2fbff")) -> void:
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color("02131f"))
	l.add_theme_constant_override("outline_size", 3)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.text_direction = Control.TEXT_DIRECTION_RTL
	l.layout_direction = Control.LAYOUT_DIRECTION_RTL

func _open_masterpiece_hub() -> void:
	var panel: PanelContainer = _make_feature_panel("🌊 مرکز تکامل اقیانوس — درخت تکامل، کلکسیون و لیگ")
	var list: VBoxContainer = panel.find_child("FeatureList", true, false)
	var scroll: ScrollContainer = panel.find_child("FeatureScroll", true, false)
	if scroll:
		scroll.mouse_filter = Control.MOUSE_FILTER_STOP
		scroll.scroll_deadzone = 12
	var league: Dictionary = FeatureManager.get_league()
	var header: Label = Label.new()
	header.text = "👤 %s   •   🏆 لیگ %s   •   امتیاز لیگ: %d   •   باس‌ها: %d" % [SaveManager.player_name if SaveManager.player_name != "" else "بازیکن", league["name"], int(league["points"]), FeatureManager.bosses_defeated]
	_style_feature_label(header, 27, Color("ffe66d"))
	header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	list.add_child(header)
	var hint: Label = Label.new()
	hint.text = "👆 صفحه را با انگشت بالا و پایین بکش — ۴۰ موجود درخت تکامل را ببین"
	_style_feature_label(hint, 24, Color("7fffe8"))
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	list.add_child(hint)
	var tree_title: Label = Label.new()
	tree_title.text = "🌳 درخت تکامل واقعی — ۴۰ موجود"
	_style_feature_label(tree_title, 34, Color("ffffff"))
	tree_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	list.add_child(tree_title)
	for species in FeatureManager.SPECIES:
		var id: String = str(species["id"])
		var owned: bool = FeatureManager.species_owned.has(id)
		var unlocked: bool = FeatureManager.discovered_species.has(id)
		var b: Button = Button.new()
		var state: String = "✓ فعال" if id == FeatureManager.active_species else ("✓ باز شده" if owned else ("🔓 کشف شده • %d DNA" % int(species["cost"]) if unlocked else "🔒 قفل"))
		b.text = "%s  %s\n%s  •  %s" % [species["icon"], species["name"], species["region"], state]
		b.custom_minimum_size.y = 92
		_style_feature_button(b, Color("49e6d6") if owned else Color("2d8bb5"))
		b.pressed.connect(func():
			if FeatureManager.buy_species(id):
				panel.queue_free()
				call_deferred("_open_masterpiece_hub")
		)
		list.add_child(b)
	var info: Label = Label.new()
	info.text = "📖 داستان: %d/%d مأموریت   |   🗺 مناطق مخفی: %d   |   ✨ اتفاقات نادر: %d   |   🧬 موجودات بازشده: %d/%d" % [FeatureManager.story_claimed.values().count(true), FeatureManager.STORY.size(), FeatureManager.secret_regions_found, FeatureManager.rare_events_found, FeatureManager.species_owned.size(), FeatureManager.SPECIES.size()]
	_style_feature_label(info, 25, Color("dffcff"))
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	list.add_child(info)
	var story_btn: Button = Button.new()
	story_btn.text = "📖 مأموریت‌های داستانی و مناطق مخفی"
	_style_feature_button(story_btn, Color("7d6cff"))
	story_btn.pressed.connect(func(): _open_story_panel())
	list.add_child(story_btn)
	var collection_btn: Button = Button.new()
	collection_btn.text = "📚 کلکسیون موجودات"
	_style_feature_button(collection_btn, Color("ffb84d"))
	collection_btn.pressed.connect(func(): _open_collection_panel())
	list.add_child(collection_btn)

func _open_story_panel() -> void:
	var panel: PanelContainer = _make_feature_panel("📖 داستان، مأموریت‌ها و مناطق مخفی")
	var list: VBoxContainer = panel.find_child("FeatureList", true, false)
	for m in FeatureManager.STORY:
		var id: String = str(m["id"]); var p: int = int(FeatureManager.story_progress.get(id, 0)); var done: bool = bool(FeatureManager.story_claimed.get(id, false))
		var l: Label = Label.new(); l.text = ("✅ " if done else "🎯 ") + str(m["title"]) + " — " + str(m["desc"]) + "   [%d/%d]   +%d DNA" % [p, int(m["target"]), int(m["reward"])]; _style_feature_label(l, 27, Color("f2fbff")); list.add_child(l)
	var hidden: Label = Label.new(); hidden.text = "🗺 مناطق مخفی کشف‌شده: " + (", ".join(FeatureManager.secret_regions) if FeatureManager.secret_regions.size() > 0 else "هنوز هیچ‌کدام؛ با تغییر منطقه، باس‌ها و اتفاقات نادر ادامه بده."); _style_feature_label(hidden, 27, Color("72ffe5")); list.add_child(hidden)

func _open_collection_panel() -> void:
	var panel: PanelContainer = _make_feature_panel("📚 کلکسیون موجودات")
	var list: VBoxContainer = panel.find_child("FeatureList", true, false)
	for s in FeatureManager.SPECIES:
		var id: String = str(s["id"]); var owned: bool = FeatureManager.species_owned.has(id); var discovered: bool = FeatureManager.discovered_species.has(id)
		var l: Label = Label.new(); l.text = ("🟢 " if owned else ("🟡 " if discovered else "⚫ ")) + str(s["icon"]) + "  " + str(s["name"]) + "  —  " + ("جمع‌آوری شد" if owned else ("قابل خرید با %d DNA" % int(s["cost"]) if discovered else "ناشناخته")); _style_feature_label(l, 27, Color("f2fbff")); list.add_child(l)

func _create_name_gate() -> void:
	if find_child("NameGate", true, false) != null:
		return
	var panel: PanelContainer = _make_feature_panel("🧬 قبل از شروع، نام تکاملی خودت را انتخاب کن")
	panel.name = "NameGate"
	var list: VBoxContainer = panel.find_child("FeatureList", true, false)
	for child in list.get_children(): child.queue_free()
	var info: Label = Label.new(); info.text = "این نام روی پروفایل، لیگ و کلکسیون تو نمایش داده می‌شود."; info.add_theme_font_size_override("font_size", 24); list.add_child(info)
	var edit: LineEdit = LineEdit.new(); edit.placeholder_text = "مثلاً: سلول پارسا"; edit.custom_minimum_size.y = 62; edit.add_theme_font_size_override("font_size", 24); list.add_child(edit)
	var ok: Button = Button.new(); ok.text = "🚀 شروع تکامل"; ok.custom_minimum_size.y = 62; ok.pressed.connect(func():
		var n: String = edit.text.strip_edges()
		if n.length() < 2: show_message("نام باید حداقل ۲ حرف باشد."); return
		SaveManager.player_name = n; FeatureManager.player_name = n; SaveManager.save_game(); panel.queue_free(); SoundManager.play_boost(); get_tree().change_scene_to_file("res://scenes/World.tscn")
	); list.add_child(ok)

func _create_account_button() -> void:
	var settings: PanelContainer = settings_panel
	if settings == null or settings.find_child("AccountButton", true, false) != null: return
	var box: VBoxContainer = settings.find_child("VBox", true, false)
	if box == null: return
	var b: Button = Button.new(); b.name = "AccountButton"; b.text = "💾 ذخیره/بازیابی حساب با شماره موبایل"; b.custom_minimum_size.y = 56; b.add_theme_font_size_override("font_size", 21); b.pressed.connect(_open_account_panel); box.add_child(b)

func _open_account_panel() -> void:
	var panel: PanelContainer = _make_feature_panel("💾 حساب امن بازی")
	var list: VBoxContainer = panel.find_child("FeatureList", true, false)
	for child in list.get_children(): child.queue_free()
	var info: Label = Label.new(); info.text = "شماره موبایل را وارد کن. نسخه فعلی کد تأیید را داخل پیام امن خود بازی نمایش می‌دهد؛ برای ارسال SMS واقعی باید سرور و سرویس پیامکی به بازی متصل شود."; info.add_theme_font_size_override("font_size", 21); info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; list.add_child(info)
	var phone: LineEdit = LineEdit.new(); phone.placeholder_text = "+49... یا شماره موبایل"; phone.custom_minimum_size.y = 58; phone.add_theme_font_size_override("font_size", 23); list.add_child(phone)
	var send: Button = Button.new(); send.text = "📨 دریافت کد تأیید"; send.custom_minimum_size.y = 58; list.add_child(send)
	var code: LineEdit = LineEdit.new(); code.placeholder_text = "کد ۶ رقمی"; code.max_length = 6; code.custom_minimum_size.y = 58; code.add_theme_font_size_override("font_size", 23); list.add_child(code)
	var verify: Button = Button.new(); verify.text = "✅ تأیید و بازیابی حساب"; verify.custom_minimum_size.y = 58; list.add_child(verify)
	var message: Label = Label.new(); message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; message.add_theme_font_size_override("font_size", 24); list.add_child(message)
	send.pressed.connect(func():
		var generated: String = SaveManager.create_account_code(phone.text)
		if generated.is_empty(): message.text = "❌ شماره معتبر وارد کن."; return
		message.text = "📩 پیام بازی\nکد تأیید حساب «سیر تکامل»: %s\nاین کد را در کادر پایین وارد کن." % generated
	)
	verify.pressed.connect(func():
		if SaveManager.verify_account_code(phone.text, code.text):
			message.text = "✅ حساب با موفقیت بازیابی شد. نام: %s\nاکنون می‌توانی وارد بازی شوی." % SaveManager.player_name
			refresh_stats()
		else: message.text = "❌ کد یا شماره اشتباه است. دوباره درخواست کد کن."
	)

func _on_quit() -> void:
	get_tree().quit()

var overlay_tween: Tween = null
var text_tweens: Array[Tween] = []

func _animate_overlay_open(panel: Control) -> void:
	# انیمیشن باز شدن نرم پنل‌های منو: محو شدن + بزرگ‌شدن از ۰.۸۸ به ۱
	if not is_instance_valid(panel):
		return
	if overlay_tween and is_instance_valid(overlay_tween):
		overlay_tween.kill()
	panel.visible = true
	panel.pivot_offset = panel.size / 2.0
	panel.scale = Vector2(0.88, 0.88)
	panel.modulate.a = 0.0
	overlay_tween = create_tween()
	overlay_tween.set_parallel(true)
	overlay_tween.set_trans(Tween.TRANS_BACK)
	overlay_tween.set_ease(Tween.EASE_OUT)
	overlay_tween.tween_property(panel, "modulate:a", 1.0, 0.22)
	overlay_tween.tween_property(panel, "scale", Vector2.ONE, 0.25)
	overlay_tween.chain().tween_callback(func():
		panel.modulate.a = 1.0
		panel.scale = Vector2.ONE)

func _animate_overlay_text(panel: Control) -> void:
	for old_tween: Tween in text_tweens:
		if is_instance_valid(old_tween):
			old_tween.kill()
	text_tweens.clear()
	var content: Node = panel.find_child("VBox", true, false)
	if content == null:
		return
	var delay: float = 0.04
	for item: Node in content.get_children():
		if item is Control:
			var control: Control = item as Control
			control.modulate.a = 0.0
			control.scale = Vector2(0.97, 0.97)
			control.pivot_offset = control.size / 2.0
			var text_tween: Tween = create_tween()
			text_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
			text_tween.tween_interval(delay)
			text_tween.set_parallel(true)
			text_tween.set_trans(Tween.TRANS_SINE)
			text_tween.set_ease(Tween.EASE_OUT)
			text_tween.tween_property(control, "modulate:a", 1.0, 0.24)
			text_tween.tween_property(control, "scale", Vector2.ONE, 0.24)
			text_tweens.append(text_tween)
			delay += 0.055

func _show_overlay(panel: PanelContainer):
	overlay_dim.visible = true
	_animate_overlay_open(panel)
	_animate_overlay_text(panel)
	SoundManager.play_eat_food()

func _close_overlays() -> void:
	if overlay_tween and is_instance_valid(overlay_tween):
		overlay_tween.kill()
		overlay_tween = null
	for old_tween: Tween in text_tweens:
		if is_instance_valid(old_tween):
			old_tween.kill()
	text_tweens.clear()
	for p: Control in [howto_panel, settings_panel, shop_panel, daily_panel, weekly_panel]:
		if p:
			p.visible = false
			p.modulate.a = 1.0
			p.scale = Vector2.ONE
	overlay_dim.visible = false

func _on_sound_toggled(on: bool) -> void:
	SaveManager.sound_enabled = on
	SaveManager.save_game()

func _on_music_toggled(on: bool) -> void:
	SaveManager.music_enabled = on
	SaveManager.save_game()

func _on_reset() -> void:
	SaveManager.high_score = 0
	SaveManager.max_level = 1
	SaveManager.total_dna = 0
	SaveManager.last_daily_claim = ""
	SaveManager.daily_streak = 0
	SaveManager.weekly_progress = {"food": 0, "enemy": 0, "survive": 0}
	SaveManager.weekly_reset_key = ""
	SaveManager.weekly_claimed = {"food": false, "enemy": false, "survive": false}
	SaveManager.reset_upgrades()
	SaveManager.save_game()
	refresh_stats()

func _on_shop() -> void:
	refresh_stats()
	_show_overlay(shop_panel)
	for c in shop_list.get_children():
		c.queue_free()
	for u in UPGRADES:
		var row: PanelContainer = _make_upgrade_row(u)
		shop_list.add_child(row)

func _make_upgrade_row(u: Dictionary) -> PanelContainer:
	var panel: PanelContainer = PanelContainer.new()
	var margin: MarginContainer = MarginContainer.new()
	for side in ["margin_left", "margin_top", "margin_right", "margin_bottom"]:
		margin.add_theme_constant_override(side, 8)
	panel.add_child(margin)
	var hbox: HBoxContainer = HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 10)
	margin.add_child(hbox)
	var cur_lvl: int = int(SaveManager.get(u["key"]))
	var maxed: bool = cur_lvl >= u["max"]
	var cost: int = u["cost"] + cur_lvl * 7 + cur_lvl * cur_lvl * 2
	var lbl: Label = Label.new()
	lbl.text = "%s %s  |  سطح %d/%d" % [u["icon"], u["name"], cur_lvl, u["max"]]
	lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lbl.custom_minimum_size = Vector2(0, 72)
	lbl.add_theme_font_size_override("font_size", 30)
	lbl.add_theme_color_override("font_color", Color("#caf0f8"))
	lbl.add_theme_color_override("font_outline_color", Color("#063248"))
	lbl.add_theme_constant_override("outline_size", 2)
	hbox.add_child(lbl)
	var btn: Button = Button.new()
	btn.text = ("MAX" if maxed else ("خرید (%d 🧬)" % cost))
	btn.disabled = maxed or SaveManager.total_dna < cost
	btn.custom_minimum_size = Vector2(190, 72)
	btn.add_theme_font_size_override("font_size", 28)
	btn.add_theme_color_override("font_color", Color("#caf0f8"))
	btn.add_theme_color_override("font_hover_color", Color("#4deeea"))
	btn.pressed.connect(func(): _buy(u))
	hbox.add_child(btn)
	return panel

func _buy(u: Dictionary) -> void:
	var cur_lvl: int = int(SaveManager.get(u["key"]))
	var cost: int = u["cost"] + cur_lvl * 7 + cur_lvl * cur_lvl * 2
	if cur_lvl >= u["max"] or SaveManager.total_dna < cost:
		return
	SaveManager.total_dna -= cost
	SaveManager.set(u["key"], cur_lvl + 1)
	SaveManager.save_game()
	SoundManager.play_eat_dna()
	_on_shop()
