extends Node2D
## سیر تکامل — بسته جزئیات شاهکار
## رویدادهای پویا، آب‌وهوا، آثار کمیاب، دستاوردها و مأموریت‌های کوتاه

var world: Node = null
var player: Node = null
var rng = RandomNumberGenerator.new()
var elapsed = 0.0
var weather_timer = 38.0
var event_timer = 52.0
var relic_timer = 24.0
var quest_timer = 42.0
var weather_time = 0.0
var event_time = 0.0
var current_weather = "آرام"
var current_event = ""
var current_quest = ""
var quest_kind = "food"
var quest_target = 10
var quest_progress = 0
var relics: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var distance_walked = 0.0
var last_player_pos = Vector2.ZERO
var combo_bonus = 1.0
var achievement_flags: Dictionary = {}
var hud: CanvasLayer
var banner: PanelContainer
var title_label: Label
var detail_label: Label
var status_label: Label
var quest_label: Label
var weather_label: Label
var toast: Label

const WEATHER: Array[Dictionary] = [
    {"name":"شب آرام", "icon":"🌙", "color":Color(0.18,0.25,0.55,0.10), "speed":1.0},
    {"name":"شفق زیستی", "icon":"🌈", "color":Color(0.20,0.80,0.55,0.08), "speed":1.03},
    {"name":"باران اسیدی", "icon":"☣️", "color":Color(0.45,0.80,0.15,0.10), "speed":0.97},
    {"name":"جریان طلایی", "icon":"✨", "color":Color(1.0,0.70,0.15,0.09), "speed":1.06},
    {"name":"مه عمیق", "icon":"🌫️", "color":Color(0.20,0.45,0.70,0.12), "speed":0.94}
]
const EVENTS: Array[Dictionary] = [
    {"name":"شکوفایی DNA", "icon":"🧬", "duration":24.0},
    {"name":"هجوم شکارچیان", "icon":"👁️", "duration":20.0},
    {"name":"بارش کریستالی", "icon":"💎", "duration":22.0},
    {"name":"موج انرژی", "icon":"⚡", "duration":18.0},
    {"name":"مهاجرت موجودات", "icon":"🐟", "duration":25.0}
]

func setup(p_world: Node, p_player: Node) -> void:
    world = p_world
    player = p_player
    rng.randomize()
    last_player_pos = player.global_position
    _build_hud()
    _set_weather()
    _new_quest()
    queue_redraw()

func _build_hud() -> void:
    hud = CanvasLayer.new()
    hud.layer = 90
    add_child(hud)
    var root = Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud.add_child(root)

    banner = PanelContainer.new()
    banner.position = Vector2(18, 128)
    banner.size = Vector2(420, 104)
    banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var style = StyleBoxFlat.new()
    style.bg_color = Color(0.015,0.035,0.07,0.86)
    style.border_color = Color(0.30,0.95,0.90,0.72)
    style.set_border_width_all(2)
    style.set_corner_radius_all(16)
    banner.add_theme_stylebox_override("panel", style)
    root.add_child(banner)
    var box = VBoxContainer.new()
    box.add_theme_constant_override("separation", 2)
    banner.add_child(box)
    title_label = Label.new()
    title_label.text = "✨ جهان زنده"
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.add_theme_font_size_override("font_size", 24)
    title_label.add_theme_color_override("font_color", Color("#7fffe8"))
    box.add_child(title_label)
    detail_label = Label.new()
    detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    detail_label.add_theme_font_size_override("font_size", 19)
    detail_label.add_theme_color_override("font_color", Color("#d8faff"))
    box.add_child(detail_label)

    weather_label = Label.new()
    weather_label.position = Vector2(18, 240)
    weather_label.size = Vector2(420, 38)
    weather_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    weather_label.add_theme_font_size_override("font_size", 20)
    weather_label.add_theme_color_override("font_color", Color("#c8f6ff"))
    root.add_child(weather_label)

    quest_label = Label.new()
    quest_label.position = Vector2(18, 282)
    quest_label.size = Vector2(520, 56)
    quest_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    quest_label.add_theme_font_size_override("font_size", 18)
    quest_label.add_theme_color_override("font_color", Color("#ffe88a"))
    root.add_child(quest_label)

    status_label = Label.new()
    status_label.position = Vector2(18, 344)
    status_label.size = Vector2(420, 34)
    status_label.add_theme_font_size_override("font_size", 16)
    status_label.add_theme_color_override("font_color", Color("#a8dce8"))
    root.add_child(status_label)

    toast = Label.new()
    toast.position = Vector2(18, 390)
    toast.size = Vector2(520, 62)
    toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    toast.add_theme_font_size_override("font_size", 23)
    toast.add_theme_color_override("font_color", Color("#ffffff"))
    toast.add_theme_color_override("font_outline_color", Color(0,0,0,0.9))
    toast.add_theme_constant_override("outline_size", 5)
    root.add_child(toast)

func _process(delta: float) -> void:
    if not is_instance_valid(player) or not is_instance_valid(world):
        return
    elapsed += delta
    weather_timer -= delta
    event_timer -= delta
    relic_timer -= delta
    quest_timer -= delta
    weather_time = maxf(0.0, weather_time - delta)
    event_time = maxf(0.0, event_time - delta)

    var moved = player.global_position.distance_to(last_player_pos)
    if moved < 120.0:
        distance_walked += moved
    last_player_pos = player.global_position

    if weather_timer <= 0.0:
        _set_weather()
        weather_timer = rng.randf_range(42.0, 72.0)
    if event_timer <= 0.0:
        _start_event()
        event_timer = rng.randf_range(58.0, 92.0)
    if relic_timer <= 0.0 and relics.size() < 3:
        _spawn_relic()
        relic_timer = rng.randf_range(28.0, 46.0)
    if quest_timer <= 0.0:
        _new_quest()
    _update_relics(delta)
    _update_particles(delta)
    _update_hud()
    queue_redraw()

func _set_weather() -> void:
    var data: Dictionary = WEATHER[rng.randi_range(0, WEATHER.size()-1)]
    current_weather = str(data["name"])
    weather_time = rng.randf_range(35.0, 58.0)
    weather_label.text = "%s  آب‌وهوا: %s" % [data["icon"], current_weather]
    if is_instance_valid(world) and world.has_method("apply_world_detail_color"):
        world.apply_world_detail_color(data["color"])
    _show_toast("%s  %s" % [data["icon"], current_weather], Color("#9fffe9"))

func _start_event() -> void:
    var data: Dictionary = EVENTS[rng.randi_range(0, EVENTS.size()-1)]
    current_event = str(data["name"])
    event_time = float(data["duration"])
    title_label.text = "%s %s" % [data["icon"], current_event]
    detail_label.text = "یک اتفاق ویژه در جهان زنده فعال شد!"
    if is_instance_valid(world):
        if current_event == "شکوفایی DNA":
            _reward_dna(8)
        elif current_event == "بارش کریستالی":
            _reward_dna(12)
        elif current_event == "موج انرژی":
            _reward_dna(6)
        elif current_event == "هجوم شکارچیان" and world.has_method("start_hunter_attack"):
            world.start_hunter_attack()
    _show_toast("⚡ رویداد جهانی: %s" % current_event, Color("#ffe47a"))

func _spawn_relic() -> void:
    var angle = rng.randf_range(0.0, TAU)
    var pos = player.global_position + Vector2.RIGHT.rotated(angle) * rng.randf_range(420.0, 900.0)
    var reward = rng.randi_range(12, 34)
    var kind = ["🧬 هسته ژنتیکی", "💎 کریستال باستانی", "🌟 ذره ستاره‌ای", "🧿 یادگار ناشناخته"][rng.randi_range(0,3)]
    relics.append({"pos":pos,"reward":reward,"kind":kind,"life":75.0,"phase":rng.randf_range(0.0,TAU)})
    _show_toast("🔎 یک %s در نزدیکی کشف شد!" % kind, Color("#d99cff"))

func _update_relics(delta: float) -> void:
    for i in range(relics.size()-1, -1, -1):
        relics[i]["life"] = float(relics[i]["life"]) - delta
        if float(relics[i]["life"]) <= 0.0:
            relics.remove_at(i)
            continue
        var pos: Vector2 = relics[i]["pos"]
        if player.global_position.distance_to(pos) < 80.0:
            var reward = int(relics[i]["reward"])
            _reward_dna(reward)
            _show_toast("✨ %s پیدا شد! +%d DNA" % [relics[i]["kind"], reward], Color("#d99cff"))
            quest_progress += 1 if quest_kind == "relic" else 0
            relics.remove_at(i)

func _new_quest() -> void:
    var choices = ["food","enemy","relic","distance"]
    quest_kind = choices[rng.randi_range(0, choices.size()-1)]
    quest_target = rng.randi_range(8, 18) if quest_kind != "distance" else rng.randi_range(900, 1800)
    quest_progress = 0
    quest_timer = rng.randf_range(55.0, 80.0)
    match quest_kind:
        "food": current_quest = "🍀 ۱۰ تا غذا بخور"
        "enemy": current_quest = "⚔️ چند دشمن را شکست بده"
        "relic": current_quest = "🔎 یک یادگار کمیاب پیدا کن"
        "distance": current_quest = "🧭 در محیط %d متر حرکت کن" % quest_target
    quest_label.text = "🎯 مأموریت کوتاه: %s  |  پاداش: ۲۵ DNA" % current_quest

func add_progress(kind: String, amount: int = 1) -> void:
    if kind != quest_kind:
        return
    quest_progress += amount
    if quest_progress >= quest_target:
        _reward_dna(25)
        _show_toast("🏆 مأموریت کامل شد! +25 DNA", Color("#ffe66d"))
        _new_quest()

func _reward_dna(amount: int) -> void:
    if is_instance_valid(player) and player.has_method("add_dna"):
        player.add_dna(amount)

func _update_particles(delta: float) -> void:
    for i in range(particles.size()-1,-1,-1):
        particles[i]["life"] = float(particles[i]["life"]) - delta
        particles[i]["pos"] = particles[i]["pos"] + particles[i]["vel"] * delta
        if float(particles[i]["life"]) <= 0.0:
            particles.remove_at(i)

func _update_hud() -> void:
    if not is_instance_valid(player): return
    var progress = quest_progress
    if quest_kind == "distance":
        progress = int(distance_walked)
    progress = mini(progress, quest_target)
    quest_label.text = "🎯 %s  |  %d / %d  |  جایزه: ۲۵ DNA" % [current_quest, progress, quest_target]
    status_label.text = "🌍 جهان زنده  •  کشفیات: %d  •  رویداد: %s" % [relics.size(), current_event if event_time > 0.0 else "در انتظار"]
    if event_time <= 0.0:
        title_label.text = "✨ جهان زنده"
        detail_label.text = "محیط پویاست؛ هر لحظه ممکن است اتفاق تازه‌ای رخ دهد."

func _show_toast(message: String, _color: Color) -> void:
    if not is_instance_valid(toast): return
    toast.text = message
    toast.modulate.a = 1.0
    var tw = create_tween()
    tw.tween_interval(2.4)
    tw.tween_property(toast, "modulate:a", 0.0, 0.5)

func _draw() -> void:
    if not is_instance_valid(player): return
    for r in relics:
        var p: Vector2 = r["pos"]
        var pulse = 1.0 + 0.16 * sin(elapsed * 5.0 + float(r["phase"]))
        draw_circle(p, 28.0 * pulse, Color(0.70,0.35,1.0,0.10))
        draw_arc(p, 22.0 * pulse, 0.0, TAU, 24, Color(0.85,0.55,1.0,0.72), 3.0, true)
        draw_circle(p, 7.0 * pulse, Color(0.90,0.75,1.0,0.9))
