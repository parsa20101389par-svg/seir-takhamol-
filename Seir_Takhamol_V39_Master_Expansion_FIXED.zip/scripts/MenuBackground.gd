extends Node2D
# پس‌زمینه زنده‌ی منو: حباب‌های بالارونده + پلانکتون‌های شناور + لایه‌های عمق آب

var bubbles: Array = []
var plankton: Array = []
var caustics_time: float = 0.0
var rng = RandomNumberGenerator.new()

func _ready():
	rng.randomize()
	for i in range(40):
		bubbles.append(_make_bubble(true))
	for i in range(60):
		plankton.append(_make_plankton(true))

func _make_bubble(anywhere: bool) -> Dictionary:
	var vp = get_viewport_rect().size
	return {
		"pos": Vector2(rng.randf_range(0, vp.x), rng.randf_range(0, vp.y) if anywhere else vp.y + 20),
		"r": rng.randf_range(2.0, 9.0),
		"spd": rng.randf_range(20.0, 70.0),
		"sway": rng.randf_range(0.0, TAU),
		"alpha": rng.randf_range(0.1, 0.4)
	}

func _make_plankton(anywhere: bool) -> Dictionary:
	var vp = get_viewport_rect().size
	return {
		"pos": Vector2(rng.randf_range(0, vp.x), rng.randf_range(0, vp.y) if anywhere else Vector2(rng.randf_range(0, vp.x), -10)),
		"vel": Vector2(rng.randf_range(-15, 15), rng.randf_range(-8, 8)),
		"r": rng.randf_range(1.0, 3.0),
		"phase": rng.randf_range(0, TAU),
		"col": Color(rng.randf_range(0.3, 0.8), rng.randf_range(0.7, 1.0), rng.randf_range(0.5, 1.0), rng.randf_range(0.2, 0.6))
	}

func _process(delta):
	caustics_time += delta
	var vp = get_viewport_rect().size
	for b in bubbles:
		b["pos"].y -= b["spd"] * delta
		b["pos"].x += sin(caustics_time * 2.0 + b["sway"]) * 12.0 * delta
		if b["pos"].y < -20:
			var nb = _make_bubble(false)
			b["pos"] = nb["pos"]; b["r"] = nb["r"]; b["spd"] = nb["spd"]; b["alpha"] = nb["alpha"]
	for p in plankton:
		p["pos"] += p["vel"] * delta * (1.0 + 0.3 * sin(caustics_time + p["phase"]))
		if p["pos"].x < -20: p["pos"].x = vp.x + 20
		if p["pos"].x > vp.x + 20: p["pos"].x = -20
		if p["pos"].y < -20: p["pos"].y = vp.y + 20
		if p["pos"].y > vp.y + 20: p["pos"].y = -20
	queue_redraw()

func _draw():
	var vp = get_viewport_rect().size
	# Plankton
	for p in plankton:
		draw_circle(p["pos"], p["r"], p["col"])
	# Bubbles
	for b in bubbles:
		var c = Color(0.7, 0.95, 1.0, b["alpha"])
		draw_circle(b["pos"], b["r"] * 1.6, Color(c.r, c.g, c.b, c.a * 0.4))
		draw_circle(b["pos"] + Vector2(-b["r"] * 0.3, -b["r"] * 0.3), b["r"] * 0.25, Color(1, 1, 1, b["alpha"] * 0.8))
