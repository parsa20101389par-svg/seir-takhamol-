extends Label
# انیمیشن عنوان منو: درخشش + شناوری ملایم

var t: float = 0.0
var base_y: float = 0.0

func _ready():
	base_y = position.y

func _process(delta):
	t += delta
	position.y = base_y + sin(t * 1.5) * 6.0
	var glow = 0.5 + 0.5 * sin(t * 2.0)
	add_theme_color_override("font_color", Color(0.55 + 0.25 * glow, 0.95, 1.0, 1.0))
