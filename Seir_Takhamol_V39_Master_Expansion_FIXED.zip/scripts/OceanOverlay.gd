extends Control

const BUBBLE_COUNT: int = 16
const FISH_COUNT: int = 3

var bubble_x: Array[float] = []
var bubble_y: Array[float] = []
var bubble_radius: Array[float] = []
var bubble_speed: Array[float] = []
var bubble_phase: Array[float] = []
var fish_x: Array[float] = []
var fish_y: Array[float] = []
var fish_speed: Array[float] = []
var fish_scale: Array[float] = []
var elapsed: float = 0.0
var show_fish: bool = false

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in range(BUBBLE_COUNT):
		bubble_x.append(randf())
		bubble_y.append(randf())
		bubble_radius.append(randf_range(3.0, 8.0))
		bubble_speed.append(randf_range(18.0, 42.0))
		bubble_phase.append(randf_range(0.0, TAU))
	for i in range(FISH_COUNT):
		fish_x.append(randf())
		fish_y.append(randf_range(0.18, 0.82))
		fish_speed.append(randf_range(22.0, 46.0) * (1.0 if i % 2 == 0 else -1.0))
		fish_scale.append(randf_range(0.7, 1.15))

func _process(delta: float) -> void:
	if not visible:
		return
	elapsed += delta
	var height: float = size.y
	var width: float = size.x
	for i in range(BUBBLE_COUNT):
		bubble_y[i] -= bubble_speed[i] * delta / maxf(height, 1.0)
		if bubble_y[i] < -0.04:
			bubble_y[i] = 1.04
			bubble_x[i] = randf()
	for i in range(FISH_COUNT):
		fish_x[i] += fish_speed[i] * delta / maxf(width, 1.0)
		if fish_x[i] > 1.12:
			fish_x[i] = -0.12
		elif fish_x[i] < -0.12:
			fish_x[i] = 1.12
	queue_redraw()

func _draw() -> void:
	var width: float = size.x
	var height: float = size.y
	for i in range(BUBBLE_COUNT):
		var alpha: float = 0.18 + 0.34 * (0.5 + 0.5 * sin(elapsed * 1.4 + bubble_phase[i]))
		var center: Vector2 = Vector2(bubble_x[i] * width + sin(elapsed + bubble_phase[i]) * 5.0, bubble_y[i] * height)
		var radius: float = bubble_radius[i]
		draw_circle(center, radius, Color(0.14, 0.75, 0.95, alpha * 0.18))
		draw_arc(center, radius, 0.0, TAU, 20, Color(0.55, 0.91, 1.0, alpha), 1.4, true)
		draw_circle(center + Vector2(-radius * 0.32, -radius * 0.32), maxf(1.0, radius * 0.18), Color(0.86, 0.98, 1.0, alpha * 0.8))
	if show_fish:
		for i in range(FISH_COUNT):
			var direction: float = 1.0 if fish_speed[i] > 0.0 else -1.0
			var pos: Vector2 = Vector2(fish_x[i] * width, fish_y[i] * height + sin(elapsed * 0.8 + float(i)) * 9.0)
			var scale_factor: float = fish_scale[i]
			var body_color: Color = Color(0.15, 0.62, 0.77, 0.28)
			draw_set_transform(pos, 0.0, Vector2(direction * scale_factor, scale_factor))
			draw_colored_polygon(PackedVector2Array([Vector2(-24, 0), Vector2(-10, -12), Vector2(10, -10), Vector2(22, 0), Vector2(10, 10), Vector2(-10, 12)]), body_color)
			draw_colored_polygon(PackedVector2Array([Vector2(18, 0), Vector2(34, -11), Vector2(34, 11)]), Color(0.2, 0.72, 0.84, 0.26))
			draw_circle(Vector2(12, -3), 1.8, Color(0.82, 0.98, 1.0, 0.65))
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
