extends CharacterBody2D

signal evolved(new_level: int, stats: Dictionary)
signal mass_changed(current_mass: float, max_mass: float)
signal player_died
signal score_updated(score: int)
signal evolution_choice_requested(new_level: int)
signal hp_changed(current_hp: float, max_hp: float)
signal adrenaline_changed(active: bool, pulse: float)
signal damage_taken(position: Vector2, damage: float)
signal food_eaten(value: float)
signal combo_reached(combo: int)

var base_speed: float = 230.0
var boost_speed: float = 380.0
var current_speed: float = 230.0
var mass: float = 20.0
var level: int = 1
var score: int = 0
var combo_count: int = 0
var combo_timer: float = 0.0
const COMBO_WINDOW: float = 2.5
func get_combo_window() -> float:
	return COMBO_WINDOW + float(evolution_extra_levels.get("combo_master", 0)) * 0.18
var pointer_target: Vector2 = Vector2.INF
var use_pointer: bool = false
var alive: bool = true
var region_visual_tint: Color = Color(0.28, 0.95, 0.9)

const EVOLUTION_SKINS: Array[Dictionary] = [
	{"name":"هسته کلاسیک","color":Color(0.28,0.90,0.88),"accent":Color(0.75,1.0,0.95),"style":0},
	{"name":"شعله‌ای","color":Color(1.0,0.28,0.08),"accent":Color(1.0,0.82,0.20),"style":1},
	{"name":"کریستالی","color":Color(0.30,0.82,1.0),"accent":Color(0.75,0.95,1.0),"style":2},
	{"name":"سمی","color":Color(0.30,1.0,0.35),"accent":Color(0.75,1.0,0.20),"style":3},
	{"name":"بنفش عمیق","color":Color(0.68,0.25,1.0),"accent":Color(0.95,0.65,1.0),"style":4},
	{"name":"طلایی","color":Color(1.0,0.68,0.10),"accent":Color(1.0,0.94,0.45),"style":5},
	{"name":"مرجانی","color":Color(1.0,0.28,0.55),"accent":Color(1.0,0.72,0.82),"style":6},
	{"name":"یخی","color":Color(0.45,0.88,1.0),"accent":Color(0.90,1.0,1.0),"style":7},
	{"name":"کهکشانی","color":Color(0.42,0.28,1.0),"accent":Color(1.0,0.35,0.85),"style":8},
	{"name":"رادیواکتیو","color":Color(0.55,1.0,0.08),"accent":Color(0.85,1.0,0.55),"style":9},
	{"name":"تاریک","color":Color(0.10,0.12,0.20),"accent":Color(0.55,0.35,1.0),"style":10},
	{"name":"مرواریدی","color":Color(0.72,0.82,0.92),"accent":Color(1.0,0.98,0.88),"style":11}
]

func set_region_visual_tint(c: Color) -> void:
	region_visual_tint = c
	queue_redraw()

func get_skin() -> Dictionary:
	var idx = clampi(SaveManager.evolution_skin, 0, EVOLUTION_SKINS.size() - 1)
	return EVOLUTION_SKINS[idx]


var radius: float = 20.0
var target_radius: float = 20.0
var pulse_time: float = 0.0
var membrane_points: PackedVector2Array = []
var num_membrane_points: int = 24
var wave_offsets: Array[float] = []
var spikes_count: int = 0
var magnet_radius: float = 80.0
# Ocean power-up timers / one-hit Bio-Shield.
var bio_shield_active: bool = false
var magnet_powerup_timer: float = 0.0
var hyper_speed_timer: float = 0.0
var dna_catalyst_timer: float = 0.0
var powerup_visual_time: float = 0.0

# --- Evolution upgrades (chosen on each level-up, per run) ---
var front_spike_level: int = 0      # شاخک جلو: more damage in front + visual
var rear_spike_level: int = 0       # شاخک عقب: counterattack from behind
var attack_mult: float = 1.0        # ارتقا حمله: global damage multiplier
var evolution_dna_mult: float = 1.0 # ضریب DNA بیشتر
var evolution_regen: int = 0        # ترمیم خودکار
var evolution_magnet: int = 0       # آهنربای جذب غذا
var poison_skin_level: int = 0
var vampirism_level: int = 0
var time_warp_level: int = 0
var armor_level: int = 0
var metabolism_level: int = 0
var thorns_level: int = 0
var dash_level: int = 0
var vitality_level: int = 0
var predator_level: int = 0
var gravity_level: int = 0
var adaptation_level: int = 0
var evolution_extra_levels: Dictionary = {}
var shockwave_unlocked: bool = false
var shockwave_level: int = 0
var shield_unlocked: bool = false
var shield_level: int = 0
var shield_timer: float = 0.0
var shield_cooldown: float = 0.0
var shockwave_cooldown: float = 0.0
var shockwave_timer: float = 0.0
var shockwave_duration: float = 0.55
var shockwave_radius: float = 350.0

# --- Health (jon) system with invulnerability frames ---
var max_hp: float = 85.0
var current_hp: float = 100.0
var invuln_timer: float = 0.0
const INVULN_TIME: float = 0.6

var regen_timer: float = 0.0
var poison_timer: float = 0.0

var move_dir: Vector2 = Vector2.ZERO
var is_boosting: bool = false
var adrenaline_active: bool = false
var adrenaline_pulse: float = 0.0
var adrenaline_speed_timer: float = 0.0
var quest_speed_timer: float = 0.0
var pop_timer: float = 0.0
var pop_scale: Vector2 = Vector2.ONE
var _normal_time_scale: float = 1.0
var boost_stamina: float = 100.0
var max_stamina: float = 100.0

@onready var magnet_area: Area2D = $MagnetArea
@onready var magnet_col: CollisionShape2D = $MagnetArea/CollisionShape2D
@onready var col_shape: CollisionShape2D = $CollisionShape2D

func _ready():
	apply_shop_upgrades()
	max_hp = 85.0 + float(level - 1) * 25.0 + float(vitality_level) * 10.0
	current_hp = max_hp
	hp_changed.emit(current_hp, max_hp)
	update_stats()
	for i in range(num_membrane_points):
		wave_offsets.append(randf_range(0.0, TAU))

func apply_shop_upgrades():
	base_speed += SaveManager.upgrade_speed * 25.0
	magnet_radius = 80.0 + (SaveManager.upgrade_attract * 35.0) + (evolution_magnet * 55.0)
	spikes_count = SaveManager.upgrade_spike * 3
	if magnet_col and magnet_col.shape is CircleShape2D:
		magnet_col.shape.radius = magnet_radius

func update_stats():
	target_radius = 16.0 + sqrt(mass) * 3.2
	var req_mass = get_req_mass_for_level(level)
	mass_changed.emit(mass, req_mass)

func get_req_mass_for_level(lvl: int) -> float:
	return 25.0 + pow(lvl, 1.8) * 30.0

func _process(delta):
	if not alive:
		return
	var low_hp: bool = get_hp_ratio() <= 0.20
	if low_hp != adrenaline_active:
		adrenaline_active = low_hp
		Engine.time_scale = 0.65 if adrenaline_active else _normal_time_scale
		adrenaline_changed.emit(adrenaline_active, 0.0)
	if adrenaline_active:
		adrenaline_pulse += delta * 5.0
		adrenaline_changed.emit(true, 0.5 + 0.5 * sin(adrenaline_pulse))
	if adrenaline_speed_timer > 0.0:
		adrenaline_speed_timer = maxf(0.0, adrenaline_speed_timer - delta)
	if quest_speed_timer > 0.0:
		quest_speed_timer = maxf(0.0, quest_speed_timer - delta)
	magnet_powerup_timer = maxf(0.0, magnet_powerup_timer - delta)
	hyper_speed_timer = maxf(0.0, hyper_speed_timer - delta)
	dna_catalyst_timer = maxf(0.0, dna_catalyst_timer - delta)
	powerup_visual_time += delta
	if pop_timer > 0.0:
		pop_timer = maxf(0.0, pop_timer - delta)
		var pop: float = sin((1.0 - pop_timer / 0.22) * PI) * 0.12
		pop_scale = Vector2(1.0 + pop, 1.0 - pop * 0.65)
	else:
		pop_scale = pop_scale.lerp(Vector2.ONE, minf(1.0, delta * 12.0))
	radius = lerp(radius, target_radius, 8.0 * delta)
	if col_shape.shape is CircleShape2D:
		col_shape.shape.radius = radius
	if is_boosting and boost_stamina > 5.0:
		current_speed = boost_speed + (SaveManager.upgrade_speed * 30.0)
		if adrenaline_speed_timer > 0.0:
			current_speed *= 1.35
		if quest_speed_timer > 0.0:
			current_speed *= 1.20
		boost_stamina = max(0.0, boost_stamina - 40.0 * delta)
		if mass > 15.0:
			add_mass(-1.0 * delta, false)
	else:
		current_speed = base_speed * (1.35 if adrenaline_speed_timer > 0.0 else 1.0) * (1.20 if quest_speed_timer > 0.0 else 1.0)
		boost_stamina = min(max_stamina, boost_stamina + 25.0 * delta)
	if combo_count > 0:
		combo_timer -= delta
		if combo_timer <= 0.0:
			combo_count = 0
	# Health regeneration upgrade
	var regen_power: int = SaveManager.upgrade_regen + evolution_regen
	if invuln_timer > 0.0:
		invuln_timer = max(0.0, invuln_timer - delta)
	if regen_power > 0 and mass < get_req_mass_for_level(level) * 0.75:
		regen_timer += delta
		if regen_timer >= 1.0:
			regen_timer = 0.0
			add_mass(regen_power * 0.8, false)
	pulse_time += delta * 4.0
	generate_membrane()
	queue_redraw()

func _physics_process(delta):
	if not alive:
		return
	var input_vector = Vector2.ZERO
	if Input.is_action_pressed("ui_right") or Input.is_key_pressed(KEY_D):
		input_vector.x += 1
	if Input.is_action_pressed("ui_left") or Input.is_key_pressed(KEY_A):
		input_vector.x -= 1
	if Input.is_action_pressed("ui_down") or Input.is_key_pressed(KEY_S):
		input_vector.y += 1
	if Input.is_action_pressed("ui_up") or Input.is_key_pressed(KEY_W):
		input_vector.y -= 1
	if move_dir.length_squared() > 0.01:
		input_vector = move_dir
	if use_pointer and input_vector == Vector2.ZERO:
		# جهت حرکت از مختصات صفحه (نه جهان) -> حلقه بازخورد دوربین کاملاً قطع می‌شود
		var screen_center: Vector2 = get_viewport_rect().size * 0.5
		var touch_screen_pos: Vector2 = get_viewport().get_mouse_position()
		var screen_dir: Vector2 = touch_screen_pos - screen_center
		if screen_dir.length() > 24.0:
			input_vector = screen_dir.normalized()
	var smooth_factor: float = 1.0 - exp(-10.0 * delta)
	if input_vector != Vector2.ZERO:
		var target_velocity: Vector2 = input_vector.normalized() * current_speed
		velocity = velocity.lerp(target_velocity, smooth_factor)
		var angle_smooth: float = 1.0 - exp(-12.0 * delta)
		rotation = lerp_angle(rotation, target_velocity.angle(), angle_smooth)
	else:
		velocity = velocity.lerp(Vector2.ZERO, 1.0 - exp(-4.0 * delta))
	if hyper_speed_timer > 0.0:
		current_speed *= 1.65
		velocity = velocity.limit_length(current_speed)
	else:
		velocity = velocity.limit_length(current_speed)
	# Refresh time-warp state each physics frame so enemies leaving the aura recover.
	for enemy in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(enemy) and "slow_factor" in enemy:
			enemy.slow_factor = 1.0
	if time_warp_level > 0:
		var warp_radius: float = 250.0 + 50.0 * float(time_warp_level)
		for enemy in get_tree().get_nodes_in_group("enemies"):
			if is_instance_valid(enemy) and global_position.distance_to(enemy.global_position) <= warp_radius:
				enemy.slow_factor = 0.55
	move_and_slide()
	attract_food(delta)
	check_enemy_contacts()
	if shield_timer > 0.0:
		shield_timer = maxf(0.0, shield_timer - delta)
	if shield_cooldown > 0.0:
		shield_cooldown = maxf(0.0, shield_cooldown - delta)
	if shockwave_cooldown > 0.0:
		shockwave_cooldown = maxf(0.0, shockwave_cooldown - delta)
	if shockwave_timer > 0.0:
		shockwave_timer = maxf(0.0, shockwave_timer - delta)
	queue_redraw()

func check_enemy_contacts():
	# Reliable contact detection: slide collisions AND direct distance checks
	if not alive:
		return
	var contacted : bool = false
	for i in range(get_slide_collision_count()):
		var col = get_slide_collision(i).get_collider()
		if col and col.is_in_group("enemies") and is_instance_valid(col):
			contacted = true
			col.handle_player_encounter()
			break
	if not contacted:
		for e in get_tree().get_nodes_in_group("enemies"):
			if not is_instance_valid(e) or not e.has_method("handle_player_encounter"):
				continue
			if global_position.distance_to(e.global_position) < radius + e.radius:
				e.handle_player_encounter()
				break

func heal(amount: float):
	if not alive:
		return
	current_hp = minf(max_hp, current_hp + amount)
	hp_changed.emit(current_hp, max_hp)

func get_hp_ratio() -> float:
	return clampf(current_hp / maxf(max_hp, 1.0), 0.0, 1.0)

func _unhandled_input(event):
	if event is InputEventScreenTouch or event is InputEventMouseButton:
		use_pointer = event.pressed
	elif event is InputEventScreenDrag:
		use_pointer = true

func attract_food(delta):
	if magnet_powerup_timer > 0.0:
		# Full-screen attraction with a distance falloff; skip distant entities for mobile performance.
		for food in get_tree().get_nodes_in_group("food"):
			if not is_instance_valid(food): continue
			var offset: Vector2 = global_position - food.global_position
			var dist: float = offset.length()
			if dist > 1700.0 or dist < 1.0: continue
			food.global_position += offset / dist * minf(1100.0, 180.0 + (1.0 - dist / 1700.0) * 820.0) * delta
	if not magnet_area:
		return
	var areas = magnet_area.get_overlapping_areas()
	for a in areas:
		if a.is_in_group("food"):
			var dir = (global_position - a.global_position).normalized()
			var dist = global_position.distance_to(a.global_position)
			var pull_force = (1.0 - (dist / magnet_radius)) * 280.0
			a.position += dir * pull_force * delta

func generate_membrane():
	membrane_points.clear()
	for i in range(num_membrane_points):
		var angle = (float(i) / num_membrane_points) * TAU
		var wobble = sin(pulse_time * 2.0 + wave_offsets[i]) * (radius * 0.08)
		var r = radius + wobble
		membrane_points.append(Vector2(cos(angle) * r, sin(angle) * r))

func _draw():
	if not alive:
		return
	draw_set_transform(Vector2.ZERO, 0.0, pop_scale)
	var skin: Dictionary = get_skin()
	var skin_color: Color = skin["color"]
	var skin_accent: Color = skin["accent"]
	var skin_style: int = int(skin["style"])
	# فروشگاه تکامل فقط ظاهر را تغییر می‌دهد؛ تم منطقه روی رنگ غالب می‌شود.
	if skin_style == 1:
		for k in range(7):
			var a = pulse_time * 0.4 + float(k) * TAU / 7.0
			var p1 = Vector2(cos(a), sin(a)) * radius * 1.0
			var p2 = Vector2(cos(a), sin(a)) * radius * (1.35 + 0.08 * sin(pulse_time * 3.0 + k))
			draw_line(p1, p2, skin_accent, 3.0, true)
	elif skin_style == 2:
		for k in range(6):
			var a = float(k) * TAU / 6.0 + pulse_time * 0.15
			var p = Vector2(cos(a), sin(a)) * radius * 1.18
			draw_colored_polygon(PackedVector2Array([p, p.rotated(0.22) * 1.12, p.rotated(-0.22) * 1.12]), skin_accent)
	elif skin_style == 4 or skin_style == 8:
		for k in range(10):
			var a = pulse_time * 0.6 + float(k) * TAU / 10.0
			var p = Vector2(cos(a), sin(a)) * radius * (0.55 + 0.18 * sin(k * 2.0 + pulse_time))
			draw_circle(p, radius * 0.045 + 1.0, skin_accent)
	elif skin_style == 5:
		draw_arc(Vector2.ZERO, radius * 1.38, pulse_time, pulse_time + PI * 1.35, 36, skin_accent, 6.0, true)
	elif skin_style == 6:
		for k in range(8):
			var a = float(k) * TAU / 8.0
			var p = Vector2(cos(a), sin(a)) * radius * 1.12
			draw_circle(p, radius * 0.14, skin_accent)
	elif skin_style == 7:
		draw_arc(Vector2.ZERO, radius * 1.46, -pulse_time, -pulse_time + PI, 32, skin_accent, 4.0, true)
		draw_arc(Vector2.ZERO, radius * 1.34, -pulse_time + PI, -pulse_time + TAU, 32, skin_accent, 3.0, true)
	elif skin_style == 9:
		for k in range(5):
			var a = pulse_time * 0.3 + k * TAU / 5.0
			draw_line(Vector2(cos(a),sin(a))*radius*0.5, Vector2(cos(a),sin(a))*radius*1.5, skin_accent, 2.0, true)
	elif skin_style == 10:
		draw_arc(Vector2.ZERO, radius * 1.5, 0, TAU, 48, skin_accent, 5.0, true)
	elif skin_style == 11:
		draw_circle(Vector2.ZERO, radius * 0.93, Color(0.9,0.95,1.0,0.18))
	var glow_level: int = SaveManager.upgrade_glow
	var breath: float = 0.5 + 0.5 * sin(pulse_time * 1.4)
	var blended_color: Color = skin_color.lerp(region_visual_tint, 0.32)
	var aura_color: Color = Color(blended_color.r, blended_color.g, blended_color.b, 0.12 + glow_level * 0.06 + breath * 0.04)
	# Outer translucent glow and a second, softer membrane ring.
	draw_circle(Vector2.ZERO, radius * (1.48 + glow_level * 0.12), aura_color)
	draw_circle(Vector2.ZERO, radius * 1.28, Color(blended_color.r, blended_color.g, blended_color.b, 0.08 + breath * 0.04))
	draw_arc(Vector2.ZERO, radius * 1.16, 0, TAU, 48, Color(skin_accent.r, skin_accent.g, skin_accent.b, 0.28 + breath * 0.12), 2.0, true)
	# Organic undulating plasma membrane; pre-generated points have independent phases.
	if membrane_points.size() >= 3:
		var center_color: Color = Color(blended_color.r * 0.65, blended_color.g * 0.65, blended_color.b * 0.78, 0.88)
		var edge_color: Color = Color(skin_accent.r, skin_accent.g, skin_accent.b, 0.9)
		draw_colored_polygon(membrane_points, center_color)
		for i in range(membrane_points.size()):
			var p1: Vector2 = membrane_points[i]
			var p2: Vector2 = membrane_points[(i + 1) % membrane_points.size()]
			draw_line(p1, p2, edge_color, 2.6, true)
			draw_circle(p1, 1.4 + 0.6 * breath, Color(0.72, 1.0, 0.96, 0.48))
	# Soft internal cytoplasm wash.
	draw_circle(Vector2.ZERO, radius * 0.84, Color(0.24, 0.72, 0.82, 0.24))
	# Power-up Bio-Shield: brighter layered bubble, visually distinct from the upgrade shield.
	if bio_shield_active:
		var bio_alpha: float = 0.58 + 0.18 * sin(powerup_visual_time * 9.0)
		draw_circle(Vector2.ZERO, radius + 25.0, Color(0.28, 0.96, 1.0, 0.10))
		draw_arc(Vector2.ZERO, radius + 22.0 + sin(powerup_visual_time * 5.0) * 2.0, 0, TAU, 56, Color(0.55, 1.0, 1.0, bio_alpha), 5.0, true)
		draw_arc(Vector2.ZERO, radius + 29.0, 0, TAU, 56, Color(0.2, 0.78, 1.0, bio_alpha * 0.55), 2.0, true)
	# Hyper-speed streaks stream behind the movement direction.
	if hyper_speed_timer > 0.0 and velocity.length() > 10.0:
		var back: Vector2 = -velocity.normalized()
		for i in range(5):
			var side: Vector2 = back.rotated(PI * 0.5) * (float(i) - 2.0) * radius * 0.22
			var trail_len: float = radius * (0.8 + 0.12 * float(i % 3))
			draw_line(side, side + back * trail_len, Color(0.28, 0.95, 1.0, 0.58 - 0.06 * float(i % 3)), 2.5, true)
	# Active shield bubble and expanding shockwave.
	if shield_timer > 0.0:
		var shield_alpha: float = 0.38 + 0.12 * sin(pulse_time * 12.0)
		draw_circle(Vector2.ZERO, radius + 18.0, Color(0.15, 0.9, 1.0, 0.12))
		draw_arc(Vector2.ZERO, radius + 18.0, 0, TAU, 48, Color(0.25, 0.95, 1.0, shield_alpha), 4.0, true)
	if shockwave_timer > 0.0:
		var wave_progress: float = 1.0 - shockwave_timer / shockwave_duration
		var wave_radius: float = lerpf(radius, shockwave_radius, wave_progress)
		var wave_alpha: float = 1.0 - wave_progress
		draw_arc(Vector2.ZERO, wave_radius, 0, TAU, 64, Color(1.0, 0.72, 0.2, wave_alpha), 7.0, true)
		draw_circle(Vector2.ZERO, wave_radius, Color(1.0, 0.45, 0.12, 0.035 * wave_alpha))
	# Shield ring (defense upgrade).
	if SaveManager.upgrade_defense > 0:
		var shield_a: float = 0.15 + SaveManager.upgrade_defense * 0.07
		draw_arc(Vector2.ZERO, radius + 8.0, 0, TAU, 40, Color(0.4, 0.7, 1.0, shield_a + 0.25), 3.0 + SaveManager.upgrade_defense, true)
	# Shop spikes (all around).
	if spikes_count > 0:
		for i in range(spikes_count):
			var sp_angle: float = (float(i) / float(spikes_count)) * TAU + pulse_time * 0.5
			var base_p: Vector2 = Vector2(cos(sp_angle) * radius, sin(sp_angle) * radius)
			var tip_p: Vector2 = Vector2(cos(sp_angle) * (radius + 12.0), sin(sp_angle) * (radius + 12.0))
			draw_line(base_p, tip_p, Color(1.0, 0.4, 0.2, 0.9), 3.0, true)
	# Evolution spike: FRONT (local +X = movement direction).
	if front_spike_level > 0:
		var len_f: float = 14.0 + front_spike_level * 8.0
		var col_f: Color = Color(1.0, 0.35, 0.15, 0.95)
		for k in range(front_spike_level):
			var off: float = (float(k) - (front_spike_level - 1) * 0.5) * 0.35
			var dir_f: Vector2 = Vector2(cos(off), sin(off))
			draw_line(dir_f * radius * 0.9, dir_f * (radius + len_f), col_f, 4.0 + front_spike_level, true)
			draw_circle(dir_f * (radius + len_f), 2.5, Color(1.0, 0.8, 0.4, 0.9))
	if rear_spike_level > 0:
		var len_r: float = 12.0 + rear_spike_level * 6.0
		var col_r: Color = Color(0.8, 0.25, 0.9, 0.95)
		for k in range(rear_spike_level):
			var off_r: float = PI + (float(k) - (rear_spike_level - 1) * 0.5) * 0.35
			var dir_r: Vector2 = Vector2(cos(off_r), sin(off_r))
			draw_line(dir_r * radius * 0.9, dir_r * (radius + len_r), col_r, 3.5 + rear_spike_level, true)
			draw_circle(dir_r * (radius + len_r), 2.0, Color(1.0, 0.6, 1.0, 0.9))
	if invuln_timer > 0.0:
		draw_arc(Vector2.ZERO, radius + 10.0, 0, TAU, 32, Color(1.0, 0.3, 0.3, 0.4 + 0.4 * sin(pulse_time * 10.0)), 4.0, true)

	# Distinct nucleus with a bright nucleolus.
	var nucleus_rad: float = radius * 0.42 * (1.0 + 0.05 * sin(pulse_time * 2.0))
	var nucleus_pos: Vector2 = Vector2(sin(pulse_time * 0.6) * radius * 0.045, cos(pulse_time * 0.8) * radius * 0.035)
	draw_circle(nucleus_pos, nucleus_rad * 1.13, Color(0.05, 0.18, 0.48, 0.25))
	draw_circle(nucleus_pos, nucleus_rad, Color(0.07, 0.29, 0.63, 0.92))
	draw_circle(nucleus_pos, nucleus_rad * 0.74, Color(0.18, 0.55, 0.83, 0.92))
	var nucleolus_pos: Vector2 = nucleus_pos + Vector2(-nucleus_rad * 0.22, -nucleus_rad * 0.16)
	draw_circle(nucleolus_pos, nucleus_rad * 0.32, Color(0.74, 0.95, 1.0, 0.95))
	draw_circle(nucleolus_pos - Vector2(nucleus_rad * 0.07, nucleus_rad * 0.07), nucleus_rad * 0.11, Color(1, 1, 1, 0.9))

	# Cytoplasm granules and small mitochondria distributed around the nucleus.
	var dot_count: int = min(12, 5 + level)
	for i in range(dot_count):
		var dot_ang: float = (float(i) / float(dot_count)) * TAU + pulse_time * 0.22
		var dot_dist: float = radius * (0.58 + 0.08 * sin(float(i) * 2.4 + pulse_time))
		var dot_pos: Vector2 = Vector2(cos(dot_ang) * dot_dist, sin(dot_ang) * dot_dist)
		var dot_rad: float = 1.8 + float(i % 3) * 0.45
		draw_circle(dot_pos, dot_rad * 1.7, Color(0.48, 1.0, 0.8, 0.12))
		draw_circle(dot_pos, dot_rad, Color(0.56, 1.0, 0.7, 0.7))
	for i in range(3):
		var ma: float = pulse_time * 0.16 + float(i) * TAU / 3.0
		var mp: Vector2 = Vector2(cos(ma) * radius * 0.67, sin(ma) * radius * 0.67)
		draw_circle(mp, radius * 0.115, Color(0.1, 0.55, 0.44, 0.82))
		draw_arc(mp, radius * 0.115, 0, TAU, 16, Color(0.54, 1.0, 0.73, 0.75), 1.2, true)
		for k in range(3):
			var crinkle: float = (float(k) - 1.0) * 0.035
			draw_line(mp + Vector2(-radius * 0.06, radius * crinkle), mp + Vector2(radius * 0.06, -radius * crinkle), Color(0.78, 1.0, 0.78, 0.55), 0.9, true)


	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func eat(food_node):
	if not alive:
		return
	var val = food_node.value
	var dna = food_node.dna_value
	var world = get_parent()
	if val < 0:
		SoundManager.play_hit()
		add_mass(val, false)
	else:
		SoundManager.play_eat_food(combo_count + 1)
		var growth_bonus: float = 1.0 + float(metabolism_level) * 0.08 + float(evolution_extra_levels.get("growth", 0)) * 0.045
		add_mass(val * growth_bonus, true)
		combo_count += 1
		combo_timer = get_combo_window()
		food_eaten.emit(val)
		combo_reached.emit(combo_count)
		pop_timer = 0.22
		var mult: float = 1.0 + min(float(combo_count - 1), 9) * 0.1
		var gained : int = int(val * 10 * level * mult)
		score += gained
		if combo_count >= 2:
			spawn_float_text("+%d  کمبو x%d" % [gained, combo_count], Color(1.0, 0.85, 0.3), world)
			if combo_count % 5 == 0:
				spawn_float_text("🔥 کمبوی داغ! x%d" % combo_count, Color(1.0, 0.4, 0.2), world, 34)
		else:
			spawn_float_text("+%d" % gained, Color(0.6, 1.0, 0.7), world)
		if dna > 0:
			SoundManager.play_eat_dna()
			add_dna(dna)
			spawn_float_text("🧬 +%d DNA" % dna, Color(0.9, 0.5, 1.0), world, 30)
	score_updated.emit(score)
	update_stats()
	check_evolution()

func add_mass(amount: float, show_text: bool = false):
	# Central mass adder: regen/shield/DNA upgrades apply here too
	if not alive:
		return
	if amount > 0 and SaveManager.upgrade_defense > 0 and show_text == false:
		amount *= 1.0
	mass += amount
	mass = max(10.0, mass)
	if amount > 0 and show_text:
		spawn_float_text("+جرم %d" % int(amount), Color(0.5, 1.0, 0.8), get_parent(), 22)
	update_stats()
	check_evolution()

func add_dna(amount: int):
	# Catalyst doubles final DNA after permanent/evolution multipliers for 15 seconds.
	var bonus = (1.0 + SaveManager.upgrade_dna_boost * 0.10) * evolution_dna_mult
	if dna_catalyst_timer > 0.0:
		bonus *= 2.0
	SaveManager.add_dna(int(round(amount * bonus)))

func check_evolution():
	# Can evolve multiple levels in one bite
	var guard : int = 0
	while mass >= get_req_mass_for_level(level) and guard < 10:
		guard += 1
		evolve_once()

func evolve_once():
	level += 1
	mass = mass * 0.65
	max_hp += 25.0
	current_hp = minf(max_hp, current_hp + 35.0)
	hp_changed.emit(current_hp, max_hp)
	var dna_bonus : int = 2 + level
	add_dna(dna_bonus)
	base_speed += 6.0
	boost_speed += 8.0
	SoundManager.play_evolve()
	SaveManager.update_score(score, level)
	var world = get_parent()
	spawn_float_text("🎉 تکامل! سطح %d" % level, Color(1.0, 0.9, 0.2), world, 40)
	evolved.emit(level, {"level": level, "mass": mass, "speed": base_speed})
	# Ask the UI to show the evolution upgrade choice panel (like the old version)
	evolution_choice_requested.emit(level)
	update_stats()

func take_damage(dmg: float, from_pos: Vector2 = Vector2.INF):
	if not alive or invuln_timer > 0.0 or shield_timer > 0.0:
		return
	if bio_shield_active:
		bio_shield_active = false
		invuln_timer = INVULN_TIME
		SoundManager.play_shield_break()
		spawn_float_text("💎 سپر زیستی شکست!", Color(0.42, 0.95, 1.0), get_parent(), 30)
		queue_redraw()
		return
	var defense_mult = 1.0 - (SaveManager.upgrade_defense * 0.12) - (armor_level * 0.045) - (evolution_extra_levels.get("hunter_resist", 0) * 0.025)
	defense_mult = maxf(0.35, defense_mult)
	var actual_dmg = dmg * defense_mult
	# Front spike: hitting us head-on hurts the attacker too (reinforced tip)
	if front_spike_level > 0 and from_pos != Vector2.INF:
		var to_attacker: Vector2 = (from_pos - global_position).normalized()
		var facing : Vector2 = Vector2(cos(rotation), sin(rotation))
		if facing.dot(to_attacker) > 0.35:  # attacker is in front
			actual_dmg *= maxf(0.35, 1.0 - front_spike_level * 0.2)
			spawn_float_text("🛡 شاخک جلو!", Color(1.0, 0.6, 0.2), get_parent(), 26)
			reflect_damage(from_pos, dmg * 0.5 * front_spike_level * attack_mult)
	# Rear spike: counterattack when hit from behind
	if rear_spike_level > 0 and from_pos != Vector2.INF:
		var to_a: Vector2 = (from_pos - global_position).normalized()
		var fwd : Vector2 = Vector2(cos(rotation), sin(rotation))
		if fwd.dot(to_a) < -0.35:  # attacker is behind us
			spawn_float_text("⚡ شاخک عقب!", Color(0.9, 0.4, 1.0), get_parent(), 26)
			reflect_damage(from_pos, dmg * 0.6 * rear_spike_level * attack_mult)
	if thorns_level > 0 and from_pos != Vector2.INF:
		reflect_damage(from_pos, (2.5 + float(thorns_level) * 2.0) * attack_mult)
	current_hp -= actual_dmg
	damage_taken.emit(from_pos if from_pos != Vector2.INF else global_position, actual_dmg)
	if get_hp_ratio() <= 0.20 and not adrenaline_active:
		adrenaline_speed_timer = 2.5
	invuln_timer = INVULN_TIME
	SoundManager.play_hit()
	spawn_float_text("-%d" % int(actual_dmg), Color(1.0, 0.35, 0.3), get_parent(), 34)
	hp_changed.emit(current_hp, max_hp)
	queue_redraw()
	if current_hp <= 0.0:
		die()

func heal_from_combat(amount: float):
	if vampirism_level > 0 and amount > 0.0:
		heal(amount * (0.04 * float(vampirism_level)))

func apply_ocean_powerup(powerup_type: String) -> void:
	if not alive: return
	match powerup_type:
		"bio_shield":
			bio_shield_active = true
			spawn_float_text("🛡 سپر فعال شد", Color(0.4, 0.9, 1.0), get_parent(), 30)
		"magnet":
			magnet_powerup_timer = 12.0
			spawn_float_text("🧲 آهنربا فعال شد", Color(1.0, 0.6, 0.2), get_parent(), 30)
		"hyper_speed":
			hyper_speed_timer = 8.0
			spawn_float_text("⚡ سرعت فوق‌العاده", Color(1.0, 0.9, 0.3), get_parent(), 30)
		"dna_catalyst":
			dna_catalyst_timer = 15.0
			spawn_float_text("🌟 جهش DNA دوبرابر", Color(0.55, 1.0, 0.42), get_parent(), 30)
		_:
			pass
	queue_redraw()

func activate_shield() -> void:
	if not alive or not shield_unlocked or shield_cooldown > 0.0:
		return
	shield_timer = 3.0
	shield_cooldown = 12.0
	queue_redraw()

func activate_shockwave() -> void:
	if not alive or not shockwave_unlocked or shockwave_cooldown > 0.0:
		return
	shockwave_cooldown = 8.0
	shockwave_timer = shockwave_duration
	for enemy in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(enemy):
			continue
		var offset: Vector2 = enemy.global_position - global_position
		if offset.length() <= shockwave_radius:
			var damage: float = (12.0 + 8.0 * float(shockwave_level)) * attack_mult
			if enemy.has_method("take_damage"):
				enemy.take_damage(damage)
			if "velocity" in enemy:
				var push_dir: Vector2 = offset.normalized()
				if push_dir == Vector2.ZERO:
					push_dir = Vector2.RIGHT
				enemy.velocity += push_dir * (420.0 + 80.0 * float(shockwave_level))
	queue_redraw()

func apply_front_spike_hit(enemy_pos: Vector2, enemy: Node):
	# EnemyCell contact handler: front spike boosts our attack, rear spike counters
	if not alive or enemy == null:
		return
	var fwd : Vector2 = Vector2(cos(rotation), sin(rotation))
	var to_enemy: Vector2 = (enemy_pos - global_position).normalized()
	if front_spike_level > 0 and fwd.dot(to_enemy) > 0.35 and enemy.has_method("take_damage"):
		enemy.take_damage(6.0 * front_spike_level * attack_mult)
	elif rear_spike_level > 0 and fwd.dot(to_enemy) < -0.35 and enemy.has_method("take_damage"):
		enemy.take_damage(8.0 * rear_spike_level * attack_mult)

func reflect_damage(from_pos: Vector2, amount: float):
	# Counterattack: damage nearby enemy cells at/behind the hit position
	if amount <= 0.0:
		return
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or not e.has_method("take_damage"):
			continue
		if global_position.distance_to(e.global_position) < radius + 70.0:
			e.take_damage(amount)
			spawn_float_text("-%d" % int(amount), Color(1.0, 0.5, 0.15), get_parent(), 24)
			break

func get_attack_mult() -> float:
	return attack_mult

func die():
	alive = false
	SoundManager.play_hit()
	SaveManager.update_score(score, level)
	player_died.emit()
	queue_redraw()

func apply_evolution_upgrade(key: String):
	# Called by the UI EvolutionChoice overlay when the player picks an upgrade
	match key:
		"spike_front":
			front_spike_level += 1
			attack_mult += 0.12   # reinforced front spike: stronger frontal attack
		"spike_rear":
			rear_spike_level += 1
		"attack":
			attack_mult += 0.20
		"health":
			add_mass(18.0, false)   # max health equivalent: mass/jon + heal
		"speed":
			base_speed *= 1.10
			boost_speed *= 1.10
		"magnet":
			evolution_magnet += 1
			magnet_radius += 55.0
			if magnet_col and magnet_col.shape is CircleShape2D:
				magnet_col.shape.radius = magnet_radius
		"regen":
			evolution_regen += 1
		"dna":
			evolution_dna_mult += 0.12
		"shockwave":
			shockwave_unlocked = true
			shockwave_level += 1
		"shield":
			shield_unlocked = true
			shield_level += 1
		"poison_skin":
			poison_skin_level += 1
		"vampirism":
			vampirism_level += 1
		"time_warp":
			time_warp_level += 1
		"armor":
			armor_level += 1
		"metabolism":
			metabolism_level += 1
		"thorns":
			thorns_level += 1
		"dash":
			dash_level += 1
			base_speed *= 1.06
			boost_speed *= 1.06
		"vitality":
			vitality_level += 1
			max_hp += 12.0
			current_hp = minf(max_hp, current_hp + 18.0)
		"predator":
			predator_level += 1
			attack_mult += 0.10
		"gravity":
			gravity_level += 1
			magnet_radius += 45.0
			if magnet_col and magnet_col.shape is CircleShape2D:
				magnet_col.shape.radius = magnet_radius
		"adaptation":
			adaptation_level += 1
			base_speed *= 1.03
			attack_mult += 0.04
		"critical":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
		"growth":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
		"stamina":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
			max_stamina += 10.0
			boost_stamina = max_stamina
		"combo_master":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
		"hunter_resist":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
		"hunter_damage":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
			attack_mult += 0.06
		"luck":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
		"pulse":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
			shockwave_radius += 18.0
		"giant_core":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
			add_mass(12.0, false)
		"adaptation_plus":
			evolution_extra_levels[key] = int(evolution_extra_levels.get(key, 0)) + 1
			base_speed *= 1.02
			attack_mult += 0.025
		_: 
			return
	spawn_float_text("✅ ارتقا اعمال شد", Color(0.5, 1.0, 0.7), get_parent(), 26)
	queue_redraw()

func spawn_float_text(txt: String, col: Color, parent_node: Node, fsize: int = 26):
	if parent_node == null or not is_instance_valid(parent_node):
		return
	var lbl: Label = Label.new()
	lbl.text = txt
	lbl.z_index = 100
	lbl.top_level = true
	lbl.global_position = global_position + Vector2(randf_range(-30, 30), -radius - 30.0)
	lbl.add_theme_font_size_override("font_size", fsize)
	lbl.add_theme_color_override("font_color", col)
	lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	lbl.add_theme_constant_override("outline_size", 8)
	parent_node.add_child(lbl)
	var tw: Tween = lbl.create_tween()
	tw.set_parallel(true)
	tw.tween_property(lbl, "global_position", lbl.global_position + Vector2(0, -70.0), 0.9).set_ease(Tween.EASE_OUT)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.9).set_ease(Tween.EASE_IN)
	tw.chain().tween_callback(lbl.queue_free)

func _exit_tree() -> void:
	if Engine.time_scale != _normal_time_scale:
		Engine.time_scale = _normal_time_scale
