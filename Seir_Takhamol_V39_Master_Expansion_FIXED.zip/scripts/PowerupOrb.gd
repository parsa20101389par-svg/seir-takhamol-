extends Node2D
# آیتم شناور اقیانوسی: پاورآپ نوری با جلوه‌های متحرک، چرخش ملایم و آیکون شناور

var bob_time: float = randf() * TAU
const ORB_RADIUS: float = 20.0

func _process(delta: float) -> void:
	bob_time += delta
	rotation += 0.8 * delta
	position += Vector2(sin(bob_time * 1.1) * 7.0, cos(bob_time * 1.5) * 5.0) * delta
	queue_redraw()

func _draw() -> void:
	var col: Color = get_meta("orb_color", Color(0.3, 0.9, 1.0))
	var ptype: String = get_meta("powerup_type", "")
	var pulse: float = 0.5 + 0.5 * sin(bob_time * 4.5)
	var glow_rad: float = ORB_RADIUS + 9.0 + pulse * 5.0
	
	# هاله بیرونی
	draw_circle(Vector2.ZERO, glow_rad, Color(col.r, col.g, col.b, 0.18 + pulse * 0.12))
	# موج نوری متناوب
	draw_arc(Vector2.ZERO, glow_rad - 2.0, 0, TAU, 36, Color(col.r, col.g, col.b, 0.45 * pulse), 1.5, true)
	# بدنه حباب
	draw_circle(Vector2.ZERO, ORB_RADIUS, Color(col.r * 0.35, col.g * 0.35, col.b * 0.35, 0.75))
	draw_arc(Vector2.ZERO, ORB_RADIUS, 0, TAU, 36, Color(col.r, col.g, col.b, 0.95), 2.2, true)
	
	# های‌لایت درخشش شیشه‌ای حباب
	draw_circle(Vector2(-ORB_RADIUS * 0.35, -ORB_RADIUS * 0.35), ORB_RADIUS * 0.28, Color(1, 1, 1, 0.85))
	
	# نشانگر نمادین داخلی بدون نیاز به فونت بر اساس نوع پاورآپ
	match ptype:
		"bio_shield":
			# نماد سپر (چندضلعی)
			var pts: PackedVector2Array = PackedVector2Array([
				Vector2(0, -9), Vector2(8, -4), Vector2(6, 6), Vector2(0, 10), Vector2(-6, 6), Vector2(-8, -4)
			])
			draw_colored_polygon(pts, Color(1.0, 1.0, 1.0, 0.9))
		"magnet":
			# نماد نعل اسب آهنربایی
			draw_arc(Vector2(0, -2), 7.0, PI * 0.8, PI * 2.2, 16, Color(1.0, 1.0, 1.0, 0.95), 3.0, true)
			draw_rect(Rect2(-8, -2, 3.5, 9), Color(1.0, 0.3, 0.3, 0.95))
			draw_rect(Rect2(4.5, -2, 3.5, 9), Color(0.3, 0.6, 1.0, 0.95))
		"hyper_speed":
			# نماد صاعقه سرعت
			var pts: PackedVector2Array = PackedVector2Array([
				Vector2(2, -10), Vector2(-6, 0), Vector2(0, 0), Vector2(-2, 10), Vector2(6, -1), Vector2(0, -1)
			])
			draw_colored_polygon(pts, Color(1.0, 1.0, 0.4, 0.95))
		"dna_catalyst":
			# نماد ستاره ۴ پره DNA
			for i in range(4):
				var ang: float = float(i) * (PI * 0.5)
				var arm_tip: Vector2 = Vector2(cos(ang), sin(ang)) * 9.0
				draw_line(Vector2.ZERO, arm_tip, Color(0.6, 1.0, 0.5, 0.95), 3.0, true)
				draw_circle(arm_tip, 2.5, Color(1.0, 1.0, 1.0, 0.95))
		"dna_treasure":
			draw_circle(Vector2.ZERO, 9.0, Color(0.95, 0.35, 1.0, 0.95))
			draw_arc(Vector2.ZERO, 13.0, 0, TAU, 20, Color(1.0, 0.8, 1.0, 0.95), 2.5, true)
			for i in range(4):
				var a = float(i) * PI * 0.5 + 0.2
				draw_line(Vector2(cos(a), sin(a)) * 4.0, Vector2(cos(a), sin(a)) * 12.0, Color(1,1,1,0.9), 2.0, true)
		_: 
			draw_circle(Vector2.ZERO, 5.0, Color(1, 1, 1, 0.9))
