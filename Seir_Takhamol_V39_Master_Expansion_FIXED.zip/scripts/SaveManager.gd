extends Node

var save_path: String = "user://seir_takhamol_save.json"

var high_score: int = 0
var max_level: int = 1
var total_dna: int = 0
var sound_enabled: bool = true
var music_enabled: bool = true
var evolution_skin: int = 0
var owned_evolution_skins: Array = [0]
var player_name: String = ""
var account_phone_hash: String = ""
var account_verified: bool = false
const ACCOUNT_PATH: String = "user://seir_takhamol_accounts.json"

var upgrade_speed: int = 0
var upgrade_attract: int = 0
var upgrade_defense: int = 0
var upgrade_spike: int = 0
var upgrade_glow: int = 0
var upgrade_regen: int = 0
var upgrade_poison: int = 0
var upgrade_dna_boost: int = 0
var last_daily_claim: String = ""
var daily_streak: int = 0
var weekly_progress: Dictionary = {"food": 0, "enemy": 0, "survive": 0}
var weekly_reset_key: String = ""
var weekly_claimed: Dictionary = {"food": false, "enemy": false, "survive": false}
var weekly_milestone_claimed: Dictionary = {}
const WEEKLY_MISSIONS: Array[Dictionary] = [
	{"id":"food_150", "kind":"food", "title":"🍀 جمع‌کننده غذا", "desc":"جمع‌آوری ۱۵۰ غذا", "target":150, "reward":80},
	{"id":"food_300", "kind":"food", "title":"🌿 شکارچی گرسنه", "desc":"جمع‌آوری ۳۰۰ غذا", "target":300, "reward":140},
	{"id":"food_600", "kind":"food", "title":"🌊 سلطان تغذیه", "desc":"جمع‌آوری ۶۰۰ غذا", "target":600, "reward":240},
	{"id":"enemy_30", "kind":"enemy", "title":"⚔ شکارچیان اعماق", "desc":"شکست ۳۰ دشمن", "target":30, "reward":100},
	{"id":"enemy_75", "kind":"enemy", "title":"🦈 شکارچی حرفه‌ای", "desc":"شکست ۷۵ دشمن", "target":75, "reward":180},
	{"id":"enemy_150", "kind":"enemy", "title":"👑 فرمانروای اعماق", "desc":"شکست ۱۵۰ دشمن", "target":150, "reward":320},
	{"id":"survive_600", "kind":"survive", "title":"⏱ بازمانده", "desc":"مجموعاً ۱۰ دقیقه زنده بمان", "target":600, "reward":120},
	{"id":"survive_1200", "kind":"survive", "title":"🛡 بازمانده سرسخت", "desc":"مجموعاً ۲۰ دقیقه زنده بمان", "target":1200, "reward":220},
	{"id":"survive_2400", "kind":"survive", "title":"🌌 موجود جاودانه", "desc":"مجموعاً ۴۰ دقیقه زنده بمان", "target":2400, "reward":450}
]
const WEEKLY_GOALS: Dictionary = {"food": {"target": 150, "reward": 80}, "enemy": {"target": 30, "reward": 100}, "survive": {"target": 600, "reward": 120}}

const DAILY_REWARDS: Array[int] = [25, 35, 45, 60, 80, 100, 140, 160, 190, 220, 260, 300, 350, 450]

const UPGRADE_KEYS: Array = ["upgrade_speed", "upgrade_attract", "upgrade_defense", "upgrade_spike", "upgrade_glow", "upgrade_regen", "upgrade_poison", "upgrade_dna_boost"]

func _ready():
	load_game()

func save_game():
	var data: Dictionary = {
		"high_score": high_score,
		"max_level": max_level,
		"total_dna": total_dna,
		"sound_enabled": sound_enabled,
		"music_enabled": music_enabled,
		"evolution_skin": evolution_skin,
		"owned_evolution_skins": owned_evolution_skins,
		"player_name": player_name,
		"account_phone_hash": account_phone_hash,
		"account_verified": account_verified,
		"last_daily_claim": last_daily_claim,
		"daily_streak": daily_streak,
		"weekly_progress": weekly_progress,
		"weekly_reset_key": weekly_reset_key,
		"weekly_claimed": weekly_claimed,
		"weekly_milestone_claimed": weekly_milestone_claimed,
	}
	for k in UPGRADE_KEYS:
		data[k] = get(k)
	var file = FileAccess.open(save_path, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		file.close()

func load_game():
	if not FileAccess.file_exists(save_path):
		return
	var file = FileAccess.open(save_path, FileAccess.READ)
	if file:
		var json_str = file.get_as_text()
		file.close()
		var json = JSON.new()
		if json.parse(json_str) == OK and typeof(json.data) == TYPE_DICTIONARY:
			var data = json.data
			high_score = data.get("high_score", 0)
			max_level = data.get("max_level", 1)
			total_dna = data.get("total_dna", 0)
			sound_enabled = data.get("sound_enabled", true)
			music_enabled = data.get("music_enabled", true)
			evolution_skin = int(data.get("evolution_skin", 0))
			owned_evolution_skins = data.get("owned_evolution_skins", [0])
			player_name = str(data.get("player_name", ""))
			account_phone_hash = str(data.get("account_phone_hash", ""))
			account_verified = bool(data.get("account_verified", false))
			if not owned_evolution_skins.has(0): owned_evolution_skins.append(0)
			last_daily_claim = str(data.get("last_daily_claim", ""))
			daily_streak = int(data.get("daily_streak", 0))
			weekly_progress = data.get("weekly_progress", {"food": 0, "enemy": 0, "survive": 0})
			weekly_reset_key = str(data.get("weekly_reset_key", ""))
			weekly_claimed = data.get("weekly_claimed", {"food": false, "enemy": false, "survive": false})
			weekly_milestone_claimed = data.get("weekly_milestone_claimed", {})
			for k in UPGRADE_KEYS:
				set(k, data.get(k, 0))

func _today_key() -> String:
	var d = Time.get_date_dict_from_system()
	return "%04d-%02d-%02d" % [d.year, d.month, d.day]

func _yesterday_key() -> String:
	var now = Time.get_unix_time_from_system() - 86400.0
	var d = Time.get_datetime_dict_from_unix_time(int(now))
	return "%04d-%02d-%02d" % [d.year, d.month, d.day]

func can_claim_daily() -> bool:
	return last_daily_claim != _today_key()

func daily_day_index() -> int:
	return clampi(daily_streak, 0, DAILY_REWARDS.size() - 1)

func daily_reward_for_day(day_index: int) -> int:
	return DAILY_REWARDS[clampi(day_index, 0, DAILY_REWARDS.size() - 1)]

func claim_daily_reward() -> int:
	var today = _today_key()
	if last_daily_claim == today:
		return 0
	if last_daily_claim != "" and last_daily_claim != _yesterday_key():
		daily_streak = 0
	var reward = daily_reward_for_day(daily_streak)
	daily_streak = (daily_streak + 1) % DAILY_REWARDS.size()
	last_daily_claim = today
	total_dna += reward
	save_game()
	return reward

func _week_key() -> String:
	var d = Time.get_date_dict_from_system()
	var unix = Time.get_unix_time_from_datetime_dict(d)
	var week = int(floor(float(unix) / 604800.0))
	return str(week)

func ensure_weekly_reset() -> void:
	var key = _week_key()
	if weekly_reset_key != key:
		weekly_reset_key = key
		weekly_progress = {"food": 0, "enemy": 0, "survive": 0}
		weekly_claimed = {"food": false, "enemy": false, "survive": false}
		weekly_milestone_claimed = {}
		save_game()

func add_weekly_progress(kind: String, amount: int = 1) -> void:
	ensure_weekly_reset()
	if not weekly_progress.has(kind):
		weekly_progress[kind] = 0
	weekly_progress[kind] = int(weekly_progress.get(kind, 0)) + amount
	for mission in WEEKLY_MISSIONS:
		if str(mission["kind"]) != kind:
			continue
		var mission_id := str(mission["id"])
		if bool(weekly_milestone_claimed.get(mission_id, false)):
			continue
		if int(weekly_progress[kind]) >= int(mission["target"]):
			weekly_milestone_claimed[mission_id] = true
			total_dna += int(mission["reward"])
	save_game()

func update_score(score: int, level: int):
	if score > high_score:
		high_score = score
	if level > max_level:
		max_level = level
	save_game()

func add_dna(amount: int):
	total_dna += amount
	save_game()

func can_afford(amount: int) -> bool:
	return total_dna >= amount

func spend_dna(amount: int) -> bool:
	# Spend DNA for upgrades; returns false if not enough DNA
	amount = absi(amount)
	if total_dna < amount:
		return false
	total_dna -= amount
	save_game()
	return true

func reset_upgrades():
	for k in UPGRADE_KEYS:
		set(k, 0)


func _account_key(phone: String) -> String:
	var normalized: String = phone.strip_edges().replace(" ", "").replace("-", "")
	return str(normalized.hash())

func _read_accounts() -> Dictionary:
	if not FileAccess.file_exists(ACCOUNT_PATH): return {}
	var f: FileAccess = FileAccess.open(ACCOUNT_PATH, FileAccess.READ)
	if f == null: return {}
	var raw: String = f.get_as_text(); f.close()
	var j: JSON = JSON.new()
	if j.parse(raw) != OK or typeof(j.data) != TYPE_DICTIONARY: return {}
	return j.data

func _write_accounts(accounts: Dictionary) -> void:
	var f: FileAccess = FileAccess.open(ACCOUNT_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(accounts))
		f.close()

func create_account_code(phone: String) -> String:
	var normalized: String = phone.strip_edges().replace(" ", "").replace("-", "")
	if normalized.length() < 7: return ""
	var code: String = "%06d" % randi_range(100000, 999999)
	var key: String = _account_key(normalized)
	var accounts: Dictionary = _read_accounts()
	var snapshot: Dictionary = {}
	# این نسخه «پیام داخل بازی» دارد؛ ارسال SMS واقعی به یک سرویس/سرور بیرونی نیاز دارد.
	var save_file: Dictionary = {
		"high_score": high_score, "max_level": max_level, "total_dna": total_dna,
		"sound_enabled": sound_enabled, "music_enabled": music_enabled,
		"evolution_skin": evolution_skin, "owned_evolution_skins": owned_evolution_skins,
		"player_name": player_name, "last_daily_claim": last_daily_claim, "daily_streak": daily_streak,
		"weekly_progress": weekly_progress, "weekly_reset_key": weekly_reset_key, "weekly_claimed": weekly_claimed
	}
	for k in UPGRADE_KEYS: save_file[k] = get(k)
	snapshot = FeatureManager.get_snapshot()
	accounts[key] = {"phone": normalized, "code": code, "save": save_file, "features": snapshot}
	_write_accounts(accounts)
	account_phone_hash = key
	account_verified = false
	save_game()
	return code

func verify_account_code(phone: String, code: String) -> bool:
	var key: String = _account_key(phone)
	var accounts: Dictionary = _read_accounts()
	if not accounts.has(key): return false
	var acc: Dictionary = accounts[key]
	if str(acc.get("code", "")) != code.strip_edges(): return false
	var data: Dictionary = acc.get("save", {})
	high_score = int(data.get("high_score", high_score))
	max_level = int(data.get("max_level", max_level))
	total_dna = int(data.get("total_dna", total_dna))
	sound_enabled = bool(data.get("sound_enabled", sound_enabled))
	music_enabled = bool(data.get("music_enabled", music_enabled))
	evolution_skin = int(data.get("evolution_skin", evolution_skin))
	owned_evolution_skins = data.get("owned_evolution_skins", owned_evolution_skins)
	player_name = str(data.get("player_name", player_name))
	last_daily_claim = str(data.get("last_daily_claim", last_daily_claim))
	daily_streak = int(data.get("daily_streak", daily_streak))
	weekly_progress = data.get("weekly_progress", weekly_progress)
	weekly_reset_key = str(data.get("weekly_reset_key", weekly_reset_key))
	weekly_claimed = data.get("weekly_claimed", weekly_claimed)
	for k in UPGRADE_KEYS: set(k, int(data.get(k, 0)))
	account_phone_hash = key
	account_verified = true
	FeatureManager.apply_snapshot(acc.get("features", {}))
	save_game()
	return true
