extends Node

var audio_players: Array[AudioStreamPlayer] = []
var max_players: int = 8

# کمبو: نیم‌پرده بالارونده (دو، ر، می، فا، سل، لا، سی، دو)
const COMBO_SCALE: Array[float] = [261.63, 293.66, 329.63, 349.23, 392.0, 440.0, 493.88, 523.25]

func _ready():
	for i in range(max_players):
		var p = AudioStreamPlayer.new()
		add_child(p)
		audio_players.append(p)

func play_synth_tone(freq: float, duration: float, type: String = "sine", gain: float = 0.5):
	if not SaveManager.sound_enabled:
		return
	var sample_hz: int = 22050
	var total_samples = int(sample_hz * duration)
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_8_BITS
	stream.mix_rate = sample_hz
	stream.stereo = false
	
	var data = PackedByteArray()
	data.resize(total_samples)
	for i in range(total_samples):
		var t = float(i) / sample_hz
		var envelope = 1.0 - (float(i) / total_samples) # Linear fade-out
		var sample_val: float = 0.0
		if type == "sine":
			sample_val = sin(2.0 * PI * freq * t)
		elif type == "square":
			sample_val = 1.0 if sin(2.0 * PI * freq * t) >= 0.0 else -1.0
		elif type == "noise":
			sample_val = randf_range(-1.0, 1.0)
		elif type == "chirp":
			var cur_f = freq + (freq * 1.5 * (1.0 - envelope))
			sample_val = sin(2.0 * PI * cur_f * t)
		
		var byte_val = int(clamp((sample_val * envelope * gain + 1.0) * 127.5, 0, 255))
		data[i] = byte_val
		
	stream.data = data
	
	# Find available player
	for p in audio_players:
		if not p.playing:
			p.stream = stream
			p.play()
			break

func play_eat_food(combo: int = 0):
	# ارتقای فرکانس با هر کمبو — نُت بالارونده گام ماژور، معتادکننده برای مغز
	var note_index: int = clampi(combo - 1, 0, COMBO_SCALE.size() - 1)
	var freq: float = COMBO_SCALE[note_index] * 2.0  # یک اکتاو بالاتر برای شفافیت
	play_synth_tone(freq, 0.08, "sine", 0.3)

func play_eat_dna():
	play_synth_tone(880.0, 0.15, "chirp", 0.4)

func play_evolve():
	play_synth_tone(523.25, 0.4, "chirp", 0.6)

func play_hit():
	play_synth_tone(120.0, 0.25, "noise", 0.5)

func play_enemy_eat():
	play_synth_tone(220.0, 0.2, "square", 0.4)

func play_boost():
	play_synth_tone(350.0, 0.1, "chirp", 0.2)

func play_powerup():
	# آرپژ سه‌نتی بالا رونده برای برداشتن آیتم اقیانوسی
	play_synth_tone(523.25, 0.09, "sine", 0.35)
	play_synth_tone(659.25, 0.09, "sine", 0.35)
	play_synth_tone(783.99, 0.14, "sine", 0.4)

func play_shield_break():
	# شکست کریستالی: نویز کوتاه با فرکانس بالا + چیرپ نزولی
	play_synth_tone(1400.0, 0.12, "noise", 0.45)
	play_synth_tone(900.0, 0.18, "chirp", 0.35)
