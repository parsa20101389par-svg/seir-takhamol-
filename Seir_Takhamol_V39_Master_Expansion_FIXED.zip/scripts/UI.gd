extends CanvasLayer

class JoystickControl extends Control:
	signal direction_changed(direction: Vector2)
	var knob: Vector2 = Vector2.ZERO
	var dragging: bool = false
	var radius: float = 82.0
	var knob_radius: float = 34.0
	func _ready() -> void:
		custom_minimum_size = Vector2(190, 190)
		mouse_filter = Control.MOUSE_FILTER_STOP
		queue_redraw()
	var touch_index: int = -1

	func _gui_input(event: InputEvent) -> void:
		# Keep GUI handling as a fallback; the global _input below is the primary
		# touch path because other full-screen Controls can otherwise steal touches.
		_handle_touch_event(event)

	func _input(event: InputEvent) -> void:
		# Robust mobile joystick: receive the touch before other HUD controls.
		if event is InputEventScreenTouch:
			if event.pressed:
				if get_global_rect().has_point(event.position):
					if touch_index == -1:
						accept_event()
						touch_index = event.index
						dragging = true
						_update_knob_from_global(event.position)
			else:
				if dragging and event.index == touch_index:
					accept_event()
					_release_joystick()
		elif event is InputEventScreenDrag:
			if dragging and event.index == touch_index:
				accept_event()
				_update_knob_from_global(event.position)

	func _handle_touch_event(event: InputEvent) -> void:
		if event is InputEventScreenTouch:
			if event.pressed:
				dragging = true
				_update_knob(event.position)
			else:
				_release_joystick()
		elif event is InputEventScreenDrag and dragging:
			_update_knob(event.position)

	func _update_knob_from_global(global_pos: Vector2) -> void:
		_update_knob(global_pos - global_position)

	func _release_joystick() -> void:
		dragging = false
		touch_index = -1
		knob = Vector2.ZERO
		direction_changed.emit(Vector2.ZERO)
		queue_redraw()
	func _update_knob(pos: Vector2) -> void:
		var center = size * 0.5
		var offset = pos - center
		knob = offset.limit_length(radius - knob_radius)
		var direction = Vector2.ZERO
		if offset.length() > 12.0:
			direction = offset.normalized()
		direction_changed.emit(direction)
		queue_redraw()
	func _draw() -> void:
		var center = size * 0.5
		draw_circle(center, radius, Color(0.02, 0.12, 0.18, 0.68))
		draw_arc(center, radius, 0.0, TAU, 48, Color(0.35, 0.95, 0.9, 0.9), 4.0, true)
		draw_circle(center + knob, knob_radius, Color(0.3, 0.9, 0.85, 0.92))
		draw_arc(center + knob, knob_radius, 0.0, TAU, 32, Color(0.8, 1.0, 1.0, 0.95), 3.0, true)

# سیر تکامل - HUD و رابط کاربری داخل بازی

@onready var score_label: Label = $Root/TopLeftPanel/VBox/ScoreLabel
@onready var high_score_label: Label = $Root/TopLeftPanel/VBox/HighScoreLabel
@onready var dna_label: Label = $Root/TopLeftPanel/VBox/DNALabel
@onready var mass_label: Label = $Root/TopLeftPanel/VBox/MassLabel
@onready var health_label: Label = $Root/TopLeftPanel/VBox/HealthLabel
@onready var health_bar: ProgressBar = $Root/TopLeftPanel/VBox/HealthBar
@onready var level_bar: ProgressBar = $Root/TopLeftPanel/VBox/LevelBar
@onready var level_label: Label = $Root/TopLeftPanel/VBox/LevelLabel
@onready var stamina_bar: ProgressBar = $Root/TopLeftPanel/VBox/StaminaBar
@onready var pause_btn: Button = $Root/TopRightBox/PauseButton
@onready var boost_btn: Button = $Root/BoostButton
@onready var evolve_banner: Label = $Root/EvolveBanner
@onready var pause_menu: Control = $Root/PauseMenu
@onready var game_over: Control = $Root/GameOver
@onready var evolution_choice: Control = $Root/EvolutionChoice
@onready var evolution_buttons: VBoxContainer = $Root/EvolutionChoice/Center/VBox/Buttons
@onready var evolution_title: Label = $Root/EvolutionChoice/Center/VBox/Title

# Upgrade definitions: key -> [icon, Persian name, short description]
const EVOLUTION_UPGRADES: Dictionary = {
	"spike_front": ["🦔", "شاخک جلو", "هر سطح: +۱۲٪ قدرت حمله و ضربه جلویی"],
	"spike_rear": ["🗡", "شاخک عقب", "هر سطح: ضدحمله قوی‌تر هنگام تماس از پشت"],
	"attack": ["⚔", "ارتقا حمله", "هر سطح: +۲۰٪ آسیب به دشمنان"],
	"health": ["❤", "ارتقا سلامت", "هر انتخاب: جرم و دوام بیشتر + ترمیم فوری"],
	"speed": ["💨", "ارتقا سرعت", "هر سطح: +۱۰٪ سرعت حرکت و بوست"],
	"magnet": ["🧲", "آهنربای جذب غذا", "هر سطح: شعاع جذب بسیار بیشتر"],
	"regen": ["🌿", "ترمیم خودکار", "هر سطح: بازسازی جرم سریع‌تر"],
	"dna": ["🧬", "ضریب DNA", "هر سطح: +۱۲٪ DNA؛ عمداً آهسته و کنترل‌شده"],
	"shockwave": ["💥", "موج شوک", "سطح بالاتر: موج قوی‌تر و آماده‌سازی سریع‌تر"],
	"shield": ["🛡", "سپر حبابی", "سطح بالاتر: دفاع و دفعات استفاده بهتر"],
	"poison_skin": ["☠", "پوست سمی", "دشمنانی که با شما تماس پیدا کنند مسموم و زخمی می‌شوند"],
	"vampirism": ["🧛", "خون‌آشامی", "با هر بار آسیب یا خوردن دشمن، بخشی از سلامت شما ترمیم می‌شود"],
	"time_warp": ["⏳", "اعوجاج زمان", "میدان کندکننده زمان در اطراف شما حرکت دشمنان را کند می‌کند"],
	"armor": ["🛡️", "زره سلولی", "آسیب دریافتی کمتر می‌شود و مقاومتت بالا می‌رود"],
	"metabolism": ["🔥", "سوخت‌وساز", "رشد از غذا کمی بیشتر می‌شود"],
	"thorns": ["🌵", "خارهای سمی", "تماس با دشمن آسیب بیشتری به او می‌زند"],
	"dash": ["⚡", "شتاب تکاملی", "سرعت پایه و سرعت بوست بیشتر می‌شود"],
	"vitality": ["💚", "حیات بیشتر", "سلامت و ترمیم بدن افزایش پیدا می‌کند"],
	"predator": ["🦷", "شکارچی", "آسیب حمله و پاداش شکار افزایش می‌یابد"],
	"gravity": ["🌀", "جذب زیستی", "غذاها از فاصله بیشتری به سمت تو می‌آیند"],
	"adaptation": ["🧬", "سازگاری", "هر سطح: تقویت کوچک و متعادل چند ویژگی"],
	"critical": ["🎯", "هسته بحرانی", "شانس ضربه قدرتمند در شکار دشمنان بیشتر می‌شود"],
	"growth": ["🫧", "رشد سلولی", "از هر غذای معمولی جرم بیشتری دریافت می‌کنی"],
	"stamina": ["⚡", "باتری زیستی", "ظرفیت بوست و بازسازی انرژی بیشتر می‌شود"],
	"combo_master": ["🔥", "استاد کمبو", "پنجره کمبو طولانی‌تر و پاداش کمبو بهتر می‌شود"],
	"hunter_resist": ["🧿", "مقاومت شکارچی", "آسیب شکارچیان و دشمنان نخبه کمتر می‌شود"],
	"hunter_damage": ["🦈", "غریزه شکار", "آسیب تو به شکارچیان بیشتر می‌شود"],
	"luck": ["🍀", "شانس زیستی", "احتمال ظاهرشدن پاورآپ و غنیمت بهتر می‌شود"],
	"pulse": ["🔵", "پالس زیستی", "توان موج شوک و مهارت‌های فعال قوی‌تر می‌شود"],
	"giant_core": ["🧿", "هسته غول‌آسا", "بدن بزرگ‌تر و سقف رشد هر سطح بالاتر می‌رود"],
	"adaptation_plus": ["🌌", "سازگاری عمیق", "چند ویژگی به‌صورت همزمان کمی تقویت می‌شوند"],
}

const EVOLUTION_MAX_LEVEL: int = 15

var player: Node = null
var dna_this_run: int = 0
var dna_at_start: int = 0
var banner_tween: Tween = null
var powerup_badges_container: HBoxContainer
var shield_badge: Label
var magnet_badge: Label
var speed_badge: Label
var dna_badge: Label
var target_level_progress: float = 0.0
var shield_button: Button = null
var shockwave_button: Button = null
var popup_tweens: Dictionary = {}
var pause_region_theme: String = "دشت آرام"
var popup_text_tweens: Array[Tween] = []
var species_codex: Control = null
var species_codex_panel: PanelContainer = null
var species_codex_list: VBoxContainer = null
var species_codex_close_btn: Button = null
var species_codex_open: bool = false
var event_banner: Label
var event_banner_timer: float = 0.0
var region_banner: PanelContainer = null
var region_banner_label: Label = null
var region_banner_subtitle: Label = null
var region_banner_timer: float = 0.0
var boss_panel: PanelContainer
var boss_label: Label
var boss_bar: ProgressBar
var boss_node: Node = null
var boss_entries: Dictionary = {}
var boss_list_box: VBoxContainer = null
var quest_panel: PanelContainer
var quest_label: Label
var quest_progress_bar: ProgressBar
var quest_toast: Label
var quest_timer: float = 0.0
var quest_index: int = 0
var quest_progress: int = 0
var quest_target: int = 5
var quest_reward: int = 35
var adrenaline_overlay: ColorRect
var adrenaline_strength: float = 0.0
var quest_speed_buff: float = 0.0
var joystick: JoystickControl = null
var touch_move_index: int = -1
var touch_move_active: bool = false
const QUESTS: Array[Dictionary] = [
	{"type":"food", "title":"جمع‌آوری غذا", "target":15, "reward":18},
	{"type":"enemy", "title":"شکست دشمنان", "target":5, "reward":24},
	{"type":"combo", "title":"رسیدن به کمبوی ۱۰", "target":10, "reward":20},
	{"type":"survive", "title":"زنده‌ماندن ۴۵ ثانیه", "target":45, "reward":28}
]

func _ready():
	# HUD must keep processing while the game world is paused, especially the evolution choices.
	process_mode = Node.PROCESS_MODE_ALWAYS
	evolution_choice.process_mode = Node.PROCESS_MODE_ALWAYS
	evolution_choice.mouse_filter = Control.MOUSE_FILTER_STOP
	$Root/EvolutionChoice/Dim.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/EvolutionChoice/Center.process_mode = Node.PROCESS_MODE_ALWAYS
	dna_at_start = SaveManager.total_dna
	# توقف بازی با لمس مستقیم و مطمئن موبایل کنترل می‌شود؛ مسیر gui_input قبلی
	# روی بعضی دستگاه‌ها با لایه‌های HUD تداخل داشت.
	pause_btn.process_mode = Node.PROCESS_MODE_ALWAYS
	pause_btn.mouse_filter = Control.MOUSE_FILTER_STOP
	# Android touch must reach the Button GUI path instead of falling through to
	# the world movement handler.
	Input.emulate_mouse_from_touch = false
	if not pause_btn.gui_input.is_connected(_on_pause_gui_input):
		pause_btn.gui_input.connect(_on_pause_gui_input)
	if not pause_btn.pressed.is_connected(_on_pause_button_pressed):
		pause_btn.pressed.connect(_on_pause_button_pressed)
	_apply_pause_button_theme("دشت آرام")
	boost_btn.pressed.connect(func(): pass)  # handled via _gui_input for hold
	boost_btn.button_down.connect(_on_boost_down)
	boost_btn.button_up.connect(_on_boost_up)
	# Pause menu must remain interactive while SceneTree is paused (Android touch included).
	pause_menu.process_mode = Node.PROCESS_MODE_ALWAYS
	# Game Over must stay interactive while the SceneTree is paused.
	game_over.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/GameOver/Dim.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/GameOver/Dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	$Root/GameOver/Panel.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/GameOver/Panel.mouse_filter = Control.MOUSE_FILTER_STOP
	$Root/GameOver/Panel/VBox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	$Root/PauseMenu/Dim.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/PauseMenu/OceanOverlay.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/PauseMenu/Panel.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/PauseMenu/Panel/VBox.process_mode = Node.PROCESS_MODE_ALWAYS
	$Root/PauseMenu/Panel/VBox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for pause_child in $Root/PauseMenu/Panel/VBox.get_children():
		if pause_child is Control:
			pause_child.process_mode = Node.PROCESS_MODE_ALWAYS
			pause_child.mouse_filter = Control.MOUSE_FILTER_STOP if pause_child is Button else Control.MOUSE_FILTER_IGNORE
	$Root/PauseMenu/Panel/VBox/ResumeBtn.pressed.connect(_toggle_pause)
	$Root/PauseMenu/Panel/VBox/RestartBtn.pressed.connect(_restart)
	$Root/PauseMenu/Panel/VBox/MenuBtn.pressed.connect(_go_menu)
	$Root/PauseMenu/Panel/VBox/QuitBtn.pressed.connect(_quit_game)
	$Root/PauseMenu/Panel/VBox/SoundToggle.button_pressed = SaveManager.sound_enabled
	$Root/PauseMenu/Panel/VBox/SoundToggle.toggled.connect(_on_sound_toggled)
	$Root/GameOver/Panel/VBox/RestartBtn.pressed.connect(_restart)
	$Root/GameOver/Panel/VBox/MenuBtn.pressed.connect(_go_menu)
	high_score_label.text = "🏆 رکورد: %d" % SaveManager.high_score
	dna_label.text = "🧬 DNA: %d" % SaveManager.total_dna
	_style_bar(health_bar, Color(0.85, 0.15, 0.2), Color(1.0, 0.25, 0.3))
	_style_bar(level_bar, Color(0.15, 0.35, 0.2), Color(0.3, 0.9, 0.45))
	_style_bar(stamina_bar, Color(0.2, 0.2, 0.1), Color(0.95, 0.85, 0.25))
	_style_stats_hud()
	_create_skill_buttons()
	_start_pause_pulse()
	_create_dynamic_hud()
	# جوی‌استیک واقعی + حرکت لمسی پشتیبان برای موبایل.
	_create_virtual_joystick()
	_enable_touch_movement()
	_set_quest(0)

func _create_virtual_joystick() -> void:
	joystick = JoystickControl.new()
	joystick.name = "VirtualJoystick"
	joystick.anchor_left = 0.0
	joystick.anchor_top = 1.0
	joystick.anchor_right = 0.0
	joystick.anchor_bottom = 1.0
	joystick.offset_left = 24.0
	joystick.offset_top = -224.0
	joystick.offset_right = 224.0
	joystick.offset_bottom = -24.0
	joystick.z_index = 100
	joystick.z_as_relative = false
	joystick.direction_changed.connect(_on_joystick_direction)
	$Root.add_child(joystick)

func _on_joystick_direction(direction: Vector2) -> void:
	if is_instance_valid(player):
		player.move_dir = direction
		player.use_pointer = false

# حرکت لمسی مستقیم: هر جا در محیط بازی لمس/درگ شود، سلول به همان سمت حرکت می‌کند.
# این مسیر در _unhandled_input است تا Buttonهای HUD قبل از حرکت لمس را مصرف کنند.
func _enable_touch_movement() -> void:
	# Mobile-safe fallback: handle both real touch and the mouse events that
	# Android can emit from touch. UI buttons are checked first and consumed.
	set_process_input(true)

func _input(event: InputEvent) -> void:
	# IMPORTANT: this function runs before GUI input. Therefore explicitly
	# consume the pause button here so its touch can never become movement.
	if not game_over.visible and not evolution_choice.visible and not pause_menu.visible:
		if event is InputEventScreenTouch and event.pressed:
			if is_instance_valid(pause_btn) and _point_in_control(pause_btn, event.position):
				_toggle_pause()
				get_viewport().set_input_as_handled()
				return
		if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			if is_instance_valid(pause_btn) and _point_in_control(pause_btn, event.position):
				_toggle_pause()
				get_viewport().set_input_as_handled()
				return

	# Species codex popup: touch fallback for the close button.
	if species_codex_open:
		_handle_species_codex_touch(event)
		return

	# Popup controls need to work while SceneTree is paused.
	if game_over.visible:
		_handle_game_over_touch(event)
		return
	if evolution_choice.visible:
		_handle_evolution_touch(event)
		return
	if pause_menu.visible:
		_handle_pause_menu_touch(event)
		return

	if get_tree().paused or not is_instance_valid(player):
		return

	# Direct touch movement fallback. The pause button and BOOST button are
	# excluded so touching HUD never moves the player.
	if event is InputEventScreenTouch:
		if event.pressed:
			if touch_move_index != -1 or _touch_is_ui_control(event.position):
				return
			touch_move_index = event.index
			touch_move_active = true
			_set_touch_direction(event.position)
			get_viewport().set_input_as_handled()
		else:
			if event.index == touch_move_index:
				touch_move_index = -1
				touch_move_active = false
				player.move_dir = Vector2.ZERO
				player.use_pointer = false
				get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and event.index == touch_move_index and touch_move_active:
		_set_touch_direction(event.position)
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		# Mouse fallback is useful on desktop and on Android when touch is
		# configured to emulate mouse events.
		if event.pressed:
			if _touch_is_ui_control(event.position):
				return
			touch_move_index = -2
			touch_move_active = true
			_set_touch_direction(event.position)
			get_viewport().set_input_as_handled()
		else:
			if touch_move_index == -2:
				touch_move_index = -1
				touch_move_active = false
				player.move_dir = Vector2.ZERO
				player.use_pointer = false
				get_viewport().set_input_as_handled()

	elif event is InputEventMouseMotion and touch_move_index == -2 and touch_move_active:
		_set_touch_direction(event.position)
		get_viewport().set_input_as_handled()


func _handle_evolution_touch(event: InputEvent) -> void:
	var pos := Vector2.ZERO
	var pressed := false
	if event is InputEventScreenTouch:
		pos = event.position
		pressed = event.pressed
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pos = event.position
		pressed = event.pressed
	else:
		return

	if not pressed:
		return

	# Check the actual global rectangles of the dynamically-created buttons.
	for child in evolution_buttons.get_children():
		if child is Button and child.visible and not child.disabled:
			var btn: Button = child
			if btn.get_global_rect().has_point(pos):
				var key_variant = btn.get_meta("evolution_key", "")
				if key_variant is String and not key_variant.is_empty():
					_on_evolution_upgrade_pressed(key_variant)
					get_viewport().set_input_as_handled()
					return


func _point_in_control(control: Control, viewport_pos: Vector2) -> bool:
	# On a CanvasLayer HUD, InputEvent positions are viewport coordinates and
	# get_global_rect() is the reliable hit area on Android with stretch/rotation.
	# Keep the local-transform check as a fallback for nested/transformed controls.
	if not is_instance_valid(control) or not control.visible:
		return false
	if control.get_global_rect().has_point(viewport_pos):
		return true
	var local_pos: Vector2 = control.get_global_transform_with_canvas().affine_inverse() * viewport_pos
	return Rect2(Vector2.ZERO, control.size).has_point(local_pos)

func _handle_pause_menu_touch(event: InputEvent) -> void:
	var pos := Vector2.ZERO
	var pressed := false
	if event is InputEventScreenTouch:
		pos = event.position
		pressed = event.pressed
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pos = event.position
		pressed = event.pressed
	else:
		return

	if not pressed or not pause_menu.visible:
		return

	var vbox := $Root/PauseMenu/Panel/VBox
	for child in vbox.get_children():
		if child is Button and child.visible and not child.disabled:
			var btn: Button = child
			if _point_in_control(btn, pos):
				# اول event را مصرف کن؛ چون بعضی عملیات مثل Restart/Menu
				# بلافاصله صحنه فعلی را آزاد می‌کنند و بعد از آن get_viewport()
				# می‌تواند null شود.
				var viewport := get_viewport()
				if is_instance_valid(viewport):
					viewport.set_input_as_handled()
				match btn.name:
					"ResumeBtn": _toggle_pause()
					"RestartBtn": call_deferred("_restart")
					"MenuBtn": call_deferred("_go_menu")
					"QuitBtn": call_deferred("_quit_game")
					"SoundToggle":
						btn.button_pressed = not btn.button_pressed
						_on_sound_toggled(btn.button_pressed)
				return

func _handle_game_over_touch(event: InputEvent) -> void:
	var pos := Vector2.ZERO
	var pressed := false
	if event is InputEventScreenTouch:
		pos = event.position
		pressed = event.pressed
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pos = event.position
		pressed = event.pressed
	else:
		return

	if not pressed or not game_over.visible:
		return

	var vbox := $Root/GameOver/Panel/VBox
	for child in vbox.get_children():
		if child is Button and child.visible and not child.disabled:
			var btn: Button = child
			if _point_in_control(btn, pos):
				# همان قاعده در Game Over: event را قبل از تعویض صحنه مصرف کن.
				var viewport := get_viewport()
				if is_instance_valid(viewport):
					viewport.set_input_as_handled()
				match btn.name:
					"RestartBtn": call_deferred("_restart")
					"MenuBtn": call_deferred("_go_menu")
				return


func _quit_game() -> void:
	get_tree().paused = false
	get_tree().quit()

func _set_touch_direction(screen_pos: Vector2) -> void:
	var center: Vector2 = get_viewport().get_visible_rect().size * 0.5
	var direction: Vector2 = screen_pos - center
	if direction.length() < 18.0:
		player.move_dir = Vector2.ZERO
	else:
		player.move_dir = direction.normalized()
	player.use_pointer = false

func _touch_is_ui_control(pos: Vector2) -> bool:
	# دکمه‌های واقعی باید همچنان قابل لمس باشند و حرکت ناخواسته ایجاد نکنند.
	if is_instance_valid(pause_btn) and _point_in_control(pause_btn, pos):
		return true
	if is_instance_valid(boost_btn) and _point_in_control(boost_btn, pos):
		return true
	return false

func _create_dynamic_hud() -> void:
	event_banner = Label.new()
	event_banner.name = "DynamicEventBanner"
	event_banner.anchor_left = 0.15
	event_banner.anchor_right = 0.85
	event_banner.anchor_top = 0.08
	event_banner.anchor_bottom = 0.08
	event_banner.offset_top = 0.0
	event_banner.offset_bottom = 58.0
	event_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	event_banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	event_banner.add_theme_font_size_override("font_size", 34)
	event_banner.add_theme_color_override("font_color", Color(0.5, 1.0, 0.9))
	event_banner.add_theme_color_override("font_outline_color", Color(0.01, 0.08, 0.14, 0.95))
	event_banner.add_theme_constant_override("outline_size", 6)
	event_banner.visible = false
	event_banner.z_index = 180
	$Root.add_child(event_banner)

	# اعلان اختصاصی تغییر منطقه؛ همیشه بالای بازی و خوانا نمایش داده می‌شود.
	region_banner = PanelContainer.new()
	region_banner.name = "RegionChangeBanner"
	region_banner.anchor_left = 0.12
	region_banner.anchor_right = 0.88
	region_banner.anchor_top = 0.045
	region_banner.anchor_bottom = 0.045
	region_banner.offset_top = 64.0
	region_banner.offset_bottom = 156.0
	region_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	region_banner.z_index = 220
	var region_style = StyleBoxFlat.new()
	region_style.bg_color = Color(0.015, 0.055, 0.09, 0.94)
	region_style.border_color = Color(0.25, 0.92, 0.9, 0.9)
	region_style.set_border_width_all(3)
	region_style.corner_radius_top_left = 22
	region_style.corner_radius_top_right = 22
	region_style.corner_radius_bottom_left = 22
	region_style.corner_radius_bottom_right = 22
	region_style.shadow_color = Color(0.0, 0.9, 0.85, 0.28)
	region_style.shadow_size = 16
	region_banner.add_theme_stylebox_override("panel", region_style)
	var region_box = VBoxContainer.new()
	region_box.alignment = BoxContainer.ALIGNMENT_CENTER
	region_box.add_theme_constant_override("separation", 0)
	region_banner_label = Label.new()
	region_banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	region_banner_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	region_banner_label.add_theme_font_size_override("font_size", 40)
	region_banner_label.add_theme_color_override("font_color", Color(0.55, 1.0, 0.95))
	region_banner_label.add_theme_color_override("font_outline_color", Color(0.0, 0.04, 0.08, 1.0))
	region_banner_label.add_theme_constant_override("outline_size", 8)
	region_box.add_child(region_banner_label)
	region_banner_subtitle = Label.new()
	region_banner_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	region_banner_subtitle.add_theme_font_size_override("font_size", 21)
	region_banner_subtitle.add_theme_color_override("font_color", Color(0.82, 0.92, 0.95))
	region_box.add_child(region_banner_subtitle)
	region_banner.add_child(region_box)
	region_banner.visible = false
	$Root.add_child(region_banner)

	boss_panel = PanelContainer.new()
	boss_panel.name = "BossHPPanel"
	boss_panel.anchor_left = 0.14
	boss_panel.anchor_right = 0.86
	boss_panel.anchor_top = 0.15
	boss_panel.anchor_bottom = 0.15
	boss_panel.offset_top = 0.0
	boss_panel.offset_bottom = 0.0
	boss_panel.visible = false
	boss_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_panel.z_index = 170
	var boss_style = StyleBoxFlat.new()
	boss_style.bg_color = Color(0.01, 0.035, 0.07, 0.90)
	boss_style.border_color = Color(1.0, 0.30, 0.24, 0.82)
	boss_style.set_border_width_all(2)
	boss_style.corner_radius_top_left = 18
	boss_style.corner_radius_top_right = 18
	boss_style.corner_radius_bottom_left = 18
	boss_style.corner_radius_bottom_right = 18
	boss_style.shadow_color = Color(1.0, 0.12, 0.08, 0.22)
	boss_style.shadow_size = 12
	boss_panel.add_theme_stylebox_override("panel", boss_style)
	boss_list_box = VBoxContainer.new()
	boss_list_box.add_theme_constant_override("separation", 5)
	boss_list_box.add_theme_constant_override("margin_left", 10)
	boss_list_box.add_theme_constant_override("margin_right", 10)
	boss_list_box.add_theme_constant_override("margin_top", 7)
	boss_list_box.add_theme_constant_override("margin_bottom", 7)
	boss_panel.add_child(boss_list_box)
	$Root.add_child(boss_panel)
	quest_panel = PanelContainer.new()
	quest_panel.name = "RunQuestPanel"
	quest_panel.anchor_left = 1.0
	quest_panel.anchor_right = 1.0
	quest_panel.anchor_top = 0.245
	quest_panel.anchor_bottom = 0.245
	quest_panel.offset_left = -455.0
	quest_panel.offset_right = -14.0
	quest_panel.offset_top = 0.0
	quest_panel.offset_bottom = 128.0
	quest_panel.add_theme_constant_override("margin_left", 18)
	quest_panel.add_theme_constant_override("margin_right", 18)
	quest_panel.add_theme_constant_override("margin_top", 13)
	quest_panel.add_theme_constant_override("margin_bottom", 13)
	quest_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	quest_panel.z_index = 140
	var quest_style = StyleBoxFlat.new()
	quest_style.bg_color = Color(0.015, 0.055, 0.11, 0.94)
	quest_style.border_color = Color(0.20, 0.92, 1.0, 0.92)
	quest_style.set_border_width_all(3)
	quest_style.corner_radius_top_left = 18
	quest_style.corner_radius_top_right = 18
	quest_style.corner_radius_bottom_left = 18
	quest_style.corner_radius_bottom_right = 18
	quest_style.shadow_color = Color(0.0, 0.82, 1.0, 0.30)
	quest_style.shadow_size = 14
	quest_panel.add_theme_stylebox_override("panel", quest_style)
	var quest_box: VBoxContainer = VBoxContainer.new()
	quest_box.add_theme_constant_override("separation", 7)
	quest_label = Label.new()
	quest_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	quest_label.text_direction = Control.TEXT_DIRECTION_RTL
	quest_label.layout_direction = Control.LAYOUT_DIRECTION_RTL
	quest_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	quest_label.clip_text = false
	quest_label.add_theme_font_size_override("font_size", 28)
	quest_label.add_theme_color_override("font_color", Color(0.60, 1.0, 0.96))
	quest_label.add_theme_color_override("font_outline_color", Color(0.0, 0.08, 0.14, 1.0))
	quest_label.add_theme_constant_override("outline_size", 5)
	quest_progress_bar = ProgressBar.new()
	quest_progress_bar.custom_minimum_size.y = 24
	quest_progress_bar.show_percentage = false
	_style_bar(quest_progress_bar, Color(0.03, 0.12, 0.18), Color(0.16, 0.95, 0.72))
	quest_box.add_child(quest_label)
	quest_box.add_child(quest_progress_bar)
	quest_panel.add_child(quest_box)
	$Root.add_child(quest_panel)
	# انیمیشن نبض آرام برای جلب توجه مأموریت بدون مزاحمت برای بازی
	var quest_pulse: Tween = create_tween().set_loops()
	quest_pulse.tween_property(quest_panel, "modulate", Color(1.0, 1.0, 1.0, 0.78), 0.75)
	quest_pulse.tween_property(quest_panel, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.75)
	quest_toast = Label.new()
	quest_toast.anchor_left = 0.18
	quest_toast.anchor_right = 0.82
	quest_toast.anchor_top = 0.34
	quest_toast.anchor_bottom = 0.34
	quest_toast.offset_bottom = 64.0
	quest_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	quest_toast.add_theme_font_size_override("font_size", 26)
	quest_toast.add_theme_color_override("font_color", Color(1.0, 0.86, 0.3))
	quest_toast.visible = false
	$Root.add_child(quest_toast)
	# Transparent full-screen draw layer: alpha is modulated by the adrenaline signal.
	adrenaline_overlay = ColorRect.new()
	adrenaline_overlay.name = "AdrenalineVignette"
	adrenaline_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	adrenaline_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	adrenaline_overlay.color = Color(0.75, 0.015, 0.035, 0.0)
	$Root.add_child(adrenaline_overlay)
	adrenaline_overlay.z_index = 90
	quest_toast.z_index = 100

func show_event(text: String, duration: float = 6.0) -> void:
	if not is_instance_valid(event_banner): return
	event_banner.text = "🌊  " + text
	event_banner.visible = true
	event_banner_timer = duration

func show_boss_warning(text: String) -> void:
	show_event("⚠ " + text, 5.0)

func show_region_change(region_name: String, immediate: bool = false) -> void:
	if not is_instance_valid(region_banner):
		return
	region_banner_label.text = "📍  " + region_name
	region_banner_subtitle.text = "تازه اولشه! منتظر بقیه باش" if immediate else "محیط جدید وارد شد"
	region_banner.visible = true
	region_banner_timer = 7.0
	region_banner.modulate.a = 1.0
	region_banner.scale = Vector2(0.94, 0.94)
	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(region_banner, "scale", Vector2.ONE, 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func bind_boss(boss: Node) -> void:
	if not is_instance_valid(boss):
		return
	boss_node = boss
	var id: int = boss.get_instance_id()
	if boss_entries.has(id):
		_update_boss_entry(boss)
		return
	var row: VBoxContainer = VBoxContainer.new()
	row.custom_minimum_size.y = 54
	row.add_theme_constant_override("separation", 2)
	var label: Label = Label.new()
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", 20)
	label.add_theme_color_override("font_color", Color(1.0, 0.72, 0.60))
	label.add_theme_color_override("font_outline_color", Color(0.10, 0.01, 0.01, 1.0))
	label.add_theme_constant_override("outline_size", 4)
	var bar: ProgressBar = ProgressBar.new()
	bar.custom_minimum_size.y = 17
	bar.show_percentage = false
	_style_bar(bar, Color(0.12, 0.025, 0.035), Color(1.0, 0.20, 0.18))
	row.add_child(label)
	row.add_child(bar)
	boss_list_box.add_child(row)
	boss_entries[id] = {"node": boss, "row": row, "label": label, "bar": bar}
	boss_panel.visible = true
	if boss.has_signal("boss_hp_changed"):
		var cb: Callable = Callable(self, "_on_boss_entry_hp_changed").bind(boss)
		boss_entries[id]["hp_cb"] = cb
		boss.boss_hp_changed.connect(cb)
		_update_boss_entry(boss)
	if boss.has_signal("boss_defeated"):
		var defeated_cb: Callable = Callable(self, "_on_boss_entry_defeated").bind(boss)
		boss_entries[id]["defeat_cb"] = defeated_cb
		boss.boss_defeated.connect(defeated_cb)

func _update_boss_entry(boss: Node) -> void:
	if not is_instance_valid(boss):
		return
	var id: int = boss.get_instance_id()
	if not boss_entries.has(id):
		return
	var entry: Dictionary = boss_entries[id]
	var maximum: float = float(boss.boss_max_hp) if "boss_max_hp" in boss else 1.0
	var current: float = float(boss.boss_hp) if "boss_hp" in boss else maximum
	var percent: int = int(round(100.0 * current / maxf(maximum, 1.0)))
	var phase: int = int(boss.boss_phase) if "boss_phase" in boss else 1
	entry["label"].text = "☠ %s   %d%%   • فاز %d/3" % [str(boss.get_meta("boss_name", "لویاتان اعماق")), percent, phase]
	entry["bar"].max_value = maximum
	entry["bar"].value = current

func _on_boss_entry_hp_changed(cur: float, maximum: float, boss: Node) -> void:
	if not is_instance_valid(boss):
		return
	var id: int = boss.get_instance_id()
	if not boss_entries.has(id):
		return
	var entry: Dictionary = boss_entries[id]
	var percent: int = int(round(100.0 * cur / maxf(maximum, 1.0)))
	var phase: int = int(boss.boss_phase) if "boss_phase" in boss else 1
	entry["label"].text = "☠ %s   %d%%   • فاز %d/3" % [str(boss.get_meta("boss_name", "لویاتان اعماق")), percent, phase]
	entry["bar"].max_value = maximum
	entry["bar"].value = cur

func _on_boss_entry_defeated(_pos: Vector2, boss: Node) -> void:
	_remove_boss_entry(boss)

func _remove_boss_entry(boss: Node) -> void:
	if not is_instance_valid(boss):
		return
	var id: int = boss.get_instance_id()
	if not boss_entries.has(id):
		if boss_node == boss:
			boss_node = null
		return
	var entry: Dictionary = boss_entries[id]
	if boss.has_signal("boss_hp_changed") and entry.has("hp_cb") and boss.boss_hp_changed.is_connected(entry["hp_cb"]):
		boss.boss_hp_changed.disconnect(entry["hp_cb"])
	if boss.has_signal("boss_defeated") and entry.has("defeat_cb") and boss.boss_defeated.is_connected(entry["defeat_cb"]):
		boss.boss_defeated.disconnect(entry["defeat_cb"])
	var row = entry.get("row", null)
	if row != null and is_instance_valid(row):
		row.queue_free()
	boss_entries.erase(id)
	if boss_node == boss:
		boss_node = null
	if boss_entries.is_empty() and is_instance_valid(boss_panel):
		boss_panel.visible = false

func _on_boss_hp_changed(cur: float, maximum: float) -> void:
	# سازگاری با اتصال‌های قدیمی
	if is_instance_valid(boss_node):
		_on_boss_entry_hp_changed(cur, maximum, boss_node)

func _on_adrenaline_changed(active: bool, pulse: float) -> void:
	adrenaline_strength = maxf(adrenaline_strength, (0.45 + pulse * 0.28) if active else 0.0)

func quest_type() -> String:
	return str(QUESTS[quest_index]["type"])

func _set_quest(index: int) -> void:
	quest_index = index % QUESTS.size()
	quest_progress = 0
	quest_target = int(QUESTS[quest_index]["target"])
	quest_reward = int(QUESTS[quest_index]["reward"])
	# مأموریت‌های زمانی از همان لحظه شروع می‌شوند؛ قبلاً تایمر همیشه صفر بود.
	quest_timer = float(quest_target) if quest_type() == "survive" else 0.0
	_update_quest_display()

func _update_quest_display() -> void:
	if not is_instance_valid(quest_label): return
	quest_progress_bar.max_value = quest_target
	quest_progress_bar.value = quest_progress
	var suffix: String = ""
	if quest_type() == "survive":
		suffix = "  ⏱ %.0fث" % maxf(quest_timer, 0.0)
	quest_label.text = "🎯 مأموریت: %s  %d/%d%s" % [QUESTS[quest_index]["title"], quest_progress, quest_target, suffix]

func quest_add_progress(kind: String, amount: int = 1) -> void:
	if kind != quest_type(): return
	if kind == "combo": quest_progress = maxi(quest_progress, amount)
	else: quest_progress += amount
	_update_quest_display()
	if quest_progress >= quest_target: _complete_quest()

func _complete_quest() -> void:
	if not is_instance_valid(player): return
	player.add_dna(quest_reward)
	quest_speed_buff = 12.0
	if "quest_speed_timer" in player: player.quest_speed_timer = 12.0
	quest_toast.text = "✅ مأموریت کامل شد! +%d DNA | افزایش سرعت" % quest_reward
	quest_toast.visible = true
	var done: int = quest_index
	_set_quest(done + 1)
	var toast_tween: Tween = create_tween()
	toast_tween.tween_interval(3.0)
	toast_tween.tween_callback(func(): if is_instance_valid(quest_toast): quest_toast.visible = false)

func show_boss_defeated() -> void:
	# هر باس به‌صورت جداگانه از لیست HUD حذف می‌شود؛ باس‌های زنده باقی می‌مانند.
	show_event("🏆 یک باس شکست خورد!", 3.5)

func _create_skill_buttons() -> void:
	# یک جعبه عمودی مجزا در پایین-راست، بالای دکمه BOOST،
	# تا «موج شوک» و «سپر» روی BOOST نیفتند و تمیز چیده شوند.
	var skill_box: VBoxContainer = VBoxContainer.new()
	skill_box.name = "SkillBox"
	skill_box.anchor_left = 1.0
	skill_box.anchor_top = 1.0
	skill_box.anchor_right = 1.0
	skill_box.anchor_bottom = 1.0
	skill_box.offset_left = -194.0
	skill_box.offset_top = -300.0
	skill_box.offset_right = -24.0
	skill_box.offset_bottom = -184.0
	skill_box.add_theme_constant_override("separation", 10)
	skill_box.alignment = BoxContainer.ALIGNMENT_END
	$Root.add_child(skill_box)

	shield_button = Button.new()
	shield_button.name = "ShieldSkillButton"
	shield_button.text = "🛡 سپر"
	shield_button.custom_minimum_size = Vector2(170, 56)
	shield_button.size_flags_horizontal = Control.SIZE_FILL
	shield_button.add_theme_font_size_override("font_size", 22)
	shield_button.pressed.connect(_on_shield_pressed)
	skill_box.add_child(shield_button)

	shockwave_button = Button.new()
	shockwave_button.name = "ShockwaveSkillButton"
	shockwave_button.text = "💥 موج شوک"
	shockwave_button.custom_minimum_size = Vector2(170, 56)
	shockwave_button.size_flags_horizontal = Control.SIZE_FILL
	shockwave_button.add_theme_font_size_override("font_size", 22)
	shockwave_button.pressed.connect(_on_shockwave_pressed)
	skill_box.add_child(shockwave_button)

func _start_pause_pulse() -> void:
	# انیمیشن پایه؛ تم هر منطقه شدت/حالت خودش را دارد.
	pause_btn.pivot_offset = pause_btn.size / 2.0
	pause_btn.resized.connect(func(): pause_btn.pivot_offset = pause_btn.size / 2.0)
	var tw: Tween = create_tween()
	tw.set_loops()
	tw.set_trans(Tween.TRANS_SINE)
	tw.set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(pause_btn, "scale", Vector2(1.07, 1.07), 0.85)
	tw.tween_property(pause_btn, "scale", Vector2(1.0, 1.0), 0.85)

func _apply_pause_button_theme(region: String) -> void:
	if not is_instance_valid(pause_btn):
		return
	var accent := Color(0.25, 0.95, 0.72)
	var secondary := Color(0.03, 0.15, 0.18)
	var icon := "⏸"
	var radius := 24
	match region:
		"دشت آرام":
			accent = Color(0.25, 0.95, 0.72); secondary = Color(0.03, 0.16, 0.15); icon = "⏸"; radius = 28
		"جنگل زیستی":
			accent = Color(0.30, 1.0, 0.32); secondary = Color(0.03, 0.17, 0.06); icon = "🌿"; radius = 18
		"منطقه شکار":
			accent = Color(1.0, 0.20, 0.12); secondary = Color(0.20, 0.025, 0.02); icon = "⏸"; radius = 12
		"خندق تاریک":
			accent = Color(0.62, 0.30, 1.0); secondary = Color(0.09, 0.03, 0.18); icon = "◈"; radius = 8
		"شهر مرجانی":
			accent = Color(1.0, 0.35, 0.70); secondary = Color(0.20, 0.035, 0.12); icon = "🪸"; radius = 30
		"دره کریستالی":
			accent = Color(0.35, 0.88, 1.0); secondary = Color(0.02, 0.12, 0.20); icon = "💎"; radius = 6
		"غار زیستی":
			accent = Color(0.75, 0.38, 1.0); secondary = Color(0.12, 0.035, 0.20); icon = "🍄"; radius = 22
		"آب‌های یخی":
			accent = Color(0.65, 0.92, 1.0); secondary = Color(0.02, 0.12, 0.22); icon = "❄"; radius = 34

	pause_btn.text = icon
	pause_btn.add_theme_font_size_override("font_size", 34)
	var normal := StyleBoxFlat.new()
	normal.bg_color = secondary
	normal.border_color = accent
	normal.set_border_width_all(3)
	normal.set_corner_radius_all(radius)
	normal.shadow_color = Color(accent.r, accent.g, accent.b, 0.28)
	normal.shadow_size = 10
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(secondary.r + 0.03, secondary.g + 0.03, secondary.b + 0.03, 1.0)
	hover.shadow_color = Color(accent.r, accent.g, accent.b, 0.55)
	hover.shadow_size = 16
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(accent.r * 0.25, accent.g * 0.25, accent.b * 0.25, 1.0)
	pressed.set_border_width_all(4)
	pause_btn.add_theme_stylebox_override("normal", normal)
	pause_btn.add_theme_stylebox_override("hover", hover)
	pause_btn.add_theme_stylebox_override("pressed", pressed)
	pause_btn.add_theme_color_override("font_color", accent)
	pause_btn.add_theme_color_override("font_hover_color", Color.WHITE)
	pause_btn.add_theme_color_override("font_pressed_color", Color.WHITE)
	var tween := create_tween()
	tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tween.set_trans(Tween.TRANS_BACK)
	tween.tween_property(pause_btn, "scale", Vector2(1.16, 1.16), 0.16)
	tween.tween_property(pause_btn, "scale", Vector2.ONE, 0.22)

func _on_shield_pressed() -> void:
	if is_instance_valid(player) and player.has_method("activate_shield"):
		player.activate_shield()

func _on_shockwave_pressed() -> void:
	if is_instance_valid(player) and player.has_method("activate_shockwave"):
		player.activate_shockwave()

func _style_bar(bar: ProgressBar, bg: Color, fill: Color):
	# Tall bars with clean borders, mobile-friendly
	bar.custom_minimum_size.y = 26.0
	var sb_bg : StyleBoxFlat = StyleBoxFlat.new()
	sb_bg.bg_color = bg
	sb_bg.set_corner_radius_all(6)
	sb_bg.set_border_width_all(2)
	sb_bg.border_color = Color(0, 0, 0, 0.85)
	var sb_fill : StyleBoxFlat = StyleBoxFlat.new()
	sb_fill.bg_color = fill
	sb_fill.set_corner_radius_all(6)
	bar.add_theme_stylebox_override("background", sb_bg)
	bar.add_theme_stylebox_override("fill", sb_fill)


func _animate_popup_open(popup: Control) -> void:
	# انیمیشن باز شدن نرم و امن پاپ‌آپ‌ها: محو شدن + بزرگ‌شدن از ۰.۸۸ به ۱
	if not is_instance_valid(popup):
		return
	if popup_tweens.has(popup) and is_instance_valid(popup_tweens[popup]):
		popup_tweens[popup].kill()
	popup.visible = true
	popup.pivot_offset = popup.size / 2.0
	popup.scale = Vector2(0.88, 0.88)
	popup.modulate.a = 0.0
	var tw: Tween = create_tween()
	tw.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
	tw.set_parallel(true)
	tw.set_trans(Tween.TRANS_BACK)
	tw.set_ease(Tween.EASE_OUT)
	tw.tween_property(popup, "modulate:a", 1.0, 0.25)
	tw.tween_property(popup, "scale", Vector2.ONE, 0.28)
	tw.chain().tween_callback(func():
		popup.modulate.a = 1.0
		popup.scale = Vector2.ONE)
	popup_tweens[popup] = tw

func _animate_popup_text(popup: Control) -> void:
	for old_tween: Tween in popup_text_tweens:
		if is_instance_valid(old_tween):
			old_tween.kill()
	popup_text_tweens.clear()
	var content: Node = popup.find_child("VBox", true, false)
	if content == null:
		return
	var delay: float = 0.04
	for item: Node in content.get_children():
		if item is Control:
			var control: Control = item as Control
			control.modulate.a = 0.0
			control.scale = Vector2(0.97, 0.97)
			control.pivot_offset = control.size / 2.0
			var text_tween: Tween = create_tween()
			text_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
			text_tween.tween_interval(delay)
			text_tween.set_parallel(true)
			text_tween.set_trans(Tween.TRANS_SINE)
			text_tween.set_ease(Tween.EASE_OUT)
			text_tween.tween_property(control, "modulate:a", 1.0, 0.24)
			text_tween.tween_property(control, "scale", Vector2.ONE, 0.24)
			popup_text_tweens.append(text_tween)
			delay += 0.055

func _reset_popup(popup: Control) -> void:
	# ریست کامل حالت بصری هنگام بسته‌شدن تا انیمیشن بعدی تمیز شروع شود
	if not is_instance_valid(popup):
		return
	if popup_tweens.has(popup) and is_instance_valid(popup_tweens[popup]):
		popup_tweens[popup].kill()
	popup_tweens.erase(popup)
	popup.visible = false
	popup.modulate.a = 1.0
	popup.scale = Vector2.ONE

func _style_stats_hud() -> void:
	# پنل مشخصات بازیکن: فاصله‌دار، خوانا و با هاله‌ی زنده‌ی اقیانوسی.
	var stats_panel: Control = $Root/TopLeftPanel
	if not is_instance_valid(stats_panel):
		return
	stats_panel.pivot_offset = stats_panel.size / 2.0
	var box: VBoxContainer = $Root/TopLeftPanel/VBox
	box.add_theme_constant_override("separation", 14)
	box.add_theme_constant_override("margin_left", 10)
	box.add_theme_constant_override("margin_right", 10)
	box.add_theme_constant_override("margin_top", 8)
	box.add_theme_constant_override("margin_bottom", 8)
	var panel_style := StyleBoxFlat.new()
	panel_style.bg_color = Color(0.005, 0.018, 0.045, 0.92)
	panel_style.border_color = Color(0.20, 0.92, 1.0, 0.88)
	panel_style.set_border_width_all(3)
	panel_style.set_corner_radius_all(24)
	panel_style.shadow_color = Color(0.0, 0.78, 1.0, 0.34)
	panel_style.shadow_size = 18
	stats_panel.add_theme_stylebox_override("panel", panel_style)
	var labels: Array[Label] = [score_label, high_score_label, dna_label, mass_label, health_label, level_label]
	var sizes: Array[int] = [29, 32, 32, 31, 31, 29]
	for i in range(labels.size()):
		var label: Label = labels[i]
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		label.add_theme_font_size_override("font_size", sizes[i])
		label.add_theme_color_override("font_color", Color(0.86, 0.97, 1.0))
		label.add_theme_color_override("font_outline_color", Color(0.0, 0.08, 0.14, 0.96))
		label.add_theme_constant_override("outline_size", 5)
	# انیمیشن تنفسِ هاله + ضربان بسیار ظریفِ کل پنل.
	var glow_tween := create_tween().set_loops()
	glow_tween.tween_property(panel_style, "shadow_size", 26.0, 0.9).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	glow_tween.tween_property(panel_style, "shadow_size", 14.0, 0.9).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var pulse_tween := create_tween().set_loops()
	pulse_tween.tween_property(stats_panel, "modulate", Color(0.88, 1.0, 1.0, 1.0), 0.75).set_trans(Tween.TRANS_SINE)
	pulse_tween.tween_property(stats_panel, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.75).set_trans(Tween.TRANS_SINE)
	# یک ورود سینمایی کوتاه در شروع مرحله.
	stats_panel.scale = Vector2(0.94, 0.94)
	stats_panel.modulate.a = 0.0
	var intro := create_tween()
	intro.set_parallel(true)
	intro.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	intro.tween_property(stats_panel, "scale", Vector2.ONE, 0.55)
	intro.tween_property(stats_panel, "modulate:a", 1.0, 0.35)

func bind_player(p: Node):
	player = p
	p.mass_changed.connect(_on_mass_changed)
	p.evolved.connect(_on_evolved)
	p.score_updated.connect(_on_score_updated)
	p.player_died.connect(_on_player_died)
	p.evolution_choice_requested.connect(_on_evolution_choice_requested)
	_on_mass_changed(p.mass, p.get_req_mass_for_level(p.level))
	p.hp_changed.connect(_on_hp_changed)
	if p.has_signal("adrenaline_changed"):
		p.adrenaline_changed.connect(_on_adrenaline_changed)
	if p.has_signal("food_eaten"):
		p.food_eaten.connect(func(_value: float): quest_add_progress("food", 1))
	if p.has_signal("combo_reached"):
		p.combo_reached.connect(func(combo: int): quest_add_progress("combo", combo))
	_on_hp_changed(p.current_hp, p.max_hp)

func _on_mass_changed(cur_mass: float, req_mass: float):
	mass_label.text = "جرم: %d / %d" % [int(cur_mass), int(req_mass)]
	# Use a normalized target, independent of per-level mass thresholds.
	level_bar.max_value = 1.0
	target_level_progress = clampf(cur_mass / maxf(req_mass, 1.0), 0.0, 1.0)

func _on_hp_changed(cur_hp: float, max_hp: float):
	health_bar.max_value = max_hp
	health_bar.value = cur_hp
	health_label.text = "❤️ سلامت: %d / %d" % [int(maxf(cur_hp, 0.0)), int(max_hp)]

func _on_score_updated(score: int):
	score_label.text = "امتیاز: %d" % score

func _process(_delta):
	if event_banner_timer > 0.0:
		event_banner_timer = maxf(0.0, event_banner_timer - _delta)
		if event_banner_timer == 0.0 and is_instance_valid(event_banner): event_banner.visible = false
	if region_banner_timer > 0.0:
		region_banner_timer = maxf(0.0, region_banner_timer - _delta)
		if region_banner_timer == 0.0 and is_instance_valid(region_banner):
			var fade = create_tween()
			fade.tween_property(region_banner, "modulate:a", 0.0, 0.35)
			fade.tween_callback(func(): region_banner.visible = false)
	if quest_timer > 0.0:
		quest_timer = maxf(0.0, quest_timer - _delta)
		if quest_type() == "survive":
			# پیشرفت از خود تایمر محاسبه می‌شود؛ int(delta) در هر فریم صفر بود.
			quest_progress = mini(quest_target, quest_target - int(ceil(quest_timer)))
			_update_quest_display()
			if quest_timer <= 0.0 and quest_progress >= quest_target:
				_complete_quest()
	if adrenaline_strength > 0.0:
		adrenaline_strength = move_toward(adrenaline_strength, 0.0, _delta * 0.35)
		if is_instance_valid(adrenaline_overlay):
			var pulse_alpha: float = adrenaline_strength * (0.68 + 0.22 * sin(Time.get_ticks_msec() * 0.012))
			adrenaline_overlay.color = Color(0.75, 0.015, 0.035, clampf(pulse_alpha, 0.0, 0.75))
	# همگام‌سازی چند باس همزمان.
	# نکته مهم: بعد از queue_free شدن باس، نگه‌داشتن آن در یک متغیر typed Node
	# می‌تواند در Godot 4 خطای «Trying to assign invalid previously freed instance» بدهد.
	# بنابراین ابتدا مقدار را بدون type می‌گیریم و فقط اگر معتبر بود با آن کار می‌کنیم.
	for id in boss_entries.keys().duplicate():
		if not boss_entries.has(id):
			continue
		var entry: Dictionary = boss_entries[id]
		var boss_ref = entry.get("node", null)
		if boss_ref != null and is_instance_valid(boss_ref):
			_update_boss_entry(boss_ref)
		else:
			# باس از صحنه حذف شده؛ فقط ردیف HUD را پاک کن، بدون لمس آبجکت آزادشده.
			var row = entry.get("row", null)
			if row != null and is_instance_valid(row):
				row.queue_free()
			boss_entries.erase(id)
	if boss_entries.is_empty() and is_instance_valid(boss_panel):
		boss_panel.visible = false

	if quest_speed_buff > 0.0:
		quest_speed_buff = maxf(0.0, quest_speed_buff - _delta)
	if player and is_instance_valid(player):
		_update_powerup_badges()
		stamina_bar.value = player.boost_stamina
		level_bar.value = move_toward(level_bar.value, target_level_progress, _delta * 0.8)
		dna_label.text = "🧬 DNA: %d" % SaveManager.total_dna
		dna_this_run = SaveManager.total_dna - dna_at_start
		if is_instance_valid(shield_button):
			var shield_ready: bool = player.shield_unlocked
			shield_button.visible = shield_ready
			shield_button.disabled = not shield_ready or player.shield_cooldown > 0.0
			shield_button.text = "🛡 سپر" if player.shield_cooldown <= 0.0 else "🛡 %.1fث" % player.shield_cooldown
		if is_instance_valid(shockwave_button):
			var wave_ready: bool = player.shockwave_unlocked
			shockwave_button.visible = wave_ready
			shockwave_button.disabled = not wave_ready or player.shockwave_cooldown > 0.0
			shockwave_button.text = "💥 موج شوک" if player.shockwave_cooldown <= 0.0 else "💥 %.1fث" % player.shockwave_cooldown

func _on_evolved(new_level: int, _stats: Dictionary):
	level_label.text = "سطح تکامل: %d" % new_level
	high_score_label.text = "🏆 رکورد: %d" % SaveManager.high_score
	_show_evolve_banner()

func _on_evolution_choice_requested(_new_level: int):
	if not is_instance_valid(player):
		return
	# آزمایشگاه تکامل: ۵ گزینه همزمان نمایش داده می‌شود و سطح فعلی هر گزینه مشخص است.
	var keys: Array = EVOLUTION_UPGRADES.keys()
	keys.shuffle()
	for c in evolution_buttons.get_children():
		c.queue_free()
	for i in range(mini(5, keys.size())):
		var key: String = keys[i]
		var info: Array = EVOLUTION_UPGRADES[key]
		var current_level: int = _get_evolution_level(key)
		var btn : Button = Button.new()
		btn.text = "%s  %s  |  سطح %d/%d\n%s" % [info[0], info[1], current_level, EVOLUTION_MAX_LEVEL, info[2]]
		btn.add_theme_font_size_override("font_size", 30)
		btn.add_theme_color_override("font_color", Color("#caf0f8"))
		btn.add_theme_color_override("font_hover_color", Color("#4deeea"))
		btn.add_theme_color_override("font_outline_color", Color("#063248"))
		btn.add_theme_constant_override("outline_size", 2)
		btn.custom_minimum_size = Vector2(0, 126)
		btn.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		# The world is paused while this popup is open, so the button itself must still process input.
		btn.process_mode = Node.PROCESS_MODE_ALWAYS
		# Touch is handled explicitly by _handle_evolution_touch so Android cannot lose the click
		# while the scene tree is paused.
		btn.mouse_filter = Control.MOUSE_FILTER_IGNORE
		btn.focus_mode = Control.FOCUS_NONE
		btn.set_meta("evolution_key", key)
		evolution_buttons.add_child(btn)
	evolution_title.text = "🧪 آزمایشگاه تکامل | ۵ انتخاب از ۳۰ جهش | هر شاخه تا سطح ۱۵"
	evolution_title.add_theme_color_override("font_color", Color("#4deeea"))
	_animate_popup_open(evolution_choice)
	get_tree().paused = true
	pause_btn.text = "▶"

func _get_evolution_level(key: String) -> int:
	if not is_instance_valid(player):
		return 0
	match key:
		"spike_front": return int(player.front_spike_level)
		"spike_rear": return int(player.rear_spike_level)
		"attack": return int(round((player.attack_mult - 1.0) / 0.20))
		"health": return int(player.level > 0 and player.mass > 20.0) # نمایش محافظه‌کارانه
		"speed": return int(round(maxf(0.0, player.base_speed / 230.0 - 1.0) / 0.10))
		"magnet": return int(player.evolution_magnet)
		"regen": return int(player.evolution_regen)
		"dna": return int(round((player.evolution_dna_mult - 1.0) / 0.12))
		"shockwave": return int(player.shockwave_level)
		"shield": return int(player.shield_level)
		"poison_skin": return int(player.poison_skin_level)
		"vampirism": return int(player.vampirism_level)
		"time_warp": return int(player.time_warp_level)
		"armor": return int(player.armor_level)
		"metabolism": return int(player.metabolism_level)
		"thorns": return int(player.thorns_level)
		"dash": return int(player.dash_level)
		"vitality": return int(player.vitality_level)
		"predator": return int(player.predator_level)
		"gravity": return int(player.gravity_level)
		"adaptation": return int(player.adaptation_level)
		_: return int(player.evolution_extra_levels.get(key, 0))
	return 0

func _on_evolution_upgrade_pressed(key: String):
	_reset_popup(evolution_choice)
	get_tree().paused = false
	_apply_pause_button_theme(pause_region_theme)
	if is_instance_valid(player):
		player.apply_evolution_upgrade(key)

func _show_evolve_banner():
	evolve_banner.visible = true
	evolve_banner.modulate.a = 0.0
	if banner_tween:
		banner_tween.kill()
	banner_tween = create_tween()
	banner_tween.tween_property(evolve_banner, "modulate:a", 1.0, 0.3)
	banner_tween.tween_interval(2.2)
	banner_tween.tween_property(evolve_banner, "modulate:a", 0.0, 0.6)
	banner_tween.tween_callback(func(): evolve_banner.visible = false)

func _on_boost_down():
	if player and is_instance_valid(player):
		_update_powerup_badges()
		player.is_boosting = true
		SoundManager.play_boost()

func _on_boost_up():
	if player and is_instance_valid(player):
		_update_powerup_badges()
		player.is_boosting = false

func set_region_pause_theme(region: String) -> void:
	pause_region_theme = region
	_apply_pause_button_theme(region)

func _on_pause_gui_input(event: InputEvent) -> void:
	# The Button.pressed signal performs the action. Here we only consume the
	# pointer event so it never falls through to gameplay movement.
	if (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed):
		get_viewport().set_input_as_handled()

func _toggle_pause():
	var tree: SceneTree = get_tree()
	var will_pause := not tree.paused
	if will_pause:
		# تم فعلی منطقه حفظ می‌شود؛ خود پنل توقف هم با همان حال‌وهوا باز می‌شود.
		var world := get_tree().get_first_node_in_group("world")
		if is_instance_valid(world) and "region_name" in world:
			pause_region_theme = str(world.region_name)
			_apply_pause_button_theme(pause_region_theme)
		pause_menu.visible = true
		_animate_popup_open(pause_menu)
		tree.paused = true
		pause_btn.text = "▶"
	else:
		tree.paused = false
		pause_menu.visible = false
		_reset_popup(pause_menu)
		_apply_pause_button_theme(pause_region_theme)

func _on_sound_toggled(on: bool):
	SaveManager.sound_enabled = on
	SaveManager.save_game()

func _restart():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/World.tscn")

func _go_menu():
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _on_player_died():
	# Game Over takes priority over every other popup.
	pause_menu.visible = false
	evolution_choice.visible = false
	get_tree().paused = true
	var panel: VBoxContainer = $Root/GameOver/Panel/VBox
	var final_score: int = player.score if player else 0
	var is_new_record: bool = final_score >= SaveManager.high_score and final_score > 0
	panel.get_node("ScoreLabel").text = "امتیاز نهایی: %d" % final_score
	panel.get_node("RecordLabel").text = "🏆 رکورد: %d%s" % [SaveManager.high_score, "  (رکورد جدید! 🎉)" if is_new_record else ""]
	panel.get_node("DNALabel").text = "🧬 DNA جمع‌آوری‌شده این دور: %d" % dna_this_run
	_animate_popup_open(game_over)

func _on_pause_button_pressed() -> void:
	# Emitted by the Button GUI layer after the touch is targeted to the pause control.
	_toggle_pause()

func _unhandled_input(event: InputEvent) -> void:
	# Keep keyboard/gamepad pause handling here. Touch movement is handled in
	# _input above so Android mouse/touch emulation cannot swallow movement.
	if event.is_action_pressed("ui_cancel"):
		_toggle_pause()
		get_viewport().set_input_as_handled()



# ==================== دایرةالمعارف گونه‌ها (Species Codex) ====================

const SPECIES_CODEX_ENTRIES: Array[Dictionary] = [
	{"icon": "🐟", "name": "شکارچی کوچک", "desc": "کوچک‌ترین شکارچی دریا؛ با تماس آسیب می‌زند."},
	{"icon": "🦈", "name": "کوسهٔ اعماق", "desc": "شکارچی سریع و خطرناک مناطق عمیق."},
	{"icon": "🐙", "name": "اختاپوس غول", "desc": "بازوهای بلند دارد و ضربهٔ سنگین می‌زند."},
	{"icon": "🦀", "name": "خرچنگ زره‌پوش", "desc": "پوستهٔ سخت؛ به زره قوی نیاز داری."},
	{"icon": "🪼", "name": "عروس دریایی سمی", "desc": "تماس با آن آسیب سم تدریجی وارد می‌کند."},
	{"icon": "🐡", "name": "ماهی خاردار", "desc": "خارهای تیز دارد؛ از رو حمله نکن."},
	{"icon": "🦑", "name": "سفیدجوک غول", "desc": "شکارچی عمق؛ سریع و چابک است."},
	{"icon": "🐢", "name": "لاک‌پشت باستانی", "desc": "آرام اما بسیار مقاوم؛ جرم زیادی دارد."},
]

func _build_species_codex() -> void:
	if is_instance_valid(species_codex):
		return
	species_codex = Control.new()
	species_codex.name = "SpeciesCodex"
	species_codex.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	species_codex.mouse_filter = Control.MOUSE_FILTER_STOP
	species_codex.process_mode = Node.PROCESS_MODE_ALWAYS
	species_codex.visible = false
	species_codex.z_index = 300
	var dim: ColorRect = ColorRect.new()
	dim.name = "Dim"
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0.0, 0.02, 0.05, 0.72)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	species_codex.add_child(dim)

	species_codex_panel = PanelContainer.new()
	species_codex_panel.name = "Panel"
	species_codex_panel.anchor_left = 0.10
	species_codex_panel.anchor_right = 0.90
	species_codex_panel.anchor_top = 0.08
	species_codex_panel.anchor_bottom = 0.92
	species_codex_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	# StyleBoxFlat با گوشه‌های گرد و حاشیهٔ درخشان
	var panel_style: StyleBoxFlat = StyleBoxFlat.new()
	panel_style.bg_color = Color(0.02, 0.06, 0.10, 0.96)
	panel_style.border_color = Color(0.30, 0.95, 0.85, 0.95)
	panel_style.set_border_width_all(3)
	panel_style.set_corner_radius_all(24)
	panel_style.shadow_color = Color(0.0, 0.95, 0.85, 0.35)
	panel_style.shadow_size = 18
	species_codex_panel.add_theme_stylebox_override("panel", panel_style)

	var box: VBoxContainer = VBoxContainer.new()
	box.name = "VBox"
	box.add_theme_constant_override("separation", 12)
	var margin: MarginContainer = MarginContainer.new()
	for side in ["left","right","top","bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_child(box)
	species_codex_panel.add_child(margin)

	var title: Label = Label.new()
	title.text = "📖 دایرةالمعارف گونه‌ها"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.text_direction = Control.TEXT_DIRECTION_RTL
	title.layout_direction = Control.LAYOUT_DIRECTION_RTL
	title.add_theme_font_size_override("font_size", 26)
	title.add_theme_color_override("font_color", Color(0.55, 1.0, 0.92))
	title.add_theme_color_override("font_outline_color", Color(0.0, 0.05, 0.1, 1.0))
	title.add_theme_constant_override("outline_size", 6)
	box.add_child(title)

	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	species_codex_list = VBoxContainer.new()
	species_codex_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	species_codex_list.add_theme_constant_override("separation", 10)
	scroll.add_child(species_codex_list)
	box.add_child(scroll)

	for entry in SPECIES_CODEX_ENTRIES:
		var item: PanelContainer = PanelContainer.new()
		var item_style: StyleBoxFlat = StyleBoxFlat.new()
		item_style.bg_color = Color(0.03, 0.09, 0.14, 0.92)
		item_style.border_color = Color(0.2, 0.85, 0.8, 0.6)
		item_style.set_border_width_all(2)
		item_style.set_corner_radius_all(16)
		item_style.shadow_color = Color(0.0, 0.85, 0.8, 0.25)
		item_style.shadow_size = 8
		item.add_theme_stylebox_override("panel", item_style)
		var item_box: HBoxContainer = HBoxContainer.new()
		item_box.add_theme_constant_override("separation", 14)
		var icon: Label = Label.new()
		icon.text = str(entry["icon"])
		icon.add_theme_font_size_override("font_size", 22)
		icon.custom_minimum_size.x = 44
		item_box.add_child(icon)
		var name_lbl: Label = Label.new()
		name_lbl.text = str(entry["name"])
		name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_lbl.text_direction = Control.TEXT_DIRECTION_RTL
		name_lbl.layout_direction = Control.LAYOUT_DIRECTION_RTL
		# برچسب آیتم: فونت ۲۰ یا بیشتر
		name_lbl.add_theme_font_size_override("font_size", 20)
		name_lbl.add_theme_color_override("font_color", Color(0.8, 1.0, 0.95))
		item_box.add_child(name_lbl)
		var desc_lbl: Label = Label.new()
		desc_lbl.text = str(entry["desc"])
		desc_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		desc_lbl.text_direction = Control.TEXT_DIRECTION_RTL
		desc_lbl.layout_direction = Control.LAYOUT_DIRECTION_RTL
		desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		desc_lbl.add_theme_font_size_override("font_size", 20)
		desc_lbl.add_theme_color_override("font_color", Color(0.72, 0.86, 0.92))
		item_box.add_child(desc_lbl)
		item.add_child(item_box)
		species_codex_list.add_child(item)

	# دکمهٔ بستن با استایل درخشان و گوشه گرد
	species_codex_close_btn = Button.new()
	species_codex_close_btn.name = "CloseButton"
	species_codex_close_btn.text = "بستن"
	species_codex_close_btn.custom_minimum_size = Vector2(0, 64)
	species_codex_close_btn.add_theme_font_size_override("font_size", 22)
	species_codex_close_btn.text_direction = Control.TEXT_DIRECTION_RTL
	var btn_normal: StyleBoxFlat = StyleBoxFlat.new()
	btn_normal.bg_color = Color(0.05, 0.22, 0.28, 0.98)
	btn_normal.border_color = Color(0.35, 1.0, 0.9, 0.95)
	btn_normal.set_border_width_all(2)
	btn_normal.set_corner_radius_all(18)
	btn_normal.shadow_color = Color(0.0, 1.0, 0.9, 0.4)
	btn_normal.shadow_size = 12
	var btn_hover: StyleBoxFlat = btn_normal.duplicate()
	btn_hover.bg_color = Color(0.08, 0.32, 0.38, 1.0)
	btn_hover.shadow_color = Color(0.0, 1.0, 0.95, 0.7)
	var btn_pressed: StyleBoxFlat = btn_normal.duplicate()
	btn_pressed.bg_color = Color(0.03, 0.14, 0.18, 1.0)
	species_codex_close_btn.add_theme_stylebox_override("normal", btn_normal)
	species_codex_close_btn.add_theme_stylebox_override("hover", btn_hover)
	species_codex_close_btn.add_theme_stylebox_override("pressed", btn_pressed)
	species_codex_close_btn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	box.add_child(species_codex_close_btn)

	# اتصال استاندارد + پشتیبان رویداد لمسی
	species_codex_close_btn.pressed.connect(_close_species_codex)

	species_codex.add_child(species_codex_panel)
	$Root.add_child(species_codex)

func open_species_codex() -> void:
	_build_species_codex()
	species_codex_open = true
	species_codex.visible = true
	species_codex.modulate = Color(1, 1, 1, 0)
	species_codex_panel.scale = Vector2(0.85, 0.85)
	species_codex_panel.pivot_offset = species_codex_panel.size * 0.5
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(species_codex, "modulate:a", 1.0, 0.25).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(species_codex_panel, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	get_tree().paused = true

# انیمیشن باز شدن در تابع نام‌دار جداگانه
func _play_codex_open_tween() -> void:
	if not is_instance_valid(species_codex):
		return
	species_codex.modulate = Color(1, 1, 1, 0)
	species_codex_panel.scale = Vector2(0.85, 0.85)
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(species_codex, "modulate:a", 1.0, 0.25).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tw.tween_property(species_codex_panel, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func _close_species_codex() -> void:
	if not species_codex_open:
		return
	species_codex_open = false
	get_tree().paused = false
	if is_instance_valid(species_codex):
		var tw: Tween = create_tween()
		tw.tween_property(species_codex, "modulate:a", 0.0, 0.15)
		tw.tween_callback(func(): species_codex.visible = false)

func _handle_species_codex_touch(event: InputEvent) -> void:
	# پشتیبان لمسی: اگر رویداد لمس/موس مستقیم روی دکمهٔ بستن آمد
	if not species_codex_open or not is_instance_valid(species_codex_close_btn):
		return
	var pos: Vector2 = Vector2.ZERO
	var pressed: bool = false
	if event is InputEventScreenTouch:
		pos = event.position
		pressed = event.pressed
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		pos = event.position
		pressed = event.pressed
	else:
		return
	if pressed and species_codex_close_btn.get_global_rect().has_point(pos):
		var viewport := get_viewport()
		if is_instance_valid(viewport):
			viewport.set_input_as_handled()
		_close_species_codex()

func _input_species_codex(event: InputEvent) -> void:
	# رابط برای فراخوانی از _input اصلی در صورت لزوم
	if species_codex_open:
		_handle_species_codex_touch(event)


func _create_badge(txt: String, col: Color) -> Label:
	var badge: Label = Label.new()
	badge.text = txt
	badge.add_theme_font_size_override("font_size", 16)
	badge.add_theme_color_override("font_color", col)
	badge.add_theme_color_override("font_outline_color", Color(0.02, 0.06, 0.1, 0.95))
	badge.add_theme_constant_override("outline_size", 4)
	badge.visible = false
	powerup_badges_container.add_child(badge)
	return badge


func _update_powerup_badges() -> void:
	if not is_instance_valid(player) or not is_instance_valid(powerup_badges_container):
		return
	# Bio Shield
	if is_instance_valid(shield_badge):
		shield_badge.visible = bool(player.get("bio_shield_active"))
	# Magnet
	if is_instance_valid(magnet_badge):
		var m_time: float = float(player.get("magnet_powerup_timer"))
		magnet_badge.visible = m_time > 0.0
		if m_time > 0.0:
			magnet_badge.text = "🧲 آهنربا: %.1fث" % m_time
	# Hyper Speed
	if is_instance_valid(speed_badge):
		var s_time: float = float(player.get("hyper_speed_timer"))
		speed_badge.visible = s_time > 0.0
		if s_time > 0.0:
			speed_badge.text = "⚡ سوپر سرعت: %.1fث" % s_time
	# DNA Catalyst
	if is_instance_valid(dna_badge):
		var d_time: float = float(player.get("dna_catalyst_timer"))
		dna_badge.visible = d_time > 0.0
		if d_time > 0.0:
			dna_badge.text = "🌟 DNA ۲برابر: %.1fث" % d_time
