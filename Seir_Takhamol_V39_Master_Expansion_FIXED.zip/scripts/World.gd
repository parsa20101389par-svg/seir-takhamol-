extends Node2D
# سیر تکامل - صحنه دنیا: اقیانوس عمیق، اسپاونر اکوسیستم، مرگ و افت غذا

const MAP_RADIUS: float = 2500.0
const FOOD_TARGET: int = 145
const FOOD_SPAWN_BATCH: int = 4
const FOOD_PLAYER_RING_MIN: float = 320.0
const FOOD_PLAYER_RING_MAX: float = 1300.0
const ENEMY_TARGETS: Dictionary = {
	0: 17,  # AMINO_GRAZER
	1: 11,  # VIRUS_HUNTER
	2: 7,   # ARMORED_DIATOM
	3: 9,   # ELECTRIC_JELLY
	4: 3,   # LEVIATHAN_TITAN
	5: 10,  # ACID_SPITTER
	6: 20,  # SWARM_MITE
	7: 6,   # CRYSTAL_AMOEBA
}
const MAX_TOTAL_ENEMIES: int = 24
const INITIAL_ENEMY_COUNT: int = 12
const CULL_DISTANCE: float = 2800.0

const ENEMY_SCENE: PackedScene = preload("res://scenes/EnemyCell.tscn")
const FOOD_SCENE: PackedScene = preload("res://scenes/Food.tscn")
const ACID_SCENE: PackedScene = preload("res://scenes/AcidProjectile.tscn")
const MASTERPIECE_SCRIPT: Script = preload("res://scripts/MasterpieceDirector.gd")

func spawn_acid_projectile(from_pos: Vector2, dir: Vector2, spd: float = 170.0, dmg: float = 6.0):
	# AcidProjectile always enters the tree through the world entities node
	if not is_instance_valid(entities):
		return
	var proj = ACID_SCENE.instantiate()
	proj.position = from_pos
	entities.add_child(proj)
	proj.setup(dir, spd, dmg)

@onready var player: CharacterBody2D = $PlayerCell
@onready var camera: Camera2D = $PlayerCell/Camera2D
@onready var entities: Node2D = $Entities
@onready var background: Node2D = $Background
@onready var boundary: Node2D = $Boundary
@onready var ui: CanvasLayer = $UI

var spawn_timer: float = 0.0
var run_time: float = 0.0
var event_timer: float = 70.0
var next_boss_time: float = 120.0
var active_event: String = ""
var event_time_left: float = 0.0
var active_event_time_total: float = 0.0
var acid_zone_position: Vector2 = Vector2.ZERO
var acid_zone_time: float = 0.0
var acid_damage_timer: float = 0.0
var camera_shake: float = 0.0
var feedback_pool: Array[Label] = []
var rng : RandomNumberGenerator = RandomNumberGenerator.new()
var powerup_spawn_timer: float = 18.0
var treasure_timer: float = 42.0
var milestone_marks: Dictionary = {}
var powerup_nodes: Array[Node2D] = []
var danger_arrows: Array[Polygon2D] = []
var weekly_survive_accumulator: float = 0.0
var masterpiece_director: Node2D = null
var world_detail_color: Color = Color(0,0,0,0)
var region_name: String = "دشت آرام"
var region_index: int = 0
var region_change_timer: float = 60.0
var region_cycle_count: int = 0
var region_bosses_spawned: int = 0
var region_boss_target: int = 4
var region_next_boss_timer: float = 30.0
const REGIONS: Array[Dictionary] = [
    {"name":"دشت آرام", "duration_min":120.0, "duration_max":300.0},
    {"name":"جنگل زیستی", "duration_min":120.0, "duration_max":300.0},
    {"name":"منطقه شکار", "duration_min":120.0, "duration_max":300.0},
    {"name":"خندق تاریک", "duration_min":120.0, "duration_max":300.0},
    {"name":"شهر مرجانی", "duration_min":120.0, "duration_max":300.0},
    {"name":"دره کریستالی", "duration_min":120.0, "duration_max":300.0},
    {"name":"غار زیستی", "duration_min":120.0, "duration_max":300.0},
    {"name":"آب‌های یخی", "duration_min":120.0, "duration_max":300.0}
]
var boss_variant_index: int = 0
const REGION_BOSS_NAMES: Dictionary = {
    "دشت آرام": ["نگهبان سبز", "غول شبنم", "سلول کهربایی", "فرمانروای دشت"],
    "جنگل زیستی": ["هیولای ریشه", "ملکه هاگ", "شکارچی برگ", "تایتان جنگل"],
    "منطقه شکار": ["شکارچی سرخ", "درنده تیغ‌دار", "سلول خون‌خوار", "فرمانروای شکار"],
    "خندق تاریک": ["سایه اعماق", "هیولای خلأ", "چشم تاریک", "فرمانروای خندق"],
    "شهر مرجانی": ["غول مرجانی", "ملکه صدف", "مار مرجانی", "تایتان اقیانوس"],
    "دره کریستالی": ["نگهبان کریستال", "آمیب الماسی", "غول منشوری", "فرمانروای بلور"],
    "غار زیستی": ["قارچ‌خوار", "هیولای اسپور", "ملکه زیست‌تاب", "تایتان غار"],
    "آب‌های یخی": ["شکارچی یخی", "غول یخ‌زده", "نهنگ کریستالی", "فرمانروای یخ"]
}
const BOSS_VARIANTS: Array[Dictionary] = [
	{"type":4, "name":"لویاتان اعماق", "warning":"لویاتان اعماق نزدیک می‌شود!"},
	{"type":5, "name":"ملکه اسید", "warning":"ملکه اسید از تاریکی بیرون آمد!"},
	{"type":3, "name":"مدوسای برق", "warning":"مدوسای برق وارد منطقه شد!"},
	{"type":7, "name":"آمیب کریستالی", "warning":"آمیب کریستالی غول‌آسا بیدار شد!"}
]

func _ready():
	rng.randomize()
	add_to_group("world")
	ui.bind_player(player)
	masterpiece_director = MASTERPIECE_SCRIPT.new()
	masterpiece_director.name = "MasterpieceDirector"
	add_child(masterpiece_director)
	masterpiece_director.setup(self, player)
	# اولین تغییر منطقه بعد از یک دقیقه؛ بعد از آن ۲ تا ۵ دقیقه.
	region_change_timer = 60.0
	player.player_died.connect(_on_player_died)
	player.evolved.connect(_on_player_evolved)
	# اتصال سیگنال‌های PlayerCell به UI و لرزش صفحه
	if player.has_signal("damage_taken"):
		player.damage_taken.connect(_on_player_damage_taken)
	if player.has_signal("food_eaten"):
		player.food_eaten.connect(_on_player_food_eaten)
	if player.has_signal("combo_reached"):
		player.combo_reached.connect(_on_player_combo_reached)
	if player.has_signal("adrenaline_changed"):
		player.adrenaline_changed.connect(_on_player_adrenaline_changed)
	# Initial population (player exists now, so distance check works)
	# ۱۲ دشمن اولیه پخش‌شده روی نقشه (بجای ۹۵) برای روان بودن روی موبایل
	var types = ENEMY_TARGETS.keys()
	for i in range(mini(INITIAL_ENEMY_COUNT, types.size() * 2)):
		_spawn_enemy(types[i % types.size()])
	for i in range(FOOD_TARGET):
		_spawn_food(randi() % 4)
	for i in range(4):
		_create_danger_arrow()
	SoundManager.play_evolve()
	if player.has_method("set_region_visual_tint"):
		player.set_region_visual_tint(_region_color(region_name))
	ui.show_region_change(region_name, true)
	if ui.has_method("set_region_pause_theme"):
		ui.set_region_pause_theme(region_name)

func _process(delta):
	run_time += delta
	update_dynamic_events(delta)
	update_boss_schedule()
	if camera_shake > 0.0:
		camera_shake = maxf(0.0, camera_shake - delta * 24.0)
		camera.offset = Vector2(rng.randf_range(-camera_shake, camera_shake), rng.randf_range(-camera_shake, camera_shake))
	else:
		camera.offset = Vector2.ZERO
	background.position = player.global_position
	boundary.position = Vector2.ZERO
	update_camera_zoom()
	update_spawn(delta)
	update_powerups(delta)
	update_treasure_hunts(delta)
	update_run_milestones()
	update_region(delta)
	weekly_survive_accumulator += delta
	FeatureManager.register_survival(delta)
	FeatureManager.maybe_rare_event(run_time)
	if weekly_survive_accumulator >= 1.0:
		var whole_seconds = int(floor(weekly_survive_accumulator))
		weekly_survive_accumulator -= float(whole_seconds)
		SaveManager.add_weekly_progress("survive", whole_seconds)
	keep_entities_in_bounds()
	cull_distant_entities()

func difficulty_scale() -> float:
	# سختی بازی با سطح بازیکن بالا می‌رود: دشمنان بیشتر/بزرگ‌تر/سریع‌تر می‌شوند
	var lvl: float = float(maxi(1, player.level))
	return clampf(1.0 + (lvl - 1.0) * 0.07, 1.0, 2.6)

func effective_enemy_target(base: int) -> int:
	# با هر سطح، سهمیه هر نوع دشمن کمی بالا می‌رود (تا سقف کل)
	var t: int = int(round(float(base) * (0.9 + difficulty_scale() * 0.25)))
	return mini(t, base + 8)

func _create_danger_arrow() -> void:
	var arrow: Polygon2D = Polygon2D.new()
	arrow.polygon = PackedVector2Array([Vector2(13, 0), Vector2(-9, -8), Vector2(-5, 0), Vector2(-9, 8)])
	arrow.color = Color(1.0, 0.08, 0.12, 0.95)
	arrow.z_index = 120
	ui.add_child(arrow)
	danger_arrows.append(arrow)

func _world_to_screen(world_pos: Vector2) -> Vector2:
	return get_viewport().get_canvas_transform() * world_pos

func update_danger_arrows() -> void:
	if not is_instance_valid(player):
		return
	var viewport: Vector2 = get_viewport_rect().size
	var center: Vector2 = viewport * 0.5
	var margin: Vector2 = Vector2(34.0, 42.0)
	var active: Array[Node] = []
	for enemy in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(enemy) or not enemy.is_predator:
			continue
		var screen: Vector2 = _world_to_screen(enemy.global_position)
		if screen.x >= 0.0 and screen.x <= viewport.x and screen.y >= 0.0 and screen.y <= viewport.y:
			continue
		if player.global_position.distance_to(enemy.global_position) > 1350.0:
			continue
		active.append(enemy)
	for i in range(danger_arrows.size()):
		var arrow: Polygon2D = danger_arrows[i]
		if i >= active.size():
			arrow.visible = false
			continue
		var enemy: Node2D = active[i] as Node2D
		var screen_pos: Vector2 = _world_to_screen(enemy.global_position)
		var direction: Vector2 = screen_pos - center
		if direction.length_squared() < 0.01:
			direction = Vector2.RIGHT
		direction = direction.normalized()
		var half: Vector2 = center - margin
		var scale_factor: float = minf(half.x / maxf(absf(direction.x), 0.001), half.y / maxf(absf(direction.y), 0.001))
		arrow.position = center + direction * scale_factor
		arrow.rotation = direction.angle()
		arrow.visible = true
		var pulse: float = 0.78 + 0.22 * sin(run_time * 9.0 + float(i))
		arrow.color = Color(1.0, 0.06, 0.12, pulse)

func update_powerups(delta: float) -> void:
	powerup_spawn_timer -= delta
	if powerup_spawn_timer <= 0.0:
		powerup_spawn_timer = rng.randf_range(22.0, 32.0)
		_spawn_powerup()
	for orb in powerup_nodes:
		if not is_instance_valid(orb):
			powerup_nodes.erase(orb)
			continue
		var life_left: float = float(orb.get_meta("life", 9999.0)) - delta
		orb.set_meta("life", life_left)
		if life_left <= 0.0:
			orb.queue_free()
			powerup_nodes.erase(orb)
			continue
		if player.global_position.distance_to(orb.global_position) < player.radius + 28.0:
			var ptype = str(orb.get_meta("powerup_type"))
			if ptype == "dna_treasure":
				var reward = int(orb.get_meta("dna_reward", 12))
				player.add_dna(reward)
				player.spawn_float_text("💎 +%d DNA" % reward, Color(0.85, 0.45, 1.0), self, 32)
			else:
				player.apply_ocean_powerup(ptype)
			var label: String = str(orb.get_meta("label"))
			player.spawn_float_text("✨ " + label, Color(0.6, 1.0, 0.9), self, 30)
			SoundManager.play_powerup()
			orb.queue_free()
			powerup_nodes.erase(orb)
	update_danger_arrows()

func _spawn_powerup() -> void:
	var kinds: Array[Dictionary] = [
		{"id":"bio_shield", "label":"سپر زیستی", "color":Color(0.25,0.95,1.0)},
		{"id":"magnet", "label":"جاذبه مغناطیسی", "color":Color(1.0,0.35,0.9)},
		{"id":"hyper_speed", "label":"جریان فراصوت", "color":Color(1.0,0.82,0.18)},
		{"id":"dna_catalyst", "label":"جهش DNA دوبرابر", "color":Color(0.55,1.0,0.42)}
	]
	var data: Dictionary = kinds[rng.randi_range(0, kinds.size() - 1)]
	var orb: Node2D = Node2D.new()
	orb.set_meta("powerup_type", data.id)
	orb.set_meta("label", data.label)
	orb.set_meta("orb_color", data.color)
	orb.z_index = 8
	orb.set_script(load("res://scripts/PowerupOrb.gd"))
	var angle: float = rng.randf_range(0.0, TAU)
	orb.global_position = player.global_position + Vector2(cos(angle), sin(angle)) * rng.randf_range(420.0, 780.0)
	entities.add_child(orb)
	powerup_nodes.append(orb)

func update_camera_zoom():
	var target_zoom: float = clamp(1.6 - (player.radius - 20.0) * 0.012, 0.45, 1.6)
	camera.zoom = camera.zoom.lerp(Vector2(target_zoom, target_zoom), 2.0 * get_process_delta_time())

func update_spawn(delta):
	spawn_timer -= delta
	if spawn_timer > 0.0:
		return
	spawn_timer = 1.0
	# Food
	var foods = get_tree().get_nodes_in_group("food")
	if foods.size() < FOOD_TARGET:
		var missing: int = mini(FOOD_SPAWN_BATCH, FOOD_TARGET - foods.size())
		for i in range(missing):
			_spawn_food(randi() % 4)
	# Enemies
	var counts : Dictionary = {}
	for t in ENEMY_TARGETS:
		counts[t] = 0
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e):
			counts[e.enemy_type] = counts.get(e.enemy_type, 0) + 1
	var total: int = 0
	for t in ENEMY_TARGETS:
		total += counts[t]
	if total >= MAX_TOTAL_ENEMIES:
		return
	for t in ENEMY_TARGETS:
		if counts[t] < effective_enemy_target(ENEMY_TARGETS[t]):
			_spawn_enemy(t)
			break

func random_map_point(margin: float = 100.0) -> Vector2:
	var r = sqrt(rng.randf()) * (MAP_RADIUS - margin)
	var a = rng.randf() * TAU
	return Vector2(cos(a) * r, sin(a) * r)

func _spawn_food(type: int) -> void:
	# بیشترِ غذاها در حلقه‌ای حول بازیکن (داخل محدوده culling) پخش می‌شوند
	# تا هم دیده شوند و هم کل نقشه از غذا خالی نماند؛ فاصله از بازیکن
	# مانع تولید توده‌ای غذا در یک نقطه می‌شود.
	var f: Node2D = FOOD_SCENE.instantiate()
	f.food_type = type
	if player != null and is_instance_valid(player) and rng.randf() < 0.7:
		var a: float = rng.randf() * TAU
		var r: float = rng.randf_range(FOOD_PLAYER_RING_MIN, FOOD_PLAYER_RING_MAX)
		f.position = player.global_position + Vector2(cos(a) * r, sin(a) * r)
		var d: float = f.position.length()
		if d > MAP_RADIUS - 100.0:
			f.position = f.position.normalized() * (MAP_RADIUS - 100.0)
	else:
		f.position = random_map_point()
	entities.add_child(f)

func _spawn_enemy(type: int, boss: bool = false, swarm: bool = false):
	var e = ENEMY_SCENE.instantiate()
	e.enemy_type = type
	e.is_boss = boss
	e.is_event_hunter = swarm
	e.event_lifetime = 20.0 if swarm else 0.0
	e.difficulty = difficulty_scale()
	e.region_name = region_name
	# Spread spawns across the FULL map: keep distance from the player
	# AND from every other living enemy so they never start in a clump.
	var pos: Vector2 = random_map_point(150.0)
	for attempt in range(60):
		var ok : bool = true
		if player != null and is_instance_valid(player) and pos.distance_to(player.global_position) < 950.0:
			ok = false
		if ok:
			for other in get_tree().get_nodes_in_group("enemies"):
				if is_instance_valid(other) and pos.distance_to(other.global_position) < 650.0:
					ok = false
					break
		if ok:
			break
		pos = random_map_point(150.0)
	e.position = pos
	e.target_player = player
	e.died.connect(_on_enemy_died)
	e.hit_player.connect(_on_enemy_hit_player)
	entities.add_child(e)
	if type == 1 or type == 2 or type == 5 or type == 6:
		e.set_hunter_threat(player.mass, player.current_speed)

func _on_enemy_died(enemy_pos: Vector2, _enemy_type: int, enemy_mass: float) -> void:
	var enemy: Node = null
	for candidate in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(candidate) and candidate.global_position.distance_to(enemy_pos) < 2.0:
			enemy = candidate
			break
	var is_boss_kill: bool = is_instance_valid(enemy) and enemy.is_boss
	if is_instance_valid(ui):
		record_enemy_defeated()
		if is_boss_kill:
			ui.show_boss_defeated()
	if is_boss_kill:
		FeatureManager.register_boss()
	else:
		FeatureManager.register_enemy()
	if is_boss_kill and is_instance_valid(player):
		player.add_dna(60)
		player.spawn_float_text("🧬 پاداش غول +۶۰ DNA", Color(0.4, 1.0, 1.0), self, 36)
		shake_screen(12.0)
	# Dead enemy drops: meat / DNA chunks
	var drops : int = maxi(1, int(enemy_mass / 25.0))
	for i in range(drops):
		var f = FOOD_SCENE.instantiate()
		f.food_type = 1 if i % 2 == 0 else 2  # NUTRIENT_HIGH (meat) / DNA_SPHERE
		f.position = enemy_pos + Vector2(rng.randf_range(-30, 30), rng.randf_range(-30, 30))
		f.value = maxf(6.0, enemy_mass * 0.15)
		entities.add_child(f)
	SoundManager.play_enemy_eat()

func update_dynamic_events(delta: float) -> void:
	event_timer -= delta
	if event_time_left > 0.0:
		event_time_left = maxf(0.0, event_time_left - delta)
		if active_event == "acid":
			acid_zone_time = event_time_left
			acid_zone_position += Vector2(sin(run_time * 0.37), cos(run_time * 0.29)) * 18.0 * delta
			acid_damage_timer -= delta
			if acid_damage_timer <= 0.0 and is_instance_valid(player) and player.global_position.distance_to(acid_zone_position) < 280.0:
				player.take_damage(5.0, acid_zone_position)
				acid_damage_timer = 1.0
		if event_time_left <= 0.0:
			if active_event == "swarm":
				for enemy in get_tree().get_nodes_in_group("enemies"):
					if is_instance_valid(enemy) and enemy.event_hunter:
						enemy.event_expired = true
			active_event = ""
			queue_redraw()
	if event_timer <= 0.0:
		var event_index: int = rng.randi_range(0, 2)
		match event_index:
			0: start_plankton_bloom()
			1: start_hunter_swarm()
			2: start_acid_surge()
		event_timer = rng.randf_range(45.0, 72.0)
		active_event_time_total = event_time_left

func update_treasure_hunts(delta: float) -> void:
	treasure_timer -= delta
	if treasure_timer > 0.0 or not is_instance_valid(player):
		return
	treasure_timer = rng.randf_range(55.0, 85.0)
	var angle = rng.randf_range(0.0, TAU)
	var pos = player.global_position + Vector2.RIGHT.rotated(angle) * rng.randf_range(360.0, 650.0)
	var orb: Node2D = Node2D.new()
	orb.name = "DNATreasure"
	orb.position = pos
	orb.z_index = 14
	orb.set_meta("dna_reward", rng.randi_range(10, 24))
	orb.set_meta("life", 18.0)
	orb.set_script(load("res://scripts/PowerupOrb.gd"))
	orb.set_meta("powerup_type", "dna_treasure")
	orb.set_meta("label", "گنج DNA")
	orb.set_meta("orb_color", Color(0.85, 0.3, 1.0))
	entities.add_child(orb)
	powerup_nodes.append(orb)
	ui.show_event("💎 گنج DNA پیدا شد! قبل از ناپدیدشدن پیدایش کن", 5.0)

func update_run_milestones() -> void:
	if not is_instance_valid(player):
		return
	var marks = [60, 180, 300, 480]
	for mark in marks:
		if run_time >= mark and not milestone_marks.has(mark):
			milestone_marks[mark] = true
			var reward = 8 + int(mark / 60) * 4
			player.add_dna(reward)
			player.spawn_float_text("🏅 رکورد بقا! +%d DNA" % reward, Color(1.0, 0.86, 0.25), self, 30)
			ui.show_event("🏅 نقطه عطف %d دقیقه‌ای" % int(mark / 60), 3.0)

func start_plankton_bloom() -> void:
	active_event = "bloom"
	event_time_left = 8.0
	var hotspot_angle: float = rng.randf_range(0.0, TAU)
	var hotspot_distance: float = rng.randf_range(600.0, 1400.0)
	var center: Vector2 = player.global_position + Vector2(cos(hotspot_angle), sin(hotspot_angle)) * hotspot_distance
	var count: int = rng.randi_range(50, 90)
	for i in range(count):
		var food: Node2D = FOOD_SCENE.instantiate()
		var pick: float = rng.randf()
		food.food_type = 2 if pick < 0.45 else (1 if pick < 0.78 else rng.randi_range(0, 3))
		var angle: float = rng.randf_range(0.0, TAU)
		var radius_spawn: float = sqrt(rng.randf()) * 230.0
		food.position = center + Vector2(cos(angle), sin(angle)) * radius_spawn
		entities.add_child(food)
	ui.show_event("شکوفایی پلانکتون", 8.0)

func start_hunter_swarm() -> void:
	active_event = "swarm"
	event_time_left = 24.0
	var count: int = rng.randi_range(10, 15)
	for i in range(count):
		var angle: float = rng.randf_range(0.0, TAU)
		# شکارچیان در فاصله‌ای قابل‌مشاهده وارد می‌شوند تا واقعاً شروع به تعقیب کنند.
		var pos: Vector2 = player.global_position + Vector2(cos(angle), sin(angle)) * rng.randf_range(520.0, 760.0)
		var enemy: Node2D = ENEMY_SCENE.instantiate()
		enemy.enemy_type = 1
		enemy.is_event_hunter = true
		enemy.event_lifetime = 24.0
		enemy.event_hunter = true
		enemy.is_predator = true
		enemy.difficulty = difficulty_scale()
		enemy.global_position = pos
		enemy.target_player = player
		enemy.died.connect(_on_enemy_died)
		enemy.hit_player.connect(_on_enemy_hit_player)
		entities.add_child(enemy)
		enemy.set_hunter_threat(player.mass, player.current_speed)
		enemy.mass = maxf(player.mass * 1.25, 600.0) * rng.randf_range(0.95, 1.35)
		# مزیت سرعت ثابت برای اینکه شکارچی‌ها واقعاً به بازیکن برسند.
		enemy.speed = player.current_speed * rng.randf_range(1.20, 1.32) + 55.0
		enemy.is_event_hunter = true
		enemy.is_predator = true
		enemy.apply_growth_visual()
	ui.show_event("حملهٔ شکارچیان — زنده بمان و شکارشان کن!", 24.0)

func start_acid_surge() -> void:
	active_event = "acid"
	event_time_left = 25.0
	acid_zone_time = 25.0
	acid_zone_position = player.global_position + Vector2.RIGHT.rotated(rng.randf_range(0.0, TAU)) * rng.randf_range(600.0, 900.0)
	acid_damage_timer = 0.0
	queue_redraw()
	ui.show_event("مه اسیدی", 25.0)

func update_boss_schedule() -> void:
	# هر منطقه ۳ تا ۵ باس دارد. باس‌ها در طول همان منطقه پخش می‌شوند.
	if region_bosses_spawned >= region_boss_target:
		return
	region_next_boss_timer -= get_process_delta_time()
	if region_next_boss_timer > 0.0:
		return
	var names: Array = REGION_BOSS_NAMES.get(region_name, ["غول اعماق", "نگهبان", "تایتان", "فرمانروا"])
	var boss_name: String = str(names[region_bosses_spawned % names.size()])
	var type_pool: Array[int] = [EnemyTypeFallback(region_bosses_spawned)]
	var type: int = type_pool[0]
	var warning = "👑 %s در %s ظاهر شد! فرار کن یا شکستش بده!" % [boss_name, region_name]
	boss_variant_index += 1
	_spawn_boss(type, boss_name, warning)
	region_bosses_spawned += 1
	var remaining = maxf(1.0, float(region_boss_target - region_bosses_spawned))
	if region_cycle_count == 0:
		# منطقه افتتاحیه فقط یک دقیقه است، پس باس‌هایش سریع‌تر وارد می‌شوند.
		region_next_boss_timer = rng.randf_range(13.0, 18.0)
	else:
		var region_span = maxf(45.0, region_change_timer)
		region_next_boss_timer = clampf(region_span / remaining, 25.0, 70.0)

func EnemyTypeFallback(index: int) -> int:
	# نوع پایه با تم منطقه عوض می‌شود تا باس‌ها فقط اسم متفاوت نداشته باشند.
	match region_name:
		"منطقه شکار": return 1 if index % 2 == 0 else 4
		"خندق تاریک": return 4 if index % 2 == 0 else 3
		"جنگل زیستی": return 0 if index % 2 == 0 else 7
		"دره کریستالی": return 7
		"آب‌های یخی": return 3 if index % 2 == 0 else 4
		"شهر مرجانی": return 3 if index % 2 == 0 else 5
		"غار زیستی": return 5 if index % 2 == 0 else 7
		_: return 4 if index % 2 == 0 else 3

func _spawn_boss(type: int, boss_name: String = "لویاتان اعماق", warning: String = "غول نزدیک می‌شود!") -> void:
	var e = ENEMY_SCENE.instantiate()
	e.enemy_type = type
	e.is_boss = true
	e.difficulty = difficulty_scale() * (1.15 + 0.08 * float(region_bosses_spawned))
	e.region_name = region_name
	e.set_meta("boss_name", boss_name)
	e.set_meta("boss_warning", warning)
	var spawn_angle: float = rng.randf_range(0.0, TAU)
	var spawn_distance: float = rng.randf_range(620.0, 900.0)
	e.position = player.global_position + Vector2.RIGHT.rotated(spawn_angle) * spawn_distance
	if e.position.length() > MAP_RADIUS - 180.0:
		e.position = e.position.normalized() * (MAP_RADIUS - 180.0)
	e.target_player = player
	e.died.connect(_on_enemy_died)
	e.hit_player.connect(_on_enemy_hit_player)
	if e.has_signal("boss_defeated"):
		e.boss_defeated.connect(_on_boss_defeated)
	entities.add_child(e)
	shake_screen(16.0)
	if is_instance_valid(ui):
		ui.show_boss_warning(warning)
		if ui.has_method("bind_boss"):
			ui.bind_boss(e)

func _on_boss_defeated(boss_pos: Vector2) -> void:
	shake_screen(20.0)
	if is_instance_valid(ui) and ui.has_method("show_boss_defeated"):
		ui.show_boss_defeated()
	spawn_feedback_label("🏆 غول شکست خورد!", Color(1.0, 0.85, 0.2), boss_pos, 34)

func shake_screen(amount: float = 7.0) -> void:
	# پشتیبانی از نام قدیمی؛ اکنون از _trigger_screen_shake استفاده می‌کند
	_trigger_screen_shake(amount)

func record_enemy_defeated() -> void:
	SaveManager.add_weekly_progress("enemy", 1)
	add_masterpiece_progress("enemy", 1)
	# سیگنال مرگ دشمن (died) -> سیستم مأموریت UI
	if is_instance_valid(ui):
		if ui.has_method("record_enemy_defeated"):
			ui.record_enemy_defeated()
		else:
			ui.quest_add_progress("enemy", 1)

func _trigger_screen_shake(amount: float) -> void:
	# شروع لرزش دوربین؛ در _process هر فریم میرا می‌شود
	camera_shake = maxf(camera_shake, clampf(amount, 0.0, 24.0))

func _on_player_damage_taken(_position: Vector2, damage: float) -> void:
	_trigger_screen_shake(clampf(damage * 0.5, 3.0, 14.0))

func _on_player_food_eaten(_value: float) -> void:
	SaveManager.add_weekly_progress("food", 1)
	FeatureManager.register_mass(_value)
	add_masterpiece_progress("food", 1)
	_trigger_screen_shake(1.5)

func _on_player_combo_reached(combo: int) -> void:
	if combo > 0 and combo % 5 == 0:
		_trigger_screen_shake(4.0)
		if is_instance_valid(ui) and ui.has_method("show_event"):
			ui.show_event("🔥 کمبو x%d" % combo, 1.5)

func _on_player_adrenaline_changed(active: bool, _pulse: float) -> void:
	if active:
		_trigger_screen_shake(8.0)

func _on_enemy_hit_player(position: Vector2, damage: float) -> void:
	shake_screen(clampf(damage * 0.45, 3.0, 12.0))

func spawn_feedback_label(text: String, color: Color, pos: Vector2, font_size: int = 26) -> void:
	var label: Label = null
	for pooled: Label in feedback_pool:
		if is_instance_valid(pooled) and not pooled.visible:
			label = pooled
			break
	if label == null:
		if feedback_pool.size() >= 20:
			return
		label = Label.new()
		label.top_level = true
		label.z_index = 100
		entities.add_child(label)
		feedback_pool.append(label)
	label.text = text
	label.visible = true
	label.global_position = pos + Vector2(rng.randf_range(-25.0, 25.0), -35.0)
	label.modulate = Color.WHITE
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	label.add_theme_constant_override("outline_size", 6)
	var tween: Tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(label, "global_position", label.global_position + Vector2(0, -60), 0.8)
	tween.tween_property(label, "modulate:a", 0.0, 0.8)
	tween.chain().tween_callback(func(): label.visible = false)

func _region_color(name: String) -> Color:
	match name:
		"دشت آرام": return Color(0.25,0.95,0.72)
		"جنگل زیستی": return Color(0.30,1.0,0.32)
		"منطقه شکار": return Color(1.0,0.20,0.12)
		"خندق تاریک": return Color(0.62,0.30,1.0)
		"شهر مرجانی": return Color(1.0,0.35,0.70)
		"دره کریستالی": return Color(0.35,0.88,1.0)
		"غار زیستی": return Color(0.75,0.38,1.0)
		"آب‌های یخی": return Color(0.65,0.92,1.0)
		_: return Color(0.3,0.9,0.9)

func update_region(delta: float) -> void:
	if not is_instance_valid(player) or not is_instance_valid(ui):
		return
	region_change_timer -= delta
	if region_change_timer > 0.0:
		return
	region_index = (region_index + 1) % REGIONS.size()
	region_cycle_count += 1
	var data: Dictionary = REGIONS[region_index]
	region_name = str(data["name"])
	FeatureManager.register_region(region_name)
	# از تغییر دوم به بعد، هر منطقه ۲ تا ۵ دقیقه دوام دارد.
	region_change_timer = rng.randf_range(120.0, 300.0)
	region_bosses_spawned = 0
	region_boss_target = rng.randi_range(3, 5)
	region_next_boss_timer = 18.0
	if is_instance_valid(background) and background.has_method("set_region_theme"):
		background.set_region_theme(region_name)
	if player.has_method("set_region_visual_tint"):
		player.set_region_visual_tint(_region_color(region_name))
	# دشمنان زنده هم‌زمان با محیط تغییر ظاهر می‌دهند؛ دشمن جدید هم از همین تم استفاده می‌کند.
	for enemy in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(enemy) and enemy.has_method("set_region_theme"):
			enemy.set_region_theme(region_name)
	# اعلان اختصاصی منطقه: بزرگ، بالای صفحه و جدا از اعلان‌های معمولی تا گم نشود.
	ui.show_region_change(region_name)
	if ui.has_method("set_region_pause_theme"):
		ui.set_region_pause_theme(region_name)
	if region_cycle_count > 0 and region_cycle_count % 3 == 0:
		ui.show_event("🌊 محیط تغییر کرد — چیزهای جدید پیدا کن!", 4.0)
	queue_redraw()

func apply_world_detail_color(c: Color) -> void:
	world_detail_color = c
	if is_instance_valid(background):
		background.modulate = Color(1.0, 1.0, 1.0, 1.0)
	queue_redraw()

func add_masterpiece_progress(kind: String, amount: int = 1) -> void:
	if is_instance_valid(masterpiece_director) and masterpiece_director.has_method("add_progress"):
		masterpiece_director.add_progress(kind, amount)

func _draw() -> void:
	if active_event == "acid" and event_time_left > 0.0:
		var local_pos: Vector2 = to_local(acid_zone_position)
		draw_circle(local_pos, 280.0, Color(0.45, 0.8, 0.12, 0.12))
		draw_arc(local_pos, 280.0, 0.0, TAU, 48, Color(0.7, 1.0, 0.2, 0.48), 5.0, true)

func _on_player_evolved(_lvl: int, _stats: Dictionary):
	SoundManager.play_evolve()

func _on_player_died():
	SaveManager.save_game()

func cull_distant_entities():
	# حذف دشمنان/غذاهای خیلی دور از بازیکن (culling پویا)؛ اسپاونر دوباره پر می‌کند
	if player == null or not is_instance_valid(player):
		return
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and player.global_position.distance_to(e.global_position) > CULL_DISTANCE:
			e.queue_free()
	for f in get_tree().get_nodes_in_group("food"):
		if is_instance_valid(f) and player.global_position.distance_to(f.global_position) > CULL_DISTANCE:
			f.queue_free()

func keep_entities_in_bounds():
	for e in get_tree().get_nodes_in_group("enemies") + get_tree().get_nodes_in_group("food"):
		if not is_instance_valid(e):
			continue
		var d = e.global_position.length()
		if d > MAP_RADIUS:
			e.global_position = e.global_position.normalized() * MAP_RADIUS
