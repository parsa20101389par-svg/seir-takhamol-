extends Node2D
# پس‌زمینه اقیانوسی رویه‌ای: گردوغبار معلق، پلانکتون‌های درخشان،
# پرتوهای حجمی متحرک، موج‌های کاستیک و حباب‌های صعودکننده.

@export var map_radius: float = 2400.0
@export var dust_count: int = 35
@export var plankton_count: int = 20

var dust: Array[Dictionary] = []
var motes: Array[Dictionary] = []
var bubbles: Array[Dictionary] = []
var plankton: Array[Dictionary] = []
var ambient_glow: Array[Dictionary] = []
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var time: float = 0.0
var frame_counter: int = 0
var region_name: String = "دشت آرام"
var region_color: Color = Color(0.03, 0.10, 0.15)
var region_accent: Color = Color(0.18, 0.85, 0.82)
var region_decor: Array[Dictionary] = []

const MOTE_COUNT: int = 15
const BUBBLE_COUNT: int = 15
const AMBIENT_GLOW_COUNT: int = 9

func _ready() -> void:
	rng.randomize()
	set_region_theme(region_name)
	for i in range(dust_count):
		var tint: Color = Color(0.65, 0.86, 1.0) if rng.randf() < 0.7 else Color(0.4, 1.0, 0.86)
		dust.append({
			"pos": _random_point(60.0),
			"r": rng.randf_range(0.6, 2.8),
			"speed": rng.randf_range(3.0, 16.0),
			"dir": rng.randf_range(0.0, TAU),
			"wobble": rng.randf_range(0.0, TAU),
			"alpha": rng.randf_range(0.08, 0.3),
			"color": tint,
		})
	for i in range(MOTE_COUNT):
		var mote_color: Color = Color(0.24, 0.95, 0.83) if rng.randf() < 0.5 else Color(0.3, 0.63, 1.0)
		motes.append({
			"pos": _random_point(60.0),
			"r": rng.randf_range(1.2, 4.5),
			"phase": rng.randf_range(0.0, TAU),
			"glow": mote_color,
			"drift": Vector2(rng.randf_range(-5.0, 5.0), rng.randf_range(-4.0, 4.0)),
		})
	for i in range(BUBBLE_COUNT):
		bubbles.append({
			"pos": _random_point(60.0),
			"r": rng.randf_range(1.8, 6.5),
			"rise": rng.randf_range(14.0, 48.0),
			"sway": rng.randf_range(0.0, TAU),
			"sway_speed": rng.randf_range(0.5, 1.6),
			"sway_amp": rng.randf_range(5.0, 20.0),
			"alpha": rng.randf_range(0.1, 0.32),
		})
	# پلانکتون‌های نقطه‌ای؛ هرکدام چشمک‌زن و بافت‌دار هستند.
	for i in range(plankton_count):
		var plankton_color: Color = Color(0.44, 1.0, 0.72) if rng.randf() < 0.55 else Color(0.44, 0.76, 1.0)
		plankton.append({
			"pos": _random_point(60.0),
			"base": _random_point(60.0),
			"r": rng.randf_range(0.7, 2.1),
			"phase": rng.randf_range(0.0, TAU),
			"speed": rng.randf_range(0.8, 2.6),
			"amp": rng.randf_range(2.0, 13.0),
			"color": plankton_color,
			"drift": Vector2(rng.randf_range(-1.8, 1.8), rng.randf_range(-1.8, 1.8)),
		})

	# هاله‌های محیطی بزرگ و بسیار کم‌رنگ برای عمق آب
	for i in range(AMBIENT_GLOW_COUNT):
		var glow_color: Color = Color(0.35, 0.85, 1.0) if rng.randf() < 0.5 else Color(0.25, 0.7, 0.95)
		ambient_glow.append({
			"pos": _random_point(120.0),
			"r": rng.randf_range(80.0, 150.0),
			"alpha": 0.03,
			"drift": Vector2(rng.randf_range(-2.5, 2.5), rng.randf_range(-1.8, 1.8)),
			"phase": rng.randf_range(0.0, TAU),
			"color": glow_color,
		})


func set_region_theme(new_region: String) -> void:
	region_name = new_region
	match new_region:
		"دشت آرام":
			region_color = Color(0.025, 0.11, 0.16)
			region_accent = Color(0.18, 0.82, 0.78)
		"جنگل زیستی":
			region_color = Color(0.025, 0.13, 0.09)
			region_accent = Color(0.25, 0.95, 0.38)
		"منطقه شکار":
			region_color = Color(0.15, 0.055, 0.075)
			region_accent = Color(1.0, 0.20, 0.22)
		"خندق تاریک":
			region_color = Color(0.018, 0.025, 0.065)
			region_accent = Color(0.38, 0.28, 1.0)
		"شهر مرجانی":
			region_color = Color(0.12, 0.045, 0.11)
			region_accent = Color(1.0, 0.32, 0.70)
		"دره کریستالی":
			region_color = Color(0.035, 0.08, 0.15)
			region_accent = Color(0.35, 0.82, 1.0)
		"غار زیستی":
			region_color = Color(0.07, 0.055, 0.10)
			region_accent = Color(0.68, 0.35, 1.0)
		"آب‌های یخی":
			region_color = Color(0.03, 0.10, 0.17)
			region_accent = Color(0.72, 0.94, 1.0)
	region_decor.clear()
	var local_rng = RandomNumberGenerator.new()
	local_rng.seed = abs(hash(new_region)) + 1337
	for i in range(42):
		var a = local_rng.randf_range(0.0, TAU)
		var r = sqrt(local_rng.randf()) * 2150.0
		region_decor.append({
			"pos": Vector2(cos(a) * r, sin(a) * r),
			"size": local_rng.randf_range(16.0, 80.0),
			"phase": local_rng.randf_range(0.0, TAU),
			"kind": local_rng.randi_range(0, 3)
		})
	queue_redraw()

func _random_point(margin: float = 0.0) -> Vector2:
	var usable_radius: float = maxf(1.0, map_radius - margin)
	var random_radius: float = sqrt(rng.randf()) * usable_radius
	var angle: float = rng.randf() * TAU
	return Vector2(cos(angle) * random_radius, sin(angle) * random_radius)

func _process(delta: float) -> void:
	time += delta
	for index in range(dust.size()):
		var particle: Dictionary = dust[index]
		var particle_pos: Vector2 = particle["pos"]
		var direction: float = particle["dir"]
		particle_pos += Vector2(cos(direction), sin(direction) * 0.4) * float(particle["speed"]) * delta
		particle_pos.y += sin(time * 0.7 + float(particle["wobble"])) * 5.0 * delta
		if particle_pos.length() > map_radius:
			particle_pos = _random_point()
		particle["pos"] = particle_pos
		dust[index] = particle
	for index in range(bubbles.size()):
		var bubble: Dictionary = bubbles[index]
		var bubble_pos: Vector2 = bubble["pos"]
		bubble_pos.y -= float(bubble["rise"]) * delta
		bubble_pos.x += sin(time * float(bubble["sway_speed"]) + float(bubble["sway"])) * float(bubble["sway_amp"]) * delta
		if bubble_pos.y < -map_radius * 1.1 or bubble_pos.length() > map_radius * 1.3:
			bubble_pos = _random_point(60.0)
			bubble_pos.y = map_radius * rng.randf_range(0.4, 1.0)
		bubble["pos"] = bubble_pos
		bubbles[index] = bubble
	for index in range(motes.size()):
		var mote: Dictionary = motes[index]
		var mote_pos: Vector2 = mote["pos"]
		mote_pos += mote["drift"] * delta
		if mote_pos.length() > map_radius:
			mote_pos = _random_point(60.0)
		mote["pos"] = mote_pos
		motes[index] = mote
	for index in range(plankton.size()):
		var speck: Dictionary = plankton[index]
		var base_pos: Vector2 = speck["base"]
		var phase: float = float(speck["phase"])
		var speed: float = float(speck["speed"])
		var amplitude: float = float(speck["amp"])
		var speck_pos: Vector2 = base_pos + Vector2(
			sin(time * speed + phase) * amplitude,
			cos(time * speed * 0.73 + phase * 1.7) * amplitude * 0.7
		) + speck["drift"] * time
		if speck_pos.length() > map_radius:
			base_pos = _random_point(80.0)
			speck["base"] = base_pos
			speck_pos = base_pos
		speck["pos"] = speck_pos
		plankton[index] = speck
	for index in range(ambient_glow.size()):
		var blob: Dictionary = ambient_glow[index]
		var blob_pos: Vector2 = blob["pos"]
		blob_pos += blob["drift"] * delta
		blob_pos.y += sin(time * 0.12 + float(blob["phase"])) * 3.0 * delta
		if blob_pos.length() > map_radius:
			blob_pos = _random_point(120.0)
		blob["pos"] = blob_pos
		ambient_glow[index] = blob
	frame_counter += 1
	if frame_counter % 3 == 0:
		queue_redraw()

func _draw() -> void:
	# هر منطقه ظاهر مستقل خودش را دارد؛ این لایه پشت موجودات بازی رسم می‌شود.
	draw_circle(Vector2.ZERO, map_radius, Color(region_color.r, region_color.g, region_color.b, 0.94))
	for deco in region_decor:
		var pos: Vector2 = deco["pos"]
		var size: float = float(deco["size"])
		var phase: float = float(deco["phase"])
		var kind: int = int(deco["kind"])
		var pulse = 0.65 + 0.35 * sin(time * 0.7 + phase)
		match kind:
			0:
				draw_circle(pos, size, Color(region_accent.r, region_accent.g, region_accent.b, 0.035 * pulse))
				draw_arc(pos, size * 0.7, 0.0, TAU, 20, Color(region_accent.r, region_accent.g, region_accent.b, 0.16 * pulse), 3.0)
			1:
				for branch in range(4):
					var ang = float(branch) * TAU / 4.0 + phase
					var end = pos + Vector2(cos(ang), sin(ang)) * size
					draw_line(pos, end, Color(region_accent.r, region_accent.g, region_accent.b, 0.12), 5.0)
			2:
				draw_colored_polygon(PackedVector2Array([
					pos + Vector2(0, -size), pos + Vector2(size * 0.55, 0),
					pos + Vector2(0, size), pos + Vector2(-size * 0.55, 0)
				]), Color(region_accent.r, region_accent.g, region_accent.b, 0.08 * pulse))
			3:
				draw_arc(pos, size, -PI * 0.85, PI * 0.85, 24, Color(region_accent.r, region_accent.g, region_accent.b, 0.11), 4.0)

	# هاله‌های محیطی نرم و بسیار کم‌رنگ در عمق آب (پشت همه چیز)
	for blob in ambient_glow:
		var blob_color: Color = blob["color"]
		var blob_pos: Vector2 = blob["pos"]
		var blob_radius: float = float(blob["r"])
		var blob_alpha: float = float(blob["alpha"]) * (0.75 + 0.25 * sin(time * 0.3 + float(blob["phase"])))
		draw_circle(blob_pos, blob_radius, Color(blob_color.r, blob_color.g, blob_color.b, blob_alpha * 0.5))
		draw_circle(blob_pos, blob_radius * 0.6, Color(blob_color.r, blob_color.g, blob_color.b, blob_alpha))
	# هاله‌های پلانکتون بزرگ‌تر/براق‌تر، برای نقاط عمق‌دار در پس‌زمینه.
	for mote in motes:
		var mote_pulse: float = 0.5 + 0.5 * sin(time * 1.25 + float(mote["phase"]))
		var mote_color: Color = mote["glow"]
		var mote_pos: Vector2 = mote["pos"]
		var mote_radius: float = float(mote["r"])
		draw_circle(mote_pos, mote_radius * (1.8 + mote_pulse), Color(mote_color.r, mote_color.g, mote_color.b, 0.035 + mote_pulse * 0.025))
		draw_circle(mote_pos, mote_radius * 0.65, Color(mote_color.r, mote_color.g, mote_color.b, 0.08 + mote_pulse * 0.06))
	# مهِ پلانکتونی: برق‌های ریز با هاله کوچک و چشمک نامنظم.
	for speck in plankton:
		var plankton_phase: float = float(speck["phase"])
		var plankton_speed: float = float(speck["speed"])
		var twinkle: float = 0.28 + 0.72 * absf(sin(time * plankton_speed + plankton_phase))
		var speck_color: Color = speck["color"]
		var speck_pos: Vector2 = speck["pos"]
		var speck_radius: float = float(speck["r"])
		draw_circle(speck_pos, speck_radius * 3.2, Color(speck_color.r, speck_color.g, speck_color.b, 0.025 * twinkle))
		draw_circle(speck_pos, speck_radius, Color(speck_color.r, speck_color.g, speck_color.b, 0.25 * twinkle))
	# حلقه‌ی حباب‌های صعودکننده، با برق بازتابی ظریف.
	for bubble in bubbles:
		var bubble_pos: Vector2 = bubble["pos"]
		var bubble_radius: float = float(bubble["r"])
		var bubble_alpha: float = float(bubble["alpha"])
		var bubble_color: Color = Color(0.72, 0.92, 1.0, bubble_alpha)
		draw_circle(bubble_pos, bubble_radius, Color(0.46, 0.76, 1.0, bubble_alpha * 0.12))
		draw_circle(bubble_pos, bubble_radius, Color(0.46, 0.76, 1.0, bubble_alpha * 0.35))
		draw_circle(bubble_pos + Vector2(-bubble_radius * 0.3, -bubble_radius * 0.3), bubble_radius * 0.25, Color(1.0, 1.0, 1.0, bubble_alpha * 0.5))
	# ذرات معلق جلویی برای افزودن عمق میدان.
	for particle in dust:
		var particle_color: Color = particle["color"]
		var particle_alpha: float = float(particle["alpha"])
		draw_circle(particle["pos"], float(particle["r"]), Color(particle_color.r, particle_color.g, particle_color.b, particle_alpha))
